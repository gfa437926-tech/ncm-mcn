with open('src/App.tsx', 'r') as f:
    content = f.read()

import_lines = """
import ClimateLibraryView from './components/views/ClimateLibraryView';
import SpecializedLibraryView from './components/views/SpecializedLibraryView';
import DynamicPageView from './components/views/DynamicPageView';
"""

if "import ClimateLibraryView" not in content:
    content = content.replace("import AdvancedMapsView", import_lines + "import AdvancedMapsView")

with open('src/App.tsx', 'w') as f:
    f.write(content)
