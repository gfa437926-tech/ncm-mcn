with open('src/components/Header.tsx', 'r') as f:
    content = f.read()

import re

pattern = re.compile(r'<div className="hidden lg:flex items-center">\s*<nav className="flex gap-1 text-sm font-bold">.*?</nav>\s*</div>', re.DOTALL)

content = pattern.sub('', content)

# I should also pass `onMenuClick` to `Header` and wire it up.
content = content.replace("export default function Header() {", "export default function Header({ onMenuClick }: { onMenuClick?: () => void }) {")
content = content.replace('<button className="p-2 hover:bg-white/10 rounded-md lg:hidden">', '<button onClick={onMenuClick} className="p-2 hover:bg-white/10 rounded-md lg:hidden">')

with open('src/components/Header.tsx', 'w') as f:
    f.write(content)
