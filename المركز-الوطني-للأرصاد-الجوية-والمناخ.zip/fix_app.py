with open('src/App.tsx', 'r') as f:
    content = f.read()

replacement = """      <Route path="/weather" element={
        <div className="max-w-7xl mx-auto w-full animate-in fade-in duration-500 pb-20 md:pb-0">
          <WeatherDashboard 
            data={weatherData} 
            cities={cities}
            selectedCity={selectedCity}
            onCityChange={setSelectedCity}
            loading={loading}
          />
          <div className="mt-8">
            <MediaSection />
          </div>
        </div>
      } />"""

import re
pattern = re.compile(r'      <Route path="/weather" element=\{.*?</Route>', re.DOTALL)
content = re.sub(r'      <Route path="/weather" element=\{.*?</Route>', replacement + '\n      </Route>', content, flags=re.DOTALL)
# wait, the pattern might be wrong because there's no </Route> for the weather route, it's <Route ... />
