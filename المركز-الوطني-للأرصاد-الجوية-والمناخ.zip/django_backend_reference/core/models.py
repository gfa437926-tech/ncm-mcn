from django.db import models

class PageContent(models.Model):
    page_id = models.CharField(max_length=100, unique=True)
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

class PageSection(models.Model):
    page = models.ForeignKey(PageContent, related_name='sections', on_delete=models.CASCADE)
    title = models.CharField(max_length=200, blank=True, null=True)
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ['order']

class Paragraph(models.Model):
    section = models.ForeignKey(PageSection, related_name='paragraphs', on_delete=models.CASCADE)
    text = models.TextField()
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ['order']

class ListItem(models.Model):
    section = models.ForeignKey(PageSection, related_name='list_items', on_delete=models.CASCADE)
    text = models.CharField(max_length=500)
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ['order']
