# Django Backend Reference

هذه الملفات المرجعية تمثل هيكلية قاعدة البيانات لموقع المركز الوطني للأرصاد باستخدام Django Framework كما طلبت.
يمكنك استخدام هذه النماذج (Models) وواجهات برمجة التطبيقات (Views) لربط النظام بـ PostgreSQL أو Oracle أو MySQL عبر Django ORM.

## الإعداد
1. `pip install django djangorestframework`
2. Configure `settings.py` `DATABASES` for PostgreSQL/MySQL/Oracle.
3. Run `python manage.py makemigrations` and `python manage.py migrate`.
