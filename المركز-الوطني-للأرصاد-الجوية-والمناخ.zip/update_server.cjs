const fs = require('fs');

let serverCode = fs.readFileSync('server.ts', 'utf8');

// Schemas to add
const newSchemas = `
// News Schema
const newsSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  date: { type: Date, default: Date.now },
  imageUrl: { type: String },
  source: { type: String }
});
const News = mongoose.model('News', newsSchema);

// Photos Schema
const photoSchema = new mongoose.Schema({
  title: { type: String, required: true },
  url: { type: String, required: true },
  description: { type: String },
  date: { type: Date, default: Date.now }
});
const Photo = mongoose.model('Photo', photoSchema);

// Videos Schema
const videoSchema = new mongoose.Schema({
  title: { type: String, required: true },
  url: { type: String, required: true },
  description: { type: String },
  thumbnailUrl: { type: String },
  date: { type: Date, default: Date.now }
});
const Video = mongoose.model('Video', videoSchema);
`;

serverCode = serverCode.replace("const Forecast = mongoose.model('Forecast', forecastSchema);", "const Forecast = mongoose.model('Forecast', forecastSchema);\n" + newSchemas);

// Seeding logic to add
const newSeeding = `
        // Seed News
        const newsCount = await News.countDocuments();
        if (newsCount === 0) {
          await News.insertMany([
            {
              title: "عاصفة رملية تقترب من المناطق الشرقية",
              content: "تشير التوقعات إلى اقتراب عاصفة رملية من المناطق الشرقية والبادية السورية.",
              imageUrl: "https://images.unsplash.com/photo-1541814686412-421711756598?w=800&q=80",
              source: "المركز الوطني"
            },
            {
              title: "انخفاض درجات الحرارة الأسبوع القادم",
              content: "من المتوقع انخفاض تدريجي في درجات الحرارة بدءاً من يوم الأحد.",
              imageUrl: "https://images.unsplash.com/photo-1542267246-86ea4bdfd6c6?w=800&q=80",
              source: "قسم التنبؤات"
            }
          ]);
          console.log("Seeded initial news data");
        }

        // Seed Photos
        const photoCount = await Photo.countDocuments();
        if (photoCount === 0) {
          await Photo.insertMany([
            {
              title: "غيوم ركامية فوق الساحل",
              url: "https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=800&q=80",
              description: "صورة التقطت لغيوم ركامية تشير إلى هطولات مطرية مرتقبة."
            },
            {
              title: "المرصد المناخي",
              url: "https://images.unsplash.com/photo-1580193769210-b8d1c049a7d9?w=800&q=80",
              description: "أجهزة الرصد الجوي في المركز."
            }
          ]);
          console.log("Seeded initial photos data");
        }

        // Seed Videos
        const videoCount = await Video.countDocuments();
        if (videoCount === 0) {
          await Video.insertMany([
            {
              title: "النشرة الجوية المفصلة",
              url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
              thumbnailUrl: "https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=800&q=80",
              description: "توقعات الطقس للأيام القادمة."
            }
          ]);
          console.log("Seeded initial videos data");
        }
`;

serverCode = serverCode.replace("console.log(\"Seeded initial forecast data\");\n      }", "console.log(\"Seeded initial forecast data\");\n      }\n" + newSeeding);

// Endpoints to add
const newEndpoints = `
  // Endpoint to fetch news
  app.get("/api/news", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json({
          status: "mock",
          data: [
            { _id: "1", title: "خبر تجريبي", content: "هذا خبر تجريبي نظراً لعدم الاتصال بقاعدة البيانات.", date: new Date() }
          ]
        });
      }
      const news = await News.find().sort({ date: -1 });
      res.json({ status: "ok", data: news });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  // Endpoint to fetch photos
  app.get("/api/photos", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json({
          status: "mock",
          data: []
        });
      }
      const photos = await Photo.find().sort({ date: -1 });
      res.json({ status: "ok", data: photos });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch photos" });
    }
  });

  // Endpoint to fetch videos
  app.get("/api/videos", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json({
          status: "mock",
          data: []
        });
      }
      const videos = await Video.find().sort({ date: -1 });
      res.json({ status: "ok", data: videos });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch videos" });
    }
  });
`;

serverCode = serverCode.replace("// AI Chat endpoint for Weather", newEndpoints + "\n  // AI Chat endpoint for Weather");

fs.writeFileSync('server.ts', serverCode);
