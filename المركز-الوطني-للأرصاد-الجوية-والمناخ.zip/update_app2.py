with open('src/App.tsx', 'r') as f:
    content = f.read()

target = "  useEffect(() => {\n    const loadWeather = async () => {"

replacement = """  const [cities, setCities] = useState<City[]>(SYRIAN_CITIES);

  useEffect(() => {
    const fetchCities = async () => {
      try {
        const res = await fetch('/api/stations');
        const data = await res.json();
        if (data.status === 'ok' && data.data && data.data.length > 0) {
          const fetchedCities = data.data.map((station: any) => ({
            id: station._id,
            name: station.name,
            lat: station.location?.coordinates[1] || 33.5,
            lng: station.location?.coordinates[0] || 36.3
          }));
          setCities(fetchedCities);
          setSelectedCity(fetchedCities[0]);
        }
      } catch (err) {
        console.error("Failed to fetch cities from MongoDB", err);
      }
    };
    fetchCities();
  }, []);

  useEffect(() => {
    const loadWeather = async () => {"""

content = content.replace(target, replacement)
content = content.replace("cities={SYRIAN_CITIES}", "cities={cities}")

with open('src/App.tsx', 'w') as f:
    f.write(content)
