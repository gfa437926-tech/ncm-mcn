import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import mongoose from "mongoose";
import { cmsRouter } from "./src/api/cms.js";
import { alertsRouter } from "./src/api/alerts.js";

// Setup MongoDB connection schema (for Windy verified data)
const windyDataSchema = new mongoose.Schema({
  date: { type: Date, required: true },
  region: { type: String, required: true },
  forecastData: { type: Object, required: true },
  approvedBy: { type: String, required: true },
  exportedAt: { type: Date, default: Date.now },
});

const WindyData = mongoose.model("WindyData", windyDataSchema);

// Station Schema
const stationSchema = new mongoose.Schema({
  name: { type: String, required: true },
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], required: true } // [longitude, latitude]
  },
  temperature: Number,
  wind_speed: Number,
  sky_condition: String,
  updated_at: { type: Date, default: Date.now }
});

stationSchema.index({ location: '2dsphere' });
const Station = mongoose.model('Station', stationSchema);

// Forecast Schema
const forecastSchema = new mongoose.Schema({
  stationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Station', required: true },
  date: { type: Date, required: true },
  temperature_max: Number,
  temperature_min: Number,
  description: String
});

const Forecast = mongoose.model('Forecast', forecastSchema);

// News Schema
const newsSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  date: { type: Date, default: Date.now },
  imageUrl: { type: String },
  source: { type: String }
});
const News = mongoose.model('News', newsSchema);

// Photos Schema
const photoSchema = new mongoose.Schema({
  title: { type: String, required: true },
  url: { type: String, required: true },
  description: { type: String },
  date: { type: Date, default: Date.now }
});
const Photo = mongoose.model('Photo', photoSchema);

// Videos Schema
const videoSchema = new mongoose.Schema({
  title: { type: String, required: true },
  url: { type: String, required: true },
  description: { type: String },
  thumbnailUrl: { type: String },
  date: { type: Date, default: Date.now }
});
const Video = mongoose.model('Video', videoSchema);


import http from "http";
import { WebSocketServer } from "ws";

async function startServer() {
  const app = express();
  const PORT = 3000;
  const server = http.createServer(app);

  app.use(express.json({ limit: '50mb' }));
  
  // CMS Routes
  app.use('/api/cms', cmsRouter);
  
  // Alerts Routes
  app.use('/api/alerts', alertsRouter);

  // Connect to MongoDB if MONGO_URI is provided
  if (process.env.MONGO_URI) {
    try {
      await mongoose.connect(process.env.MONGO_URI);
      console.log("Connected to MongoDB successfully");
      
      // Seed data if empty
      const count = await Station.countDocuments();
      if (count === 0) {
        const insertedStations = await Station.insertMany([
          {
            name: "دمشق",
            location: { type: "Point", coordinates: [36.2913, 33.5138] },
            temperature: 30,
            wind_speed: 15,
            sky_condition: "مشمس"
          },
          {
            name: "اللاذقية",
            location: { type: "Point", coordinates: [35.7901, 35.5317] },
            temperature: 28,
            wind_speed: 25,
            sky_condition: "غائم"
          },
          {
            name: "حلب",
            location: { type: "Point", coordinates: [37.1343, 36.2021] },
            temperature: 32,
            wind_speed: 10,
            sky_condition: "صافي"
          }
        ]);
        console.log("Seeded initial station data");
        
        // Seed forecasts
        const forecasts = [];
        for (const station of insertedStations) {
          for (let i = 1; i <= 3; i++) {
            const nextDay = new Date();
            nextDay.setDate(nextDay.getDate() + i);
            forecasts.push({
              stationId: station._id,
              date: nextDay,
              temperature_max: station.temperature + Math.floor(Math.random() * 5),
              temperature_min: station.temperature - Math.floor(Math.random() * 5) - 5,
              description: i % 2 === 0 ? "صافي" : "غائم جزئياً"
            });
          }
        }
        await Forecast.insertMany(forecasts);
        console.log("Seeded initial forecast data");
      }

        // Seed News
        const newsCount = await News.countDocuments();
        if (newsCount === 0) {
          await News.insertMany([
            {
              title: "عاصفة رملية تقترب من المناطق الشرقية",
              content: "تشير التوقعات إلى اقتراب عاصفة رملية من المناطق الشرقية والبادية السورية.",
              imageUrl: "https://images.unsplash.com/photo-1541814686412-421711756598?w=800&q=80",
              source: "المركز الوطني"
            },
            {
              title: "انخفاض درجات الحرارة الأسبوع القادم",
              content: "من المتوقع انخفاض تدريجي في درجات الحرارة بدءاً من يوم الأحد.",
              imageUrl: "https://images.unsplash.com/photo-1542267246-86ea4bdfd6c6?w=800&q=80",
              source: "قسم التنبؤات"
            }
          ]);
          console.log("Seeded initial news data");
        }

        // Seed Photos
        const photoCount = await Photo.countDocuments();
        if (photoCount === 0) {
          await Photo.insertMany([
            {
              title: "غيوم ركامية فوق الساحل",
              url: "https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=800&q=80",
              description: "صورة التقطت لغيوم ركامية تشير إلى هطولات مطرية مرتقبة."
            },
            {
              title: "المرصد المناخي",
              url: "https://images.unsplash.com/photo-1580193769210-b8d1c049a7d9?w=800&q=80",
              description: "أجهزة الرصد الجوي في المركز."
            }
          ]);
          console.log("Seeded initial photos data");
        }

        // Seed Videos
        const videoCount = await Video.countDocuments();
        if (videoCount === 0) {
          await Video.insertMany([
            {
              title: "النشرة الجوية المفصلة",
              url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
              thumbnailUrl: "https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=800&q=80",
              description: "توقعات الطقس للأيام القادمة."
            }
          ]);
          console.log("Seeded initial videos data");
        }

    } catch (err) {
      console.error("MongoDB connection error:", err);
    }
  } else {
    console.warn("MONGO_URI not provided. Skipping MongoDB connection.");
  }

  // API endpoints
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Endpoint to fetch verified Windy data from MongoDB
  app.get("/api/windy-data", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        // Return mock data if not connected, so the frontend works out-of-the-box for preview
        return res.json({
          status: "mock",
          data: [
            {
              _id: "mock1",
              date: new Date().toISOString(),
              region: "Damascus",
              forecastData: { windSpeed: 15, temperature: 28, condition: "Clear" },
              approvedBy: "Forecaster A",
              exportedAt: new Date().toISOString()
            },
            {
              _id: "mock2",
              date: new Date(Date.now() + 86400000).toISOString(),
              region: "Latakia",
              forecastData: { windSpeed: 25, temperature: 24, condition: "Rain" },
              approvedBy: "Forecaster B",
              exportedAt: new Date().toISOString()
            }
          ]
        });
      }

      const data = await WindyData.find().sort({ date: -1 }).limit(10);
      res.json({ status: "ok", data });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch data from MongoDB" });
    }
  });

  // Endpoint to fetch stations
  app.get("/api/stations", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json({
          status: "mock",
          data: [
            { name: "دمشق", temperature: 30, wind_speed: 15, sky_condition: "مشمس" },
            { name: "اللاذقية", temperature: 28, wind_speed: 25, sky_condition: "غائم" },
          ]
        });
      }
      const stations = await Station.find();
      res.json({ status: "ok", data: stations });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch stations" });
    }
  });

  // Endpoint to fetch forecasts
  app.get("/api/forecasts", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json({
          status: "mock",
          data: [
            { stationId: "mock1", date: new Date(Date.now() + 86400000), temperature_max: 32, temperature_min: 22, description: "صافي" }
          ]
        });
      }
      const forecasts = await Forecast.find().populate('stationId', 'name');
      res.json({ status: "ok", data: forecasts });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch forecasts" });
    }
  });

  
  // Endpoint to fetch news
  app.get("/api/news", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json({
          status: "mock",
          data: [
            { _id: "1", title: "المركز الوطني يحذر من موجة حر شديدة", content: "يتوقع أن تضرب البلاد موجة حر شديدة خلال الأيام القادمة، ويرجى أخذ الحيطة والحذر.", date: new Date(), imageUrl: "https://images.unsplash.com/photo-1504386106331-3e4e71712b38?w=800&q=80" },
            { _id: "2", title: "تحديثات الخرائط المناخية لشهر يوليو", content: "تم تحديث الخرائط المناخية وإضافة تفاصيل دقيقة عن نسب الرطوبة المتوقعة في السواحل.", date: new Date(), imageUrl: "https://images.unsplash.com/photo-1592210454359-9043f067919b?w=800&q=80" },
            { _id: "3", title: "تحذير: ازدياد حالات الإصابة باللشمانيا", content: "أعلنت وزارة الصحة بالتعاون مع المركز عن تحذير صحي بسبب التغيرات المناخية التي تزيد من انتشار ذبابة الرمل.", date: new Date(), imageUrl: "https://images.unsplash.com/photo-1584631436421-d1421008064a?w=800&q=80" }
          ]
        });
      }
      const news = await News.find().sort({ date: -1 });
      res.json({ status: "ok", data: news });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  // Endpoint to fetch photos
  app.get("/api/photos", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json({
          status: "mock",
          data: [
            { _id: "1", title: "غيوم ركامية فوق الساحل", url: "https://images.unsplash.com/photo-1534088568595-a066f410cbda?w=800&q=80" },
            { _id: "2", title: "محطة الرصد الجوي في دمشق", url: "https://images.unsplash.com/photo-1530908295418-a12e326966ba?w=800&q=80" },
            { _id: "3", title: "عاصفة رملية", url: "https://images.unsplash.com/photo-1621272036047-311e9a4fbaea?w=800&q=80" },
          ]
        });
      }
      const photos = await Photo.find().sort({ date: -1 });
      res.json({ status: "ok", data: photos });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch photos" });
    }
  });

  // Endpoint to fetch videos
  app.get("/api/videos", async (req, res) => {
    try {
      if (mongoose.connection.readyState !== 1) {
        return res.json({
          status: "mock",
          data: [
            { _id: "1", title: "كيفية تشكل العواصف", url: "https://www.youtube.com/embed/dQw4w9WgXcQ", thumbnailUrl: "https://images.unsplash.com/photo-1492011221367-f47e3ccd77a0?w=800&q=80" }
          ]
        });
      }
      const videos = await Video.find().sort({ date: -1 });
      res.json({ status: "ok", data: videos });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch videos" });
    }
  });

  // AI Chat endpoint for Weather
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, imageBase64, previous_interaction_id, useThinking, weatherContext } = req.body;
      
      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: "GEMINI_API_KEY is missing." });
      }

      let stationsContext = "";
      if (mongoose.connection.readyState === 1) {
        const stations = await Station.find();
        const forecasts = await Forecast.find().populate('stationId', 'name');
        stationsContext = "البيانات الحية من قاعدة البيانات للمحطات:\n" + JSON.stringify(stations, null, 2) + "\nالتنبؤات المستقبلية للمحطات:\n" + JSON.stringify(forecasts, null, 2);
      } else {
        stationsContext = "البيانات الحية للمحطات (Mock):\nدمشق: الحرارة 30، الرياح 15، مشمس.\nاللاذقية: الحرارة 28، الرياح 25، غائم.\nالتنبؤات: غداً في دمشق الحرارة 32.";
      }

      const { GoogleGenAI } = await import("@google/genai");
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const system_instruction = `أنت مساعد ذكي تابع للمركز الوطني للأرصاد الجوية في سوريا. 
مهمتك هي الإجابة عن أسئلة المستخدم حول الطقس.
استخدم المعطيات التالية كمرجع إضافي:
${stationsContext}`;

      let model = useThinking ? "gemini-3.1-pro-preview" : "gemini-2.5-flash";
      if (imageBase64 && !useThinking) {
        model = "gemini-3.1-pro-preview";
      }

      const input: any[] = [];
      if (imageBase64) {
        input.push({
          type: "image",
          mime_type: "image/jpeg",
          data: imageBase64.replace(/^data:image\/\w+;base64,/, ""),
        });
      }
      input.push({
        type: "text",
        text: message
      });

      const generationConfig: any = {};
      if (useThinking) {
        generationConfig.thinking_level = "high";
      }

      const interaction = await ai.interactions.create({
        model,
        input,
        previous_interaction_id: previous_interaction_id || undefined,
        system_instruction,
        tools: [
          { type: 'google_search' },
          { type: 'google_maps' }
        ],
        generation_config: Object.keys(generationConfig).length > 0 ? generationConfig : undefined
      });

      res.json({ reply: interaction.output_text, interaction_id: interaction.id });
    } catch (err: any) {
      console.error("AI Chat error:", err);
      if (err.message?.includes('429') || err.message?.includes('quota') || err.status === 429) {
        return res.status(429).json({ error: "تم تجاوز الحد المسموح للاستخدام المجاني من Gemini API. يرجى مراجعة تفاصيل حسابك أو المحاولة لاحقاً." });
      }
      res.status(500).json({ error: "Failed to generate chat response" });
    }
  });

  const wss = new WebSocketServer({ server, path: "/api/live" });

  wss.on("connection", async (clientWs) => {
    try {
      const { GoogleGenAI, Modality } = await import("@google/genai");
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const session = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: "أنت مساعد ذكي تابع للمركز الوطني للأرصاد الجوية في سوريا. أجب باختصار وبشكل مفيد.",
        },
        callbacks: {
          onmessage: (message: any) => {
            const audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audio) clientWs.send(JSON.stringify({ audio }));
            if (message.serverContent?.interrupted)
              clientWs.send(JSON.stringify({ interrupted: true }));
          },
        },
      });

      clientWs.on("message", (data) => {
        try {
          const { audio } = JSON.parse(data.toString());
          if (audio) {
            session.sendRealtimeInput({
              audio: { data: audio, mimeType: "audio/pcm;rate=16000" },
            });
          }
        } catch (e) {
          console.error("Live API WS message error", e);
        }
      });
      
    } catch (err) {
      console.error("Failed to start live session:", err);
    }
  });

  // File management for in-app code editor
  app.get("/api/files", (req, res) => {
    try {
      const srcDir = path.join(process.cwd(), 'src');
      const getFiles = (dir: string): string[] => {
        const files: string[] = [];
        const items = fs.readdirSync(dir, { withFileTypes: true });
        for (const item of items) {
          const fullPath = path.join(dir, item.name);
          if (item.isDirectory()) {
            files.push(...getFiles(fullPath));
          } else if (item.name.endsWith('.tsx') || item.name.endsWith('.ts') || item.name.endsWith('.css')) {
            files.push(fullPath.replace(srcDir, ''));
          }
        }
        return files;
      };
      res.json({ files: getFiles(srcDir) });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to list files" });
    }
  });

  app.get("/api/files/content", (req, res) => {
    try {
      const filePath = req.query.path as string;
      if (!filePath) return res.status(400).json({ error: "Path required" });
      const fullPath = path.join(process.cwd(), 'src', filePath);
      if (!fullPath.startsWith(path.join(process.cwd(), 'src'))) {
        return res.status(403).json({ error: "Invalid path" });
      }
      const content = fs.readFileSync(fullPath, 'utf8');
      res.json({ content });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to read file" });
    }
  });

  app.post("/api/files/content", (req, res) => {
    try {
      const { path: filePath, content } = req.body;
      if (!filePath || content === undefined) return res.status(400).json({ error: "Path and content required" });
      const fullPath = path.join(process.cwd(), 'src', filePath);
      if (!fullPath.startsWith(path.join(process.cwd(), 'src'))) {
        return res.status(403).json({ error: "Invalid path" });
      }
      fs.writeFileSync(fullPath, content, 'utf8');
      res.json({ success: true });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to write file" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
