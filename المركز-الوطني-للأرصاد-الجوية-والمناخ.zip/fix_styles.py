import os
import glob
import re

html_files = glob.glob('public/pages/*.html')
if 'public/pages/map1.html' in html_files:
    html_files.remove('public/pages/map1.html')
if 'public/pages/specialized_library.html' in html_files:
    html_files.remove('public/pages/specialized_library.html')
if 'public/pages/climate_library.html' in html_files:
    html_files.remove('public/pages/climate_library.html')

dark_style = """
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --bg: #0b0f19; --card-bg: #161a27; --text: #e2e8f0; --accent: #3b82f6; --accent-hover: #2563eb; --border: rgba(255,255,255,0.1); }
        * { box-sizing: border-box; font-family: 'Cairo', sans-serif; }
        body { background-color: var(--bg); color: var(--text); margin: 0; padding: 0; min-height: 100vh; display: flex; flex-direction: column; }
        .header { background: linear-gradient(135deg, rgba(15,23,42,0.8), rgba(22,26,39,0.9)); padding: 40px 20px; text-align: center; border-bottom: 1px solid var(--border); }
        .header h1 { font-size: 2.2rem; margin: 0 0 10px 0; color: #fff; font-weight: 700; text-shadow: 0 2px 10px rgba(0,0,0,0.5); }
        .header p { color: #94a3b8; font-size: 1.1rem; margin: 0; }
        .container { max-width: 1200px; margin: 0 auto; padding: 40px 20px; }
        .row { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px; }
        .task-card, .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 16px; padding: 25px; transition: transform 0.3s, box-shadow 0.3s; }
        .task-card:hover, .card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.4); border-color: rgba(59, 130, 246, 0.4); }
        .card-header, .card h3 { display: flex; align-items: center; gap: 12px; font-size: 1.25rem; font-weight: 700; color: #fff; margin-bottom: 15px; border-bottom: 1px solid var(--border); padding-bottom: 12px; }
        .card-header i, .card h3 i { color: var(--accent); font-size: 1.5rem; }
        .emergency .card-header i { color: #ef4444; }
        p, li { color: #cbd5e1; line-height: 1.7; font-size: 1rem; }
        ul { list-style: none; padding: 0; }
        ul li { position: relative; padding-right: 25px; margin-bottom: 10px; }
        ul li::before { content: "•"; color: var(--accent); position: absolute; right: 0; font-size: 1.2rem; font-weight: bold; }
    </style>
"""

for file in html_files:
    try:
        with open(file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Remove old styles and links
        content = re.sub(r'<style>.*?</style>', '', content, flags=re.DOTALL)
        content = re.sub(r'<link.*?bootstrap.*?>', '', content, flags=re.IGNORECASE)
        
        # Inject new style before </head>
        content = content.replace('</head>', dark_style + '\n</head>')
        
        # Remove bootstrap classes from body/main to avoid conflicts or just let CSS grid override
        content = content.replace('class="row"', 'class="row"')
        content = content.replace('class="container"', 'class="container"')
        
        with open(file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Updated {file}")
    except Exception as e:
        print(f"Error updating {file}: {e}")

