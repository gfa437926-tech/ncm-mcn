import re
with open('src/index.css', 'r') as f:
    content = f.read()

content = re.sub(r'body \{.*?\}', 'body {\n  margin: 0;\n  padding: 0;\n  background: radial-gradient(circle at top right, #1e293b, #0f172a, #020617);\n  background-attachment: fixed;\n  color: #f8fafc;\n}', content, count=1, flags=re.DOTALL)
content = re.sub(r'body \{\n  background: radial-gradient.*?\}', '', content, flags=re.DOTALL)

with open('src/index.css', 'w') as f:
    f.write(content)
