with open('src/App.tsx', 'r') as f:
    content = f.read()

content = content.replace("const [error, setError] = useState('');", "const [error, setError] = useState('');\n  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);")

with open('src/App.tsx', 'w') as f:
    f.write(content)
