import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

import_statement = "import ClimateLibraryView from './components/views/ClimateLibraryView';\nimport SpecializedLibraryView from './components/views/SpecializedLibraryView';\n"
content = content.replace("import IframeRouteWrapper from", import_statement + "import IframeRouteWrapper from")

route_replacement = """      <Route path="/page/climate_library" element={
        <div className="pb-20 md:pb-0 h-full"><ClimateLibraryView /></div>
      } />
      <Route path="/page/specialized_library" element={
        <div className="pb-20 md:pb-0 h-full"><SpecializedLibraryView /></div>
      } />
      {/* Iframe Routes for all the static pages */}"""
content = content.replace("{/* Iframe Routes for all the static pages */}", route_replacement)

with open('src/App.tsx', 'w') as f:
    f.write(content)
