import { GoogleGenAI } from "@google/genai";
async function run() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  try {
    const interaction = await ai.interactions.create({
        model: "gemini-3.6-flash",
        input: [{ type: "text", text: "Hello" }],
        system_instruction: "You are a test.",
        tools: [
          { type: 'google_search' },
          { type: 'google_maps' }
        ]
      });
      console.log(interaction.output_text);
  } catch(e) {
    console.error(e);
  }
}
run();
