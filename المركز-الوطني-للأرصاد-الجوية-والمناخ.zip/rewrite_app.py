import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

replacement = """  const routes = (
    <Routes>
      <Route path="/" element={<Navigate to="/weather" replace />} />
      <Route path="/weather" element={
        <div className="max-w-7xl mx-auto w-full animate-in fade-in duration-500">
          <div className="hidden md:block">
            <WeatherDashboard 
              data={weatherData} 
              cities={SYRIAN_CITIES}
              selectedCity={selectedCity}
              onCityChange={setSelectedCity}
              loading={loading}
            />
            <div className="mt-8">
              <NewsFeed news={MOCK_NEWS} />
            </div>
          </div>
          <div className="block md:hidden pb-20">
            <MobileWeatherDashboard 
              data={weatherData} 
              cities={SYRIAN_CITIES}
              selectedCity={selectedCity}
              onCityChange={setSelectedCity}
            />
          </div>
        </div>
      } />
      
      <Route path="/map" element={
        <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl overflow-hidden h-[90vh] border border-white/5 shadow-2xl flex flex-col pb-20 md:pb-0">
          <SyriaMapView />
        </div>
      } />
      <Route path="/alerts" element={<AlertsView />} />
      <Route path="/gis" element={<GISView />} />
      <Route path="/services" element={<div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white pb-20 md:pb-0"><h2 className="text-2xl font-bold mb-4">خدماتنا</h2><p>الخدمات متوفرة قريباً</p></div>} />
      <Route path="/forecasts" element={<ForecastsTable />} />
      <Route path="/forecasts/:type" element={<ForecastsTable />} />
      <Route path="/satellite" element={<ECMWFMap />} />
      <Route path="/route" element={<RouteMapView />} />
      <Route path="/stations" element={<div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white w-full h-[85vh] pb-20 md:pb-0"><iframe src="/pages/stations.html" className="w-full h-full rounded-2xl border-none"></iframe></div>} />
      <Route path="/stations-list" element={<div className="pb-20 md:pb-0 h-full"><StationsTab /></div>} />
      <Route path="/about" element={<div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white pb-20 md:pb-0"><h2 className="text-2xl font-bold mb-4">معلوماتنا</h2><p>معلومات المركز الوطني</p></div>} />
      <Route path="/marine" element={<div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white pb-20 md:pb-0"><h2 className="text-2xl font-bold mb-4">الاشعارات الملاحية</h2><p>الاشعارات الملاحية</p></div>} />
      <Route path="/knowledge" element={
        <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl pb-20 md:pb-0">
          <KnowledgeBaseView />
        </div>
      } />
      <Route path="/library" element={
        <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-2 md:p-6 border border-white/5 shadow-2xl pb-20 md:pb-0">
          <LibraryView />
        </div>
      } />
      {/* Iframe Routes for all the static pages */}
      <Route path="/page/:pageName" element={
        <div className="pb-20 md:pb-0 h-full"><IframeRouteWrapper /></div>
      } />
      <Route path="/request-data" element={
        <div className="pb-20 md:pb-0 h-full"><DataRequestView /></div>
      } />
    </Routes>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0b0f19] to-[#131620] font-sans text-white" dir="rtl">
      {/* Unified Layout */}
      <div className="flex flex-col min-h-screen relative">
        <Header />
        
        <main className="flex flex-1 max-w-[1920px] mx-auto w-full relative">
          <div className="hidden md:block">
            <Sidebar />
          </div>
          <div className="flex-1 overflow-x-hidden flex flex-col p-4 md:p-6 pb-24 md:pb-6">
            {routes}
          </div>
        </main>
        
        {isHome && <div className="hidden md:block"><Footer /></div>}
        
        {/* Mobile Bottom Navigation */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#1e2338]/90 backdrop-blur-lg border-t border-white/10 flex justify-around items-center p-3 z-50">
          <Link to="/weather" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/weather') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Sun size={20} />
            <span className="text-[10px]">الرئيسية</span>
          </Link>
          <Link to="/map" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/map') ? 'text-blue-400' : 'text-gray-400'}`}>
            <MapPin size={20} />
            <span className="text-[10px]">الخريطة</span>
          </Link>
          <Link to="/route" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/route') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Map size={20} />
            <span className="text-[10px]">المسار</span>
          </Link>
          <Link to="/stations-list" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/stations') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Activity size={20} />
            <span className="text-[10px]">المحطات</span>
          </Link>
        </div>
      </div>
    </div>
  );
}"""

pattern = re.compile(r'  const isHome = location\.pathname === \'/\' \|\| location\.pathname === \'/weather\';\n\n  return \(.*?</main>\n        \n        \{isHome && <Footer />\}\n      </div>\n    </div>\n  \);\n}', re.DOTALL)
new_content = pattern.sub(replacement, content)

with open('src/App.tsx', 'w') as f:
    f.write(new_content)
