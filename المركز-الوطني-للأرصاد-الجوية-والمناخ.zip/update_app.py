import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

replacement = """  const [cities, setCities] = useState<City[]>(SYRIAN_CITIES);
  const [selectedCity, setSelectedCity] = useState<City>(SYRIAN_CITIES[0]);
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCities = async () => {
      try {
        const res = await fetch('/api/stations');
        const data = await res.json();
        if (data.status === 'ok' && data.data && data.data.length > 0) {
          const fetchedCities = data.data.map((station: any) => ({
            id: station._id,
            name: station.name,
            lat: station.location?.coordinates[1] || 33.5,
            lng: station.location?.coordinates[0] || 36.3
          }));
          setCities(fetchedCities);
          setSelectedCity(fetchedCities[0]);
        }
      } catch (err) {
        console.error("Failed to fetch cities from MongoDB", err);
      }
    };
    fetchCities();
  }, []);

  useEffect(() => {
    const loadWeather = async () => {
      if (!selectedCity) return;
"""

pattern = re.compile(r'  const \[selectedCity, setSelectedCity\] = useState<City>\(SYRIAN_CITIES\[0\]\);\n  const \[weatherData, setWeatherData\] = useState<WeatherData \| null>\(null\);\n  const \[loading, setLoading\] = useState\(true\);\n  const \[error, setError\] = useState<string \| null>\(null\);\n\n  useEffect\(\(\) => \{\n    const loadWeather = async \(\) => \{', re.DOTALL)

new_content = pattern.sub(replacement, content)

new_content = new_content.replace('cities={SYRIAN_CITIES}', 'cities={cities}')

with open('src/App.tsx', 'w') as f:
    f.write(new_content)
