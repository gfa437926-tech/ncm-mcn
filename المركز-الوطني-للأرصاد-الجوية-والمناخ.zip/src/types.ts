export interface WeatherData {
  current: {
    temp: number;
    condition: string;
    feelsLike: number;
    windSpeed: number;
    windDirection: number;
    humidity: number;
    pressure: number;
    visibility: number;
    uvIndex: number;
    dewPoint: number;
    cloudCover: number;
    airQuality?: number;
    isDay: boolean;
    icon: any; // Lucide icon
    location: string;
  };
  sunAndMoon: {
    sunrise: string;
    sunset: string;
  };
  hourly: Array<{
    time: string;
    temp: number;
    condition: string;
    icon: any;
    isDay: boolean;
    precipitationProbability: number;
    windSpeed?: number;
    humidity?: number;
    cloudCover?: number;
    pressure?: number;
    uvIndex?: number;
    visibility?: number;
    feelsLike?: number;
    airQuality?: number;
    dewPoint?: number;
  }>;
  daily: Array<{
    date: string;
    dayName: string;
    maxTemp: number;
    minTemp: number;
    condition: string;
    icon: any;
    precipitationChance: number;
    uvIndex?: number;
  }>;
}

export interface NewsItem {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  imageUrl: string;
}

export interface CapAlert {
  id: string;
  headline: string;
  event: string;
  severity: string;
  description: string;
  instruction?: string;
  effective: string;
  expires: string;
}

export interface City {
  id: string;
  name: string;
  lat: number;
  lng: number;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  size: string;
  img: string;
  category: string;
  pages: number;
  published: string;
  content: string; // The text or abstract
}
