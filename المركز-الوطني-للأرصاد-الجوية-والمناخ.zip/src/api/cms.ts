import express from 'express';
import { getDatabase } from './db.js';

export const cmsRouter = express.Router();
const db = getDatabase();

// Pages
cmsRouter.get('/pages', async (req, res) => {
  try {
    const pages = await db.getPages();
    res.json({ status: 'ok', data: pages });
  } catch (err) { res.status(500).json({ error: 'Failed' }); }
});

cmsRouter.get('/pages/:id', async (req, res) => {
  try {
    const page = await db.getPage(req.params.id);
    if (!page) return res.status(404).json({ error: 'Not found' });
    res.json({ status: 'ok', data: page });
  } catch (err) { res.status(500).json({ error: 'Failed' }); }
});

cmsRouter.put('/pages/:id', express.json(), async (req, res) => {
  try {
    const success = await db.updatePage(req.params.id, req.body);
    res.json({ status: 'ok', success });
  } catch (err) { res.status(500).json({ error: 'Failed' }); }
});

// News
cmsRouter.get('/news', async (req, res) => {
  try { res.json({ status: 'ok', data: await db.getNews() }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});
cmsRouter.post('/news', express.json(), async (req, res) => {
  try { res.json({ status: 'ok', data: await db.addNews(req.body) }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});
cmsRouter.put('/news/:id', express.json(), async (req, res) => {
  try { res.json({ status: 'ok', success: await db.updateNews(req.params.id, req.body) }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});
cmsRouter.delete('/news/:id', async (req, res) => {
  try { res.json({ status: 'ok', success: await db.deleteNews(req.params.id) }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});

// Photos
cmsRouter.get('/photos', async (req, res) => {
  try { res.json({ status: 'ok', data: await db.getPhotos() }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});
cmsRouter.post('/photos', express.json(), async (req, res) => {
  try { res.json({ status: 'ok', data: await db.addPhoto(req.body) }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});
cmsRouter.delete('/photos/:id', async (req, res) => {
  try { res.json({ status: 'ok', success: await db.deletePhoto(req.params.id) }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});

// Videos
cmsRouter.get('/videos', async (req, res) => {
  try { res.json({ status: 'ok', data: await db.getVideos() }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});
cmsRouter.post('/videos', express.json(), async (req, res) => {
  try { res.json({ status: 'ok', data: await db.addVideo(req.body) }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});
cmsRouter.delete('/videos/:id', async (req, res) => {
  try { res.json({ status: 'ok', success: await db.deleteVideo(req.params.id) }); } catch (err) { res.status(500).json({ error: 'Failed' }); }
});
