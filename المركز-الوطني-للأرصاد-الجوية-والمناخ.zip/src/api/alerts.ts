import express from 'express';
import { randomUUID } from 'crypto';

export const alertsRouter = express.Router();

interface Alert {
  id: string;
  title: string;
  description: string;
  severity: 'Extreme' | 'Severe' | 'Moderate' | 'Minor';
  timestamp: string;
}

let activeAlerts: Alert[] = [];
const clients: express.Response[] = [];

// SSE stream for alerts
alertsRouter.get('/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  clients.push(res);
  
  // Send initial connected event
  res.write(`data: ${JSON.stringify({ type: 'connected' })}\n\n`);

  // Remove client on close
  req.on('close', () => {
    const idx = clients.indexOf(res);
    if (idx !== -1) {
      clients.splice(idx, 1);
    }
  });
});

// Broadcast a new alert
alertsRouter.post('/trigger', express.json(), (req, res) => {
  const { title, description, severity } = req.body;
  
  const newAlert: Alert = {
    id: randomUUID(),
    title: title || 'تحذير جديد',
    description: description || 'تفاصيل التحذير غير متوفرة',
    severity: severity || 'Severe',
    timestamp: new Date().toISOString()
  };
  
  activeAlerts.unshift(newAlert);
  // Keep only the latest 10 alerts
  if (activeAlerts.length > 10) activeAlerts.pop();

  // Notify all connected clients
  clients.forEach(client => {
    client.write(`data: ${JSON.stringify({ type: 'new_alert', alert: newAlert })}\n\n`);
  });

  res.json({ status: 'ok', alert: newAlert });
});

alertsRouter.get('/', (req, res) => {
  res.json({ status: 'ok', data: activeAlerts });
});
