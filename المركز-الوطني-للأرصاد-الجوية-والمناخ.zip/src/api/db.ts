import fs from 'fs';
import path from 'path';

export interface ContentProvider {
  getPages(): Promise<any>;
  getPage(pageId: string): Promise<any>;
  updatePage(pageId: string, data: any): Promise<boolean>;
  
  getNews(): Promise<any[]>;
  addNews(item: any): Promise<any>;
  updateNews(id: string, item: any): Promise<boolean>;
  deleteNews(id: string): Promise<boolean>;

  getPhotos(): Promise<any[]>;
  addPhoto(item: any): Promise<any>;
  deletePhoto(id: string): Promise<boolean>;

  getVideos(): Promise<any[]>;
  addVideo(item: any): Promise<any>;
  deleteVideo(id: string): Promise<boolean>;
}

export class SupabaseProvider implements ContentProvider {
  async getPages() { throw new Error("Not implemented"); }
  async getPage(id: string) { throw new Error("Not implemented"); }
  async updatePage(id: string, data: any): Promise<boolean> { throw new Error("Not implemented"); }
  async getNews() { return []; }
  async addNews(item: any) { return item; }
  async updateNews(id: string, item: any): Promise<boolean> { return false; }
  async deleteNews(id: string): Promise<boolean> { return false; }
  async getPhotos() { return []; }
  async addPhoto(item: any) { return item; }
  async deletePhoto(id: string): Promise<boolean> { return false; }
  async getVideos() { return []; }
  async addVideo(item: any) { return item; }
  async deleteVideo(id: string): Promise<boolean> { return false; }
}

export class MongoDBProvider implements ContentProvider {
  async getPages() { throw new Error("Not implemented"); }
  async getPage(id: string) { throw new Error("Not implemented"); }
  async updatePage(id: string, data: any): Promise<boolean> { throw new Error("Not implemented"); }
  async getNews() { return []; }
  async addNews(item: any) { return item; }
  async updateNews(id: string, item: any): Promise<boolean> { return false; }
  async deleteNews(id: string): Promise<boolean> { return false; }
  async getPhotos() { return []; }
  async addPhoto(item: any) { return item; }
  async deletePhoto(id: string): Promise<boolean> { return false; }
  async getVideos() { return []; }
  async addVideo(item: any) { return item; }
  async deleteVideo(id: string): Promise<boolean> { return false; }
}

export class LocalJSONProvider implements ContentProvider {
  private getFilePath(filename: string) {
    const basePath = path.join(process.cwd(), 'src', 'data');
    if (!fs.existsSync(basePath)) fs.mkdirSync(basePath, { recursive: true });
    return path.join(basePath, filename);
  }

  private readDb(filename: string) {
    const file = this.getFilePath(filename);
    if (fs.existsSync(file)) {
      try {
        return JSON.parse(fs.readFileSync(file, 'utf-8'));
      } catch (e) { return null; }
    }
    return null;
  }

  private writeDb(filename: string, data: any) {
    fs.writeFileSync(this.getFilePath(filename), JSON.stringify(data, null, 2));
  }

  async getPages() {
    return this.readDb('pagesData.json') || {};
  }
  
  async getPage(id: string) {
    const pages = await this.getPages();
    return pages[id] || null;
  }
  
  async updatePage(id: string, data: any) {
    const pages = await this.getPages();
    pages[id] = data;
    this.writeDb('pagesData.json', pages);
    return true;
  }
  
  private initMediaDb() {
    const data = this.readDb('mediaDb.json');
    if (!data) {
      const initial = {
        news: [
          { _id: "1", title: "المركز الوطني يحذر من موجة حر شديدة", content: "يتوقع أن تضرب البلاد موجة حر شديدة خلال الأيام القادمة، ويرجى أخذ الحيطة والحذر.", date: new Date().toISOString(), imageUrl: "https://images.unsplash.com/photo-1504386106331-3e4e71712b38?w=800&q=80" }
        ],
        photos: [
          { _id: "1", title: "غيوم ركامية فوق الساحل", url: "https://images.unsplash.com/photo-1534088568595-a066f410cbda?w=800&q=80" }
        ],
        videos: [
          { _id: "1", title: "كيفية تشكل العواصف", url: "https://www.youtube.com/embed/dQw4w9WgXcQ", thumbnailUrl: "https://images.unsplash.com/photo-1492011221367-f47e3ccd77a0?w=800&q=80" }
        ]
      };
      this.writeDb('mediaDb.json', initial);
      return initial;
    }
    return data;
  }

  async getNews() { return this.initMediaDb().news || []; }
  async addNews(item: any) {
    const db = this.initMediaDb();
    item._id = Date.now().toString();
    item.date = item.date || new Date().toISOString();
    db.news.unshift(item);
    this.writeDb('mediaDb.json', db);
    return item;
  }
  async updateNews(id: string, item: any) {
    const db = this.initMediaDb();
    const idx = db.news.findIndex((n: any) => n._id === id);
    if (idx !== -1) {
      db.news[idx] = { ...db.news[idx], ...item };
      this.writeDb('mediaDb.json', db);
      return true;
    }
    return false;
  }
  async deleteNews(id: string) {
    const db = this.initMediaDb();
    db.news = db.news.filter((n: any) => n._id !== id);
    this.writeDb('mediaDb.json', db);
    return true;
  }

  async getPhotos() { return this.initMediaDb().photos || []; }
  async addPhoto(item: any) {
    const db = this.initMediaDb();
    item._id = Date.now().toString();
    db.photos.unshift(item);
    this.writeDb('mediaDb.json', db);
    return item;
  }
  async deletePhoto(id: string) {
    const db = this.initMediaDb();
    db.photos = db.photos.filter((p: any) => p._id !== id);
    this.writeDb('mediaDb.json', db);
    return true;
  }

  async getVideos() { return this.initMediaDb().videos || []; }
  async addVideo(item: any) {
    const db = this.initMediaDb();
    item._id = Date.now().toString();
    db.videos.unshift(item);
    this.writeDb('mediaDb.json', db);
    return item;
  }
  async deleteVideo(id: string) {
    const db = this.initMediaDb();
    db.videos = db.videos.filter((v: any) => v._id !== id);
    this.writeDb('mediaDb.json', db);
    return true;
  }
}

export function getDatabase(): ContentProvider {
  const dbType = process.env.DB_TYPE || 'local';
  if (dbType === 'supabase') return new SupabaseProvider();
  if (dbType === 'mongodb') return new MongoDBProvider();
  return new LocalJSONProvider();
}
