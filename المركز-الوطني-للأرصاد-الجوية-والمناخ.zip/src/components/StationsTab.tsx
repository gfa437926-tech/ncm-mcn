import React from 'react';

export default function StationsTab() {
  return (
    <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white w-full h-[85vh] animate-in fade-in duration-500">
      <h2 className="text-2xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-l from-white to-gray-400">قائمة المحطات</h2>
      <iframe 
        src="/pages/stations.html" 
        className="w-full h-full rounded-2xl border-none shadow-inner bg-[#0b0f19]/50"
        title="Stations"
      />
    </div>
  );
}
