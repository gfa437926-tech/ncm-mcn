import React from 'react';

export default function ECMWFMap() {
  return (
    <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white w-full h-[85vh] animate-in fade-in duration-500 flex flex-col">
      <h2 className="text-2xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-l from-white to-gray-400">خرائط ECMWF المباشرة</h2>
      <div className="flex-1 w-full rounded-2xl overflow-hidden shadow-inner border border-white/10 relative">
        <iframe 
          src="https://embed.windy.com/embed.html?type=map&location=coordinates&metricRain=mm&metricTemp=°C&metricWind=km/h&zoom=6&overlay=wind&product=ecmwf&level=surface&lat=34.8&lon=38.9"
          className="absolute inset-0 w-full h-full border-none"
          title="ECMWF Map"
        />
      </div>
    </div>
  );
}
