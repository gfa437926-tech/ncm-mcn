import React, { useState } from 'react';
import { Bell, BellRing, BellOff } from 'lucide-react';
import { useAlertNotifications } from '../hooks/useAlertNotifications';

export default function NotificationBell() {
  const { permission, requestPermission } = useAlertNotifications();
  const [loading, setLoading] = useState(false);

  const handleToggle = async () => {
    if (permission === 'granted') {
      // Browsers don't allow revoking permission via JS once granted.
      alert('تم تفعيل الإشعارات. يمكنك إيقافها من إعدادات المتصفح.');
      return;
    }
    
    if (permission === 'denied') {
      alert('تم حظر الإشعارات مسبقاً. يرجى تفعيلها من إعدادات المتصفح للحصول على تنبيهات الطقس العاجلة.');
      return;
    }

    setLoading(true);
    await requestPermission();
    setLoading(false);
  };

  return (
    <button 
      onClick={handleToggle}
      disabled={loading}
      className={`flex items-center gap-1.5 px-2 py-1 rounded-md transition-colors font-bold text-xs ${
        permission === 'granted' 
          ? 'text-blue-400 bg-blue-500/10 hover:bg-blue-500/20' 
          : permission === 'denied'
          ? 'text-red-400 bg-red-500/10'
          : 'text-gray-400 hover:text-white bg-white/5 hover:bg-white/10'
      }`}
      title="إشعارات التنبيهات العاجلة"
    >
      {permission === 'granted' ? (
        <><BellRing size={14} className="animate-pulse" /> مفعلة</>
      ) : permission === 'denied' ? (
        <><BellOff size={14} /> محظورة</>
      ) : (
        <><Bell size={14} /> تفعيل التنبيهات</>
      )}
    </button>
  );
}
