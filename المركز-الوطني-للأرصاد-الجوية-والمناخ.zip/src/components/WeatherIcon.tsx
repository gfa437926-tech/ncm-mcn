import { Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudMoon, CloudRain, CloudSnow, CloudSun, Moon, Snowflake, Sun } from 'lucide-react';
import { motion } from 'framer-motion';

interface WeatherIconProps {
  status: string;
  className?: string;
  size?: number;
}

export default function WeatherIcon({ status, className = "", size = 32 }: WeatherIconProps) {
  switch (status) {
    case 'clear-day':
      return (
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 15, repeat: Infinity, ease: "linear" }} className={className}>
          <Sun size={size} className="text-yellow-400" fill="currentColor" />
        </motion.div>
      );
    case 'clear-night':
      return (
        <motion.div animate={{ rotate: [-5, 5] }} transition={{ duration: 4, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }} className={className}>
          <Moon size={size} className="text-blue-300" fill="currentColor" />
        </motion.div>
      );
    case 'partly-cloudy-day':
      return (
        <div className={`relative ${className}`} style={{ width: size, height: size }}>
          <motion.div animate={{ x: [-2, 2] }} transition={{ duration: 3, repeat: Infinity, repeatType: "reverse" }} className="absolute top-0 right-0">
            <Sun size={size * 0.7} className="text-yellow-400" fill="currentColor" />
          </motion.div>
          <motion.div animate={{ x: [2, -2] }} transition={{ duration: 4, repeat: Infinity, repeatType: "reverse" }} className="absolute bottom-0 left-0">
            <Cloud size={size * 0.8} className="text-white" fill="currentColor" />
          </motion.div>
        </div>
      );
    case 'partly-cloudy-night':
      return (
        <div className={`relative ${className}`} style={{ width: size, height: size }}>
          <motion.div animate={{ rotate: [-5, 5] }} transition={{ duration: 4, repeat: Infinity, repeatType: "reverse" }} className="absolute top-0 right-0">
            <Moon size={size * 0.7} className="text-blue-300" fill="currentColor" />
          </motion.div>
          <motion.div animate={{ x: [2, -2] }} transition={{ duration: 4, repeat: Infinity, repeatType: "reverse" }} className="absolute bottom-0 left-0">
            <Cloud size={size * 0.8} className="text-white" fill="currentColor" />
          </motion.div>
        </div>
      );
    case 'cloudy':
      return (
        <motion.div animate={{ x: [-3, 3] }} transition={{ duration: 5, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }} className={className}>
          <Cloud size={size} className="text-gray-300" fill="currentColor" />
        </motion.div>
      );
    case 'fog':
      return (
        <motion.div animate={{ opacity: [0.7, 1] }} transition={{ duration: 3, repeat: Infinity, repeatType: "reverse" }} className={className}>
          <CloudFog size={size} className="text-gray-400" />
        </motion.div>
      );
    case 'rain':
      return (
        <motion.div animate={{ y: [-2, 2] }} transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }} className={className}>
          <CloudRain size={size} className="text-blue-400" fill="currentColor" />
        </motion.div>
      );
    case 'snow':
      return (
        <motion.div animate={{ y: [-2, 2], rotate: [-10, 10] }} transition={{ duration: 3, repeat: Infinity, repeatType: "reverse" }} className={className}>
          <CloudSnow size={size} className="text-blue-100" fill="currentColor" />
        </motion.div>
      );
    case 'thunderstorm':
      return (
        <motion.div animate={{ scale: [1, 1.05] }} transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }} className={className}>
          <CloudLightning size={size} className="text-purple-400" fill="currentColor" />
        </motion.div>
      );
    default:
      return <Sun size={size} className={`text-yellow-400 ${className}`} fill="currentColor" />;
  }
}
