import React, { useState, useEffect } from 'react';
import { Newspaper, Image as ImageIcon, Video as VideoIcon, ArrowLeft, Clock } from 'lucide-react';

interface NewsItem {
  _id: string;
  title: string;
  content: string;
  date: string;
  imageUrl?: string;
  source?: string;
}

interface PhotoItem {
  _id: string;
  title: string;
  url: string;
  description?: string;
}

interface VideoItem {
  _id: string;
  title: string;
  url: string;
  thumbnailUrl?: string;
  description?: string;
}

export default function MediaSection() {
  const [activeTab, setActiveTab] = useState<'news' | 'photos' | 'videos'>('news');
  const [news, setNews] = useState<NewsItem[]>([]);
  const [photos, setPhotos] = useState<PhotoItem[]>([]);
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMedia = async () => {
      setLoading(true);
      try {
        const [newsRes, photosRes, videosRes] = await Promise.all([
          fetch('/api/cms/news').then(r => r.json()),
          fetch('/api/cms/photos').then(r => r.json()),
          fetch('/api/cms/videos').then(r => r.json())
        ]);
        
        if (newsRes.status === 'ok' || newsRes.status === 'mock') setNews(newsRes.data || []);
        if (photosRes.status === 'ok' || photosRes.status === 'mock') setPhotos(photosRes.data || []);
        if (videosRes.status === 'ok' || videosRes.status === 'mock') setVideos(videosRes.data || []);
      } catch (err) {
        console.error("Failed to fetch media:", err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchMedia();
  }, []);

  const TabButton = ({ id, label, icon: Icon }: { id: 'news' | 'photos' | 'videos', label: string, icon: any }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold transition-all ${
        activeTab === id 
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25' 
          : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
      }`}
    >
      <Icon size={20} />
      {label}
    </button>
  );

  return (
    <section className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 md:p-8 border border-white/5 shadow-2xl">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-6">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">المركز الإعلامي</h2>
          <p className="text-gray-400">أحدث الأخبار والصور والفيديوهات الخاصة بالمركز</p>
        </div>
        <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
          <TabButton id="news" label="الأخبار" icon={Newspaper} />
          <TabButton id="photos" label="الصور" icon={ImageIcon} />
          <TabButton id="videos" label="الفيديوهات" icon={VideoIcon} />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
        </div>
      ) : (
        <div className="min-h-[400px]">
          {/* News Tab */}
          {activeTab === 'news' && (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              {news.length > 0 ? news.map((item) => (
                <article key={item._id} className="group cursor-pointer bg-[#1e2338] rounded-2xl overflow-hidden border border-white/5 hover:border-blue-500/30 transition-all">
                  {item.imageUrl && (
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={item.imageUrl} 
                        alt={item.title}
                        className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#1e2338] to-transparent"></div>
                    </div>
                  )}
                  <div className="p-6">
                    <div className="flex items-center gap-2 text-xs text-blue-400 mb-3 font-medium">
                      <Clock size={14} />
                      <span>{new Date(item.date).toLocaleDateString('ar-SA')}</span>
                      {item.source && <span className="px-2 py-1 bg-blue-500/10 rounded-full">{item.source}</span>}
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3 group-hover:text-blue-400 transition-colors line-clamp-2">
                      {item.title}
                    </h3>
                    <p className="text-gray-400 text-sm line-clamp-3 leading-relaxed">
                      {item.content}
                    </p>
                  </div>
                </article>
              )) : (
                <div className="col-span-full py-12 text-center text-gray-500">لا توجد أخبار حالياً</div>
              )}
            </div>
          )}

          {/* Photos Tab */}
          {activeTab === 'photos' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              {photos.length > 0 ? photos.map((item) => (
                <div key={item._id} className="group relative rounded-2xl overflow-hidden cursor-pointer aspect-square bg-[#1e2338] border border-white/5">
                  <img src={item.url} alt={item.title} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="text-xl font-bold text-white mb-1">{item.title}</h3>
                    {item.description && <p className="text-gray-300 text-sm line-clamp-2">{item.description}</p>}
                  </div>
                </div>
              )) : (
                <div className="col-span-full py-12 text-center text-gray-500">لا توجد صور حالياً</div>
              )}
            </div>
          )}

          {/* Videos Tab */}
          {activeTab === 'videos' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              {videos.length > 0 ? videos.map((item) => (
                <div key={item._id} className="bg-[#1e2338] rounded-2xl overflow-hidden border border-white/5 group">
                  <div className="relative aspect-video bg-black">
                    {item.url.includes('youtube.com') || item.url.includes('youtu.be') ? (
                      <iframe 
                        src={item.url} 
                        className="w-full h-full border-0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowFullScreen
                      ></iframe>
                    ) : (
                      <video 
                        src={item.url} 
                        poster={item.thumbnailUrl}
                        controls 
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                    {item.description && <p className="text-gray-400 text-sm">{item.description}</p>}
                  </div>
                </div>
              )) : (
                <div className="col-span-full py-12 text-center text-gray-500">لا توجد فيديوهات حالياً</div>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  );
}
