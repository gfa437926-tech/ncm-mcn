import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { Thermometer, Wind, Droplets, Snowflake } from 'lucide-react';

const iceData = Array.from({ length: 20 }, (_, i) => ({
  time: i,
  val: Math.sin(i / 3) * 10 + 20 - i
}));

export default function GlobalMapView() {
  return (
    <div className="flex flex-col gap-4 p-4 pb-24 max-w-lg mx-auto w-full animate-in fade-in duration-500">
      
      {/* Layer Control */}
      <div className="flex flex-col gap-2 mb-2">
        <div className="flex justify-between items-center mb-1">
          <span className="text-xs text-gray-400">Layer Control</span>
          <span className="text-xs text-gray-400 flex items-center gap-2">Layer <div className="w-8 h-4 bg-blue-500 rounded-full relative"><div className="absolute right-1 top-0.5 w-3 h-3 bg-white rounded-full"></div></div></span>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          <button className="bg-[#2a1a1c] border border-[#4a2223] text-red-400 rounded-full px-3 py-1.5 text-xs flex items-center gap-1.5 whitespace-nowrap shrink-0">
            <Thermometer size={14} /> Temperature
          </button>
          <button className="bg-[#1a1d27] border border-[#2a2e3d] text-gray-400 rounded-full px-3 py-1.5 text-xs flex items-center gap-1.5 whitespace-nowrap shrink-0 hover:bg-[#2a2e3d]">
            <Wind size={14} /> CO2
          </button>
          <button className="bg-[#1a1d27] border border-[#2a2e3d] text-gray-400 rounded-full px-3 py-1.5 text-xs flex items-center gap-1.5 whitespace-nowrap shrink-0 hover:bg-[#2a2e3d]">
            <Droplets size={14} /> Sea Level
          </button>
          <button className="bg-[#1a1d27] border border-[#2a2e3d] text-blue-400 rounded-full px-3 py-1.5 text-xs flex items-center gap-1.5 whitespace-nowrap shrink-0 hover:bg-[#2a2e3d]">
            <Snowflake size={14} /> Ice Cover
          </button>
        </div>
      </div>

      {/* Earth Map Visual */}
      <div className="relative w-full aspect-square max-w-[320px] mx-auto mb-4">
        <div className="absolute inset-0 rounded-full shadow-[0_0_50px_rgba(59,130,246,0.2)] bg-blue-900/20 overflow-hidden flex items-center justify-center">
           {/* Placeholder for actual 3D Earth, using a static styling approach to mimic the globe */}
           <div className="w-full h-full rounded-full relative overflow-hidden bg-[#0f172a]">
             {/* Simple pseudo-map continents */}
             <div className="absolute top-[20%] left-[10%] w-[40%] h-[30%] bg-orange-500/40 blur-xl rounded-full mix-blend-screen"></div>
             <div className="absolute top-[30%] right-[15%] w-[50%] h-[40%] bg-red-500/50 blur-xl rounded-full mix-blend-screen"></div>
             <div className="absolute bottom-[20%] left-[30%] w-[60%] h-[20%] bg-blue-400/30 blur-xl rounded-full mix-blend-screen"></div>
             {/* Grid lines */}
             <div className="absolute inset-0 border border-white/10 rounded-full"></div>
             <div className="absolute inset-0 border border-white/10 rounded-full rotate-45 scale-y-50"></div>
             <div className="absolute inset-0 border border-white/10 rounded-full -rotate-45 scale-y-50"></div>
             <div className="absolute top-1/2 left-0 right-0 h-px bg-white/20"></div>
             <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/20"></div>
           </div>
        </div>
        <div className="absolute top-0 left-0 text-xs text-gray-200">
          Global Surface<br/>Temperature Anomalies
        </div>
        <div className="absolute bottom-4 right-0 text-xs text-gray-200 text-right">
          Ocean Currents
          <div className="flex items-center gap-1 mt-1 justify-end">
            <div className="w-24 h-1.5 bg-gradient-to-r from-blue-500 via-gray-500 to-red-500 rounded-full"></div>
            <Wind size={12} className="text-gray-400" />
          </div>
        </div>
      </div>

      {/* Global Insights */}
      <h3 className="text-sm text-gray-200 mb-2">Global Insights</h3>
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d]">
          <h4 className="text-[11px] text-gray-400 mb-1">Global Temp Pulse</h4>
          <div className="text-2xl font-bold text-orange-400">+1.1°C</div>
          <div className="text-[9px] text-gray-500 mt-1">+1.1°C above pre-industrial</div>
        </div>
        <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d] relative">
          <h4 className="text-[11px] text-gray-400 mb-1">Atmospheric CO2</h4>
          <div className="text-2xl font-bold text-white">421 <span className="text-sm text-gray-500 font-normal">ppm</span></div>
          <Wind size={20} className="text-gray-600 absolute bottom-4 right-4" />
        </div>
        <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d] col-span-2 flex items-center justify-between">
           <div>
             <h4 className="text-[11px] text-gray-400 mb-1">Sea Level Rise</h4>
             <div className="text-xl font-bold text-orange-400">+3.6 <span className="text-sm text-gray-500 font-normal">mm/year</span></div>
           </div>
        </div>
        <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d] col-span-2 flex items-center justify-between h-24">
           <div>
             <h4 className="text-[11px] text-gray-400 mb-1">Arctic Sea Ice Extent</h4>
           </div>
           <div className="w-1/2 h-full">
             <ResponsiveContainer width="100%" height="100%">
               <LineChart data={iceData}>
                 <Line type="monotone" dataKey="val" stroke="#3b82f6" strokeWidth={2} dot={false} />
               </LineChart>
             </ResponsiveContainer>
           </div>
        </div>
      </div>

    </div>
  );
}
