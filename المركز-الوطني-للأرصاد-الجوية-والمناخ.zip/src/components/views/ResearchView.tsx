import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { Download, RefreshCw, AlertCircle, Plus, ChevronDown, DownloadCloud } from 'lucide-react';

const timeSeriesData = [
  { time: '11:00', t1: 200, t2: 300, t3: 400 },
  { time: '13:00', t1: 300, t2: 450, t3: 350 },
  { time: '16:00', t1: 450, t2: 500, t3: 600 },
  { time: '19:00', t1: 350, t2: 400, t3: 500 },
  { time: '22:00', t1: 200, t2: 350, t3: 400 },
];

const aodData = Array.from({ length: 15 }, (_, i) => ({
  time: i,
  val: Math.random() * 0.4 + 0.1
}));

export default function ResearchView() {
  return (
    <div className="flex flex-col gap-4 p-4 pb-24 max-w-lg mx-auto w-full animate-in fade-in duration-500">
      
      {/* Station Selector */}
      <div className="flex flex-col gap-2">
        <span className="text-xs text-gray-400">Station Selector</span>
        <div className="flex gap-2">
          <div className="flex-1 bg-[#1a1d27] border border-[#2a2e3d] rounded-xl p-3 flex items-center justify-between">
            <span className="text-sm text-gray-200">Damascus Central (Active)</span>
            <ChevronDown size={16} className="text-gray-500" />
          </div>
          <button className="bg-[#1a1d27] border border-[#2a2e3d] rounded-xl px-4 flex items-center justify-center text-gray-300">
            Add
          </button>
          <button className="bg-[#1a1d27] border border-[#2a2e3d] rounded-xl w-12 flex items-center justify-center text-gray-300">
            <Plus size={16} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Comparative Time Series */}
        <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d] col-span-2 md:col-span-1">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm text-gray-200">Comparative Time Series</h3>
            <div className="flex gap-2">
               <span className="flex items-center gap-1 text-[10px] text-gray-400"><div className="w-2 h-2 rounded-full bg-red-400"></div>Temperature</span>
               <span className="flex items-center gap-1 text-[10px] text-gray-400"><div className="w-2 h-2 rounded-full bg-blue-400"></div>Humidity</span>
               <span className="flex items-center gap-1 text-[10px] text-gray-400"><div className="w-2 h-2 rounded-full bg-emerald-400"></div>Pressure</span>
            </div>
          </div>
          <div className="h-32 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeSeriesData}>
                <YAxis hide domain={['dataMin - 100', 'dataMax + 100']} />
                <Line type="monotone" dataKey="t1" stroke="#f87171" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="t2" stroke="#60a5fa" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="t3" stroke="#34d399" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-between text-[10px] text-gray-500 mt-2 border-b border-gray-800 pb-2">
            <span>11:00</span><span>13:00</span><span>16:00</span><span>19:00</span><span>22:00</span>
          </div>
          <div className="flex items-center gap-3 mt-2 text-[10px] text-gray-400">
            <span className="flex items-center gap-1"><div className="w-2 h-2 bg-red-400"></div>Damascus Central</span>
            <span className="flex items-center gap-1"><div className="w-2 h-2 bg-blue-400"></div>Airport</span>
            <span className="flex items-center gap-1"><div className="w-2 h-2 bg-emerald-400"></div>Rural</span>
          </div>
          <div className="text-[10px] text-gray-500 mt-1">Past 48 hours</div>
        </div>

        {/* SYNOP Data Decoder */}
        <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d] col-span-2 md:col-span-1">
          <h3 className="text-sm text-gray-200 mb-2">SYNOP Data Decoder</h3>
          <div className="text-xs text-gray-400 font-mono leading-relaxed mb-4">
            Damascus Central<br/>
            AAXX 12181 40107 11997...<br/>
            #215711Y709 SYNX 11997...<br/>
            11997 11110067 11997...<br/>
            11997 U U32 6:07 14097...
          </div>
          <div className="text-sm text-gray-200 grid grid-cols-2 gap-y-1">
            <span>P: 1014.2</span>
            <span>T: 18.2</span>
            <span>Td: 12.1</span>
            <span>W: 14 km/h</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* NDVI */}
        <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d] flex flex-col">
          <h3 className="text-[11px] text-gray-400 mb-2">Satellite Vegetation Index (NDVI)</h3>
          <div className="flex-1 bg-gray-800 rounded-lg overflow-hidden relative min-h-[100px]">
            <img src="https://images.unsplash.com/photo-1596306499300-0b7c013b14b1?w=400&q=80" alt="NDVI Map" className="w-full h-full object-cover opacity-60 mix-blend-luminosity" />
            <div className="absolute inset-0 bg-gradient-to-tr from-green-500/20 to-red-500/20"></div>
            <div className="absolute bottom-2 right-2 text-xl font-bold text-white">0.45</div>
            <div className="absolute bottom-2 left-2 flex gap-2">
              <button className="w-6 h-6 rounded-full bg-black/50 flex items-center justify-center text-white"><DownloadCloud size={12} /></button>
            </div>
          </div>
        </div>

        {/* AOD */}
        <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d] flex flex-col">
          <h3 className="text-[11px] text-gray-400 mb-2">Aerosol Optical Depth (AOD)</h3>
          <div className="flex-1 w-full min-h-[100px] flex items-end">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={aodData}>
                <Bar dataKey="val">
                  {aodData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.val > 0.3 ? '#10b981' : '#3b82f6'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-between items-center mt-2">
             <div className="flex gap-2">
              <button className="w-6 h-6 rounded-full bg-gray-800 flex items-center justify-center text-gray-400"><DownloadCloud size={12} /></button>
            </div>
            <span className="text-xl font-bold text-white">0.12</span>
          </div>
        </div>
      </div>

      {/* Data Integrity Log */}
      <div className="bg-[#1a1d27] rounded-2xl p-4 border border-[#2a2e3d]">
        <h3 className="text-sm text-gray-200 mb-3">Data Integrity Log</h3>
        <div className="flex flex-col gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-gray-400">Last SYNOP Sync:</span>
            <span className="text-white">2 mins ago</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">Sensor Status:</span>
            <span className="text-emerald-400">All Operational</span>
          </div>
        </div>
      </div>

    </div>
  );
}
