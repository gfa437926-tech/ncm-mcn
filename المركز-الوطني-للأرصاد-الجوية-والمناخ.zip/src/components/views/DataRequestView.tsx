import React, { useState } from 'react';
import { Send, CheckCircle2, AlertCircle } from 'lucide-react';

export default function DataRequestView() {
  const [formData, setFormData] = useState({
    name: '',
    dataType: '',
    purpose: '',
  });
  
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.dataType || !formData.purpose) {
      setStatus('error');
      return;
    }
    
    setStatus('submitting');
    
    // Simulate API call
    setTimeout(() => {
      setStatus('success');
      setFormData({ name: '', dataType: '', purpose: '' });
      
      // Reset success message after 3 seconds
      setTimeout(() => setStatus('idle'), 3000);
    }, 1500);
  };

  return (
    <div className="max-w-3xl mx-auto w-full animate-in fade-in duration-500 py-6">
      <div className="bg-[#161a27]/90 backdrop-blur-xl rounded-3xl p-8 border border-white/5 shadow-2xl relative overflow-hidden">
        
        {/* Ambient background glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-[80px] pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-[80px] pointer-events-none"></div>

        <div className="relative z-10">
          <h2 className="text-3xl font-bold text-white mb-2">طلب بيانات مناخية</h2>
          <p className="text-gray-400 mb-8">قم بتعبئة النموذج التالي للحصول على بيانات مناخية مخصصة لأغراضك البحثية أو التجارية.</p>

          {status === 'success' && (
            <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-3 text-emerald-400">
              <CheckCircle2 size={20} />
              <span>تم إرسال طلبك بنجاح! سيتم التواصل معك قريباً.</span>
            </div>
          )}

          {status === 'error' && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-400">
              <AlertCircle size={20} />
              <span>يرجى تعبئة جميع الحقول المطلوبة.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            
            <div className="space-y-2">
              <label htmlFor="name" className="block text-sm font-medium text-gray-300">
                الاسم الكامل <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-[#0b0f19] border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                placeholder="أدخل اسمك الكامل"
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="dataType" className="block text-sm font-medium text-gray-300">
                نوع البيانات المطلوبة <span className="text-red-400">*</span>
              </label>
              <select
                id="dataType"
                value={formData.dataType}
                onChange={(e) => setFormData({ ...formData, dataType: e.target.value })}
                className="w-full bg-[#0b0f19] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all appearance-none"
                style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'24\' height=\'24\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'white\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3E%3Cpath d=\'m6 9 6 6 6-6\'/%3E%3C/svg%3E")', backgroundPosition: 'left 1rem center', backgroundRepeat: 'no-repeat', backgroundSize: '1.2em' }}
              >
                <option value="" disabled className="text-gray-500">اختر نوع البيانات</option>
                <option value="historical">بيانات مناخية تاريخية</option>
                <option value="forecast">توقعات جوية طويلة الأمد</option>
                <option value="raw">بيانات خام من المحطات</option>
                <option value="custom">تحليل مناخي مخصص</option>
              </select>
            </div>

            <div className="space-y-2">
              <label htmlFor="purpose" className="block text-sm font-medium text-gray-300">
                الغرض من الاستخدام <span className="text-red-400">*</span>
              </label>
              <textarea
                id="purpose"
                rows={4}
                value={formData.purpose}
                onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                className="w-full bg-[#0b0f19] border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all resize-none"
                placeholder="يرجى وصف كيف سيتم استخدام هذه البيانات..."
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={status === 'submitting'}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 px-6 rounded-xl transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:shadow-[0_0_30px_rgba(37,99,235,0.5)] flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {status === 'submitting' ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  <Send size={18} />
                  <span>إرسال الطلب</span>
                </>
              )}
            </button>
            
          </form>
        </div>
      </div>
    </div>
  );
}
