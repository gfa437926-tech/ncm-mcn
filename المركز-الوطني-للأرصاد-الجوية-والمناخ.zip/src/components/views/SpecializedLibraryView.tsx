import React from 'react';
import { Book, Cpu, CloudRain, ShieldAlert, Navigation, Sun, Search, Download } from 'lucide-react';

export default function SpecializedLibraryView() {
  const books = [
    { title: 'Numerical Weather Prediction: Fundamentals', category: 'التنبؤ العددي', icon: Cpu, author: 'Thomas Warner' },
    { title: 'Guide to Instruments & Methods of Observation', category: 'أدوات الرصد', icon: CloudRain, author: 'WMO' },
    { title: 'Manual on Global Data-processing', category: 'معالجة البيانات', icon: Navigation, author: 'WMO' },
    { title: 'Practical Meteorology: An Algebra-based Survey', category: 'أساسيات الأرصاد', icon: Book, author: 'Roland Stull' },
    { title: 'Aviation Meteorology (Doc 8896)', category: 'أرصاد الطيران', icon: Navigation, author: 'ICAO / WMO' },
    { title: 'Climate Change 2022: Synthesis Report', category: 'التغير المناخي', icon: Sun, author: 'IPCC' },
  ];

  return (
    <div className="bg-[#1e2338] text-white rounded-3xl overflow-hidden border border-white/5 h-full flex flex-col">
      <div className="bg-blue-900/50 p-8 text-center border-b border-white/10 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/30 to-indigo-900/30"></div>
        <div className="relative z-10">
          <Book size={48} className="mx-auto mb-4 text-blue-400" />
          <h1 className="text-3xl font-bold mb-2">المكتبة العلمية للأرصاد والمناخ</h1>
          <p className="text-blue-200 max-w-2xl mx-auto">مرجعك الشامل لأهم الكتب والأبحاث والمنشورات العالمية في مجال الأرصاد الجوية، المناخ، والتنبؤات العددية.</p>
          
          <div className="mt-8 flex justify-center">
            <div className="bg-black/20 p-2 rounded-2xl flex items-center w-full max-w-xl border border-white/10">
              <div className="p-2 text-blue-400"><Search size={20} /></div>
              <input type="text" placeholder="ابحث عن كتاب، مؤلف، أو موضوع..." className="bg-transparent border-none outline-none text-white w-full px-2" />
              <button className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-xl transition-colors font-bold">بحث</button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {books.map((book, idx) => (
            <div key={idx} className="bg-blue-950/20 border border-blue-900/30 rounded-2xl p-6 hover:bg-blue-900/40 transition-colors flex flex-col">
              <div className="flex justify-between items-start mb-4">
                <span className="text-xs font-bold px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full">{book.category}</span>
                <book.icon size={24} className="text-blue-400/50" />
              </div>
              <h3 className="font-bold text-lg mb-2">{book.title}</h3>
              <p className="text-gray-400 text-sm mb-4 flex-1">المؤلف: {book.author}</p>
              <div className="flex gap-2 mt-auto pt-4 border-t border-white/5">
                <button className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 py-2 rounded-xl text-sm font-bold transition-colors">
                  <Download size={16} /> تحميل
                </button>
                <button className="px-4 flex items-center justify-center bg-white/5 hover:bg-white/10 py-2 rounded-xl text-sm transition-colors border border-white/10">
                  قراءة
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
