import { Search, BookOpen, Download, X, Eye } from 'lucide-react';
import { useState } from 'react';
import { Book } from '../../types';

const MOCK_BOOKS: Book[] = [
  { 
    id: '1', 
    title: 'أساسيات الأرصاد الجوية الديناميكية', 
    author: 'جيمس هولتون', 
    size: '15 MB', 
    img: 'https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=400&q=80', 
    category: 'ديناميكا الهواء',
    pages: 532,
    published: '2012',
    content: `الفصل الأول: القوى المؤثرة في الغلاف الجوي
الغلاف الجوي هو سائل معقد تحكمه القوانين الأساسية للديناميكا الحرارية وميكانيكا الموائع. في هذا الفصل، نستعرض القوى الأساسية التي تحدد حركة الهواء.
1. قوة انحدار الضغط: وهي القوة الناتجة عن اختلاف الضغط بين منطقتين.
2. قوة كوريوليس: وهي قوة ظاهرية تنتج عن دوران الأرض.
3. قوة الاحتكاك: وتؤثر بشكل رئيسي في الطبقة الحدية السطحية.

يتناول الكتاب بالتفصيل كيفية تفاعل هذه القوى لتكوين الرياح وأنظمة الطقس التي نشهدها يومياً.`
  },
  { 
    id: '2', 
    title: 'علم المناخ التطبيقي والتغير المناخي', 
    author: 'الهيئة الحكومية الدولية (IPCC)', 
    size: '22 MB', 
    img: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&q=80', 
    category: 'المناخ',
    pages: 1200,
    published: '2021',
    content: `التقرير التقييمي السادس - ملخص لصناع السياسات
أصبح من الواضح بشكل لا لبس فيه أن التأثير البشري قد أدى إلى تدفئة الغلاف الجوي والمحيطات والأرض. حدثت تغيرات سريعة وواسعة النطاق في الغلاف الجوي، المحيطات، الغلاف الجليدي والمحيط الحيوي.
تتضمن آثار التغير المناخي زيادة تواتر وشدة الظواهر الجوية المتطرفة، مثل موجات الحر، والأمطار الغزيرة، والجفاف، والزوابع المدارية. إن الحد من الاحترار العالمي يتطلب تخفيضات سريعة ومستدامة في انبعاثات غازات الاحتباس الحراري.`
  },
  { 
    id: '3', 
    title: 'تحليل الطقس السينوبتيكي', 
    author: 'هوارد بلوستين', 
    size: '18 MB', 
    img: 'https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?w=400&q=80', 
    category: 'السينوبتيك',
    pages: 450,
    published: '1992',
    content: `مقدمة في التحليل السينوبتيكي:
التحليل السينوبتيكي هو دراسة أنظمة الطقس على مقاييس مكانية تتراوح من مئات إلى آلاف الكيلومترات (المقياس السينوبتيكي). يشمل ذلك دراسة الجبهات الهوائية، المنخفضات الجوية خارج المدارية، والمرتفعات الجوية.
يعتمد التحليل بشكل أساسي على خرائط الطقس السطحية والعلوية لتمثيل توزيعات الضغط، درجات الحرارة، والرطوبة.
في هذا المرجع، سنستعرض النماذج المفاهيمية للجبهات (نموذج الإعصار النرويجي) وتقنيات التحليل الكينماتيكي.`
  },
  { 
    id: '4', 
    title: 'الاستشعار عن بعد للغلاف الجوي', 
    author: 'ستانلي كيدر', 
    size: '12 MB', 
    img: 'https://images.unsplash.com/photo-1516934812368-7b95cc4b665c?w=400&q=80', 
    category: 'أقمار صناعية',
    pages: 380,
    published: '1995',
    content: `الأقمار الصناعية والأرصاد الجوية:
أحدثت تقنيات الاستشعار عن بعد ثورة في قدرتنا على مراقبة الأرض وغلافها الجوي. تنقسم سواتل الأرصاد الجوية بشكل رئيسي إلى نوعين: سواتل قطبية المدار وسواتل مستقرة بالنسبة للأرض (Geostationary).
تستخدم هذه الأقمار أجهزة استشعار سلبية (مثل مقاييس الإشعاع) ونشطة (مثل الرادارات) لقياس الإشعاع المنبعث أو المنعكس من الأرض والغلاف الجوي في مختلف الأطوال الموجية (المرئية، تحت الحمراء، والمايكروويف).`
  },
  { 
    id: '5', 
    title: 'الأرصاد الجوية البحرية', 
    author: 'المنظمة العالمية للأرصاد (WMO)', 
    size: '8 MB', 
    img: 'https://images.unsplash.com/photo-1498698906158-bfb9f1d06e33?w=400&q=80', 
    category: 'البحرية',
    pages: 200,
    published: '2015',
    content: `دليل الأرصاد الجوية البحرية:
تعتبر الظروف الجوية فوق المحيطات والبحار ذات أهمية قصوى للملاحة البحرية الآمنة. يشمل هذا الدليل طرق رصد عناصر الطقس البحرية (כمثل ارتفاع الأمواج، حرارة سطح البحر، والتيارات).
كما يوضح كيفية إصدار النشرات والتحذيرات البحرية، خاصة بالنسبة للعواصف والزوابع، والتفاعلات المعقدة بين الغلاف الجوي والمحيط (כمثل ظاهرة النينيو).`
  },
  { 
    id: '6', 
    title: 'مناخ الشرق الأوسط وسوريا', 
    author: 'د. يوسف الصافي', 
    size: '6 MB', 
    img: 'https://images.unsplash.com/photo-1545888801-447a1772661c?w=400&q=80', 
    category: 'المناخ',
    pages: 315,
    published: '2019',
    content: `المناخ في حوض شرق المتوسط:
يتميز مناخ سوريا بشكل عام بأنه مناخ متوسطي، مع صيف حار وجاف وشتاء بارد وممطر، إلا أنه يتسم بتنوع كبير بسبب التضاريس. نجد المناخ الساحلي الرطب في الغرب، والمناخ شبه الجاف في المناطق الداخلية، والمناخ الصحراوي الجاف في البادية والشرق.
يناقش هذا الكتاب التوزيع المكاني والزماني للهطول المطري، وتحليل موجات الجفاف المتكررة وتأثيرها على الزراعة والموارد المائية.`
  },
];

const categories = ['الكل', 'المناخ', 'السينوبتيك', 'البحرية', 'أقمار صناعية', 'ديناميكا الهواء'];

export default function LibraryView() {
  const [activeCategory, setActiveCategory] = useState('الكل');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  const filteredBooks = MOCK_BOOKS.filter(book => {
    const matchesCategory = activeCategory === 'الكل' || book.category === activeCategory;
    const matchesSearch = book.title.includes(searchQuery) || book.author.includes(searchQuery);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="flex flex-col h-full animate-in fade-in duration-500 text-white p-4" dir="rtl">
      
      {/* Header Info */}
      <div className="bg-gradient-to-r from-[#121629] to-[#1e2338] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden mb-6">
        <div className="absolute top-0 left-0 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between md:items-center gap-4">
          <div>
            <h2 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-l from-white to-gray-400 mb-1">المكتبة الرقمية للأرصاد</h2>
            <p className="text-sm text-gray-400">كتب ومراجع علمية متخصصة في علوم الطقس والمناخ متاحة للقراءة والتحميل.</p>
          </div>
          <div className="flex items-center gap-4 text-sm font-medium">
             <div className="flex flex-col items-center p-3 bg-white/5 rounded-xl border border-white/10">
               <span className="text-xl text-blue-400 font-bold">{MOCK_BOOKS.length}</span>
               <span className="text-gray-400 text-xs">كتاب ومرجع</span>
             </div>
             <div className="flex flex-col items-center p-3 bg-white/5 rounded-xl border border-white/10">
               <span className="text-xl text-emerald-400 font-bold">120+</span>
               <span className="text-gray-400 text-xs">مستفيد يومياً</span>
             </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row items-start md:items-center gap-4 mb-6">
        <div className="w-full md:max-w-xs bg-[#1a1d2d] border border-white/10 rounded-xl p-3 flex items-center gap-3 shadow-inner">
          <Search size={18} className="text-gray-500" />
          <input 
            type="text" 
            placeholder="ابحث عن كتاب، مؤلف..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent border-none text-sm text-gray-200 w-full focus:outline-none placeholder-gray-600" 
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 w-full md:w-auto hide-scrollbar">
          {categories.map((cat) => (
            <button 
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all shadow-sm ${
                activeCategory === cat 
                  ? 'bg-blue-600 text-white shadow-blue-500/20' 
                  : 'bg-[#1a1d2d] border border-white/5 text-gray-400 hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Books Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 mb-8">
        {filteredBooks.map((book) => (
          <div key={book.id} onClick={() => setSelectedBook(book)} className="flex flex-col gap-3 group cursor-pointer">
            <div className="bg-[#1a1d2d] rounded-2xl overflow-hidden border border-white/10 aspect-[3/4] relative shadow-lg group-hover:shadow-blue-500/10 group-hover:border-blue-500/30 transition-all duration-300">
              <img src={book.img} className="w-full h-full object-cover opacity-80 mix-blend-luminosity group-hover:opacity-100 group-hover:scale-105 transition-all duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f19] via-[#0b0f19]/40 to-transparent flex flex-col justify-end p-3 opacity-90">
                 <h4 className="text-sm text-white font-bold leading-tight line-clamp-2">{book.title}</h4>
                 <div className="flex items-center justify-between mt-2">
                   <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full text-white backdrop-blur-md">{book.category}</span>
                   <Eye size={14} className="text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity" />
                 </div>
              </div>
            </div>
            <div className="flex flex-col px-1">
               <span className="text-xs text-gray-400">{book.author}</span>
               <div className="flex justify-between items-center mt-1 text-[10px] text-gray-500 font-medium">
                 <span>{book.pages} صفحة</span>
                 <span>{book.size}</span>
               </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredBooks.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
          <BookOpen size={48} className="mb-4 opacity-20" />
          <p>لا توجد كتب مطابقة للبحث أو التصنيف.</p>
        </div>
      )}

      {/* Book Reading Modal */}
      {selectedBook && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 sm:p-6 bg-[#0b0f19]/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-[#131620] border border-white/10 rounded-3xl w-full max-w-4xl h-[90vh] md:h-[80vh] flex flex-col overflow-hidden shadow-2xl relative">
            
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-white/10 bg-[#1a1d2d]/50">
              <div className="flex items-center gap-4">
                <button onClick={() => setSelectedBook(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors text-gray-400 hover:text-white">
                  <X size={20} />
                </button>
                <h3 className="font-bold text-lg text-white">{selectedBook.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors shadow-lg shadow-blue-500/20">
                  <Download size={16} /> <span className="hidden sm:inline">تحميل ({selectedBook.size})</span>
                </button>
              </div>
            </div>

            {/* Modal Content - Reader View */}
            <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-[#0f121b]">
              
              {/* Sidebar Info */}
              <div className="w-full md:w-64 bg-[#161a27] p-6 border-l border-white/5 flex flex-col items-center text-center shrink-0 overflow-y-auto">
                <img src={selectedBook.img} className="w-32 rounded-xl shadow-xl border border-white/10 mb-4" />
                <h4 className="font-bold text-white text-lg leading-tight mb-2">{selectedBook.title}</h4>
                <p className="text-gray-400 text-sm mb-6">{selectedBook.author}</p>
                
                <div className="w-full flex flex-col gap-3 text-sm">
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-gray-500">التصنيف</span>
                    <span className="text-gray-200">{selectedBook.category}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-gray-500">سنة النشر</span>
                    <span className="text-gray-200">{selectedBook.published}</span>
                  </div>
                  <div className="flex justify-between pb-2">
                    <span className="text-gray-500">عدد الصفحات</span>
                    <span className="text-gray-200">{selectedBook.pages}</span>
                  </div>
                </div>
              </div>

              {/* Reader Area */}
              <div className="flex-1 p-6 sm:p-12 overflow-y-auto custom-scrollbar">
                <div className="max-w-2xl mx-auto bg-white/5 border border-white/10 rounded-2xl p-8 sm:p-12 prose prose-invert prose-blue">
                  <div className="text-gray-300 leading-loose text-lg whitespace-pre-wrap font-serif">
                    {selectedBook.content}
                  </div>
                  <div className="mt-12 pt-8 border-t border-white/10 text-center text-gray-500 text-sm">
                    -- نهاية المستخرج المتاح للمعاينة --<br/>
                    يرجى تحميل الكتاب للحصول على النسخة الكاملة.
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
