import React, { useState } from 'react';
import SyriaMapView from './SyriaMapView';

type MapProvider = 'local' | 'ecmwf' | 'eumetsat' | 'windy' | 'ventusky';

export default function AdvancedMapsView() {
  const [activeTab, setActiveTab] = useState<MapProvider>('local');

  const tabs: { id: MapProvider; label: string }[] = [
    { id: 'local', label: 'محطات الرصد (محلي)' },
    { id: 'windy', label: 'Windy' },
    { id: 'ventusky', label: 'Ventusky' },
    { id: 'ecmwf', label: 'ECMWF' },
    { id: 'eumetsat', label: 'EUMETSAT' },
  ];

  return (
    <div className="bg-transparent backdrop-blur-md rounded-3xl overflow-hidden h-[90vh] border border-white/5 shadow-2xl flex flex-col w-full text-slate-50 relative z-0">
      {/* Map Tabs */}
      <div className="flex gap-2 p-3 border-b border-white/10 overflow-x-auto hide-scrollbar z-10 bg-[#1e2338]/80">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`whitespace-nowrap px-4 py-2 rounded-xl text-sm font-bold transition-all ${
              activeTab === tab.id
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Map Content */}
      <div className="flex-1 relative w-full h-full z-0 bg-black/20">
        {activeTab === 'local' && <SyriaMapView />}
        
        {activeTab === 'windy' && (
          <iframe 
            src="https://embed.windy.com/embed.html?type=map&location=coordinates&metricRain=mm&metricTemp=%C2%B0C&metricWind=km%2Fh&zoom=5&overlay=wind&product=ecmwf&level=surface&lat=34.8&lon=38.9&detailLat=34.8&detailLon=38.9" 
            className="w-full h-full border-none" 
            title="Windy Map"
          ></iframe>
        )}

        {activeTab === 'ventusky' && (
          <iframe 
            src="https://www.ventusky.com/?p=34.8;38.9;5&l=temperature-2m" 
            className="w-full h-full border-none" 
            title="Ventusky Map"
          ></iframe>
        )}

        {activeTab === 'ecmwf' && (
          <div className="w-full h-full flex items-center justify-center bg-[#0b0f19]">
             {/* Replace with actual ECMWF embed if available, or direct them */}
             <div className="text-center p-8 max-w-lg">
                <h3 className="text-2xl font-bold mb-4 text-blue-400">ECMWF Open Charts</h3>
                <p className="text-gray-300 mb-6">المركز الأوروبي للتنبؤات الجوية متوسطة المدى. يمكن عرض الخرائط التفاعلية هنا في حال توفر رابط التضمين الرسمي.</p>
                <a href="https://charts.ecmwf.int/" target="_blank" rel="noopener noreferrer" className="px-6 py-3 bg-blue-600 rounded-xl font-bold inline-block hover:bg-blue-700 transition-colors">
                  فتح منصة ECMWF
                </a>
             </div>
          </div>
        )}

        {activeTab === 'eumetsat' && (
          <iframe 
            src="https://view.eumetsat.int/productviewer?v=default" 
            className="w-full h-full border-none" 
            title="EUMETSAT Viewer"
          ></iframe>
        )}
      </div>
    </div>
  );
}
