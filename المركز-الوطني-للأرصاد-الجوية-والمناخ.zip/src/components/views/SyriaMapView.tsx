import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Map, CalendarDays, Moon, Sun, Maximize2, Minimize2, Thermometer, Wind, Cloud } from 'lucide-react';

// Fix Leaflet's default icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom Icon for Weather Stations
const stationIcon = new L.DivIcon({
  html: `<div style="background-color: #3b82f6; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
         </div>`,
  className: 'custom-station-icon',
  iconSize: [24, 24],
  iconAnchor: [12, 12]
});

interface StationData {
  _id: string;
  name: string;
  location: {
    coordinates: [number, number]; // [longitude, latitude]
  };
  temperature: number;
  wind_speed: number;
  sky_condition: string;
}

export default function SyriaMapView() {
  const [activeTab, setActiveTab] = useState<'current' | 'forecast'>('current');
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);
  const [stations, setStations] = useState<StationData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/stations')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'ok' || data.status === 'mock') {
          setStations(data.data);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error("Failed to fetch stations:", err);
        setLoading(false);
      });
  }, [activeTab]);

  const containerClasses = isExpanded 
    ? `fixed inset-0 z-[9999] flex flex-col transition-colors duration-300 ${isDarkMode ? 'bg-[#0b0f19] text-white' : 'bg-gray-100 text-gray-900'}` 
    : `w-full h-[600px] md:h-full flex flex-col rounded-3xl overflow-hidden transition-colors duration-300 border ${isDarkMode ? 'bg-[#0b0f19] border-white/5 shadow-2xl' : 'bg-white border-gray-200 shadow-xl'}`;

  const tileUrl = isDarkMode 
    ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
    : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";

  return (
    <div className={containerClasses}>
      {/* Header Tabs & Theme Switcher */}
      <div className={`flex items-center justify-between p-3 md:p-4 border-b transition-colors duration-300 ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('current')}
            className={`flex items-center gap-2 px-3 py-2 md:px-4 md:py-2 rounded-xl font-bold transition-all text-xs md:text-sm ${
              activeTab === 'current'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                : `${isDarkMode ? 'text-gray-400 hover:bg-white/10' : 'text-gray-600 hover:bg-gray-100'}`
            }`}
          >
            <Map size={18} />
            <span className="hidden sm:inline">الطقس الحالي</span>
            <span className="sm:hidden">الحالي</span>
          </button>
          <button
            onClick={() => setActiveTab('forecast')}
            className={`flex items-center gap-2 px-3 py-2 md:px-4 md:py-2 rounded-xl font-bold transition-all text-xs md:text-sm ${
              activeTab === 'forecast'
                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                : `${isDarkMode ? 'text-gray-400 hover:bg-white/10' : 'text-gray-600 hover:bg-gray-100'}`
            }`}
          >
            <CalendarDays size={18} />
            <span className="hidden sm:inline">الطقس المتوقع</span>
            <span className="sm:hidden">المتوقع</span>
          </button>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`p-2 rounded-xl transition-all flex items-center justify-center ${
              isDarkMode ? 'bg-white/10 text-yellow-400 hover:bg-white/20' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            title="تبديل الوضع الليلي/النهاري"
          >
            {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className={`p-2 rounded-xl transition-all flex items-center justify-center hidden md:flex ${
              isDarkMode ? 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            title={isExpanded ? 'تصغير' : 'تكبير ملء الشاشة'}
          >
            {isExpanded ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
          </button>
        </div>
      </div>

      {/* Map Container */}
      <div className="flex-1 relative w-full h-full z-0">
        {loading ? (
          <div className="absolute inset-0 flex items-center justify-center z-10 bg-black/20 backdrop-blur-sm">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
          </div>
        ) : (
          <MapContainer 
            center={[34.8021, 38.9968]} // Center of Syria
            zoom={6} 
            style={{ height: '100%', width: '100%', zIndex: 0 }}
            zoomControl={false}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url={tileUrl}
            />
            {stations.map(station => (
              <Marker 
                key={station._id || station.name} 
                position={[station.location?.coordinates[1] || 33.5, station.location?.coordinates[0] || 36.3]} 
                icon={stationIcon}
              >
                <Popup className={isDarkMode ? 'dark-popup' : ''}>
                  <div className={`p-1 ${isDarkMode ? 'text-gray-800' : ''} text-right`} dir="rtl">
                    <h3 className="font-bold text-lg mb-2 text-blue-600">{station.name}</h3>
                    <div className="flex items-center gap-2 mb-1">
                      <Thermometer size={16} className="text-orange-500" />
                      <span>الحرارة: {station.temperature}°C</span>
                    </div>
                    <div className="flex items-center gap-2 mb-1">
                      <Wind size={16} className="text-teal-500" />
                      <span>الرياح: {station.wind_speed} كم/سا</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Cloud size={16} className="text-gray-500" />
                      <span>الحالة: {station.sky_condition}</span>
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        )}
      </div>
      
      {/* Footer Info */}
      <div className={`p-3 text-xs md:text-sm border-t text-center ${isDarkMode ? 'border-white/10 text-gray-400' : 'border-gray-200 text-gray-500'}`}>
        بيانات محدثة من محطات الرصد السطحي - {activeTab === 'current' ? 'مباشر' : 'توقعات 3 أيام'}
      </div>
    </div>
  );
}
