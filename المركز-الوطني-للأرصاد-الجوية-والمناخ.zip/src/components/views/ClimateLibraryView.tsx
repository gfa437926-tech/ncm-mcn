import React from 'react';
import { BookOpen, Calendar, Map, Thermometer, Search, Download, FileText } from 'lucide-react';

export default function ClimateLibraryView() {
  const books = [
    { title: 'مؤشرات التطرف المناخي في سورية (2010-2020)', category: 'بحوث التغير المناخي', icon: Thermometer },
    { title: 'الأطلس المناخي للجمهورية العربية السورية', category: 'الأطلس المناخي', icon: Map },
    { title: 'النشرة المناخية السنوية لعام 2023', category: 'النشرات المناخية', icon: Calendar },
    { title: 'التغيرات المناخية وأثرها على الزراعة', category: 'الزراعة والمناخ', icon: BookOpen },
    { title: 'دراسة تحليلية للأمطار في الساحل السوري', category: 'بحوث الهطول', icon: FileText },
    { title: 'أثر التغير المناخي على الموارد المائية', category: 'المياه والمناخ', icon: BookOpen },
  ];

  return (
    <div className="bg-[#1e2338] text-white rounded-3xl overflow-hidden border border-white/5 h-full flex flex-col">
      <div className="bg-emerald-800/80 p-8 text-center border-b border-white/10 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/50 to-teal-900/50"></div>
        <div className="relative z-10">
          <BookOpen size={48} className="mx-auto mb-4 text-emerald-400" />
          <h1 className="text-3xl font-bold mb-2">مكتبة الدراسات المناخية</h1>
          <p className="text-emerald-100 max-w-2xl mx-auto">إصدارات وتقارير دورية حول السجل المناخي، التغيرات المناخية، والنشرات الشهرية للجمهورية العربية السورية.</p>
          
          <div className="mt-8 flex justify-center">
            <div className="bg-black/20 p-2 rounded-2xl flex items-center w-full max-w-xl border border-white/10">
              <div className="p-2 text-emerald-400"><Search size={20} /></div>
              <input type="text" placeholder="ابحث عن نشرة، دراسة، أو عام..." className="bg-transparent border-none outline-none text-white w-full px-2" />
              <button className="bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2 rounded-xl transition-colors font-bold">بحث</button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {books.map((book, idx) => (
            <div key={idx} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-colors flex flex-col">
              <div className="flex justify-between items-start mb-4">
                <span className="text-xs font-bold px-3 py-1 bg-emerald-500/20 text-emerald-300 rounded-full">{book.category}</span>
                <book.icon size={24} className="text-gray-400" />
              </div>
              <h3 className="font-bold text-lg mb-4 flex-1">{book.title}</h3>
              <div className="flex gap-2 mt-auto pt-4 border-t border-white/10">
                <button className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 py-2 rounded-xl text-sm font-bold transition-colors">
                  <Download size={16} /> تحميل PDF
                </button>
                <button className="px-4 flex items-center justify-center bg-white/10 hover:bg-white/20 py-2 rounded-xl text-sm transition-colors">
                  قراءة
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
