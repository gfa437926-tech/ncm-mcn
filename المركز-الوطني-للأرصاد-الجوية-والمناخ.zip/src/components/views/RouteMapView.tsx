import { MapContainer, TileLayer, Polyline, Marker, Popup, CircleMarker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { CloudFog, CloudRain, AlertTriangle, Wind, MapPin, X, Navigation } from 'lucide-react';
import { useState, useEffect } from 'react';

// Fix for default marker icons in React-Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Create custom icons for warnings
const createWarningIcon = (color: string, iconHtml: string) => L.divIcon({
  className: 'custom-warning-icon',
  html: `<div style="background-color: ${color}; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3); font-size: 16px;">${iconHtml}</div>`,
  iconSize: [30, 30],
  iconAnchor: [15, 15]
});

export default function RouteMapView() {
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation([position.coords.latitude, position.coords.longitude]);
        },
        (error) => {
          console.warn("User location not available or permission denied.");
        }
      );
    }
  }, []);

  // Damascus to Aleppo example route
  const start: [number, number] = [33.5138, 36.2765]; // Damascus
  const end: [number, number] = [36.2021, 37.1343]; // Aleppo
  const center: [number, number] = userLocation || [34.85, 36.7]; // Middle or user location
  
  // Fake route line
  const route: [number, number][] = [
    start,
    [33.9, 36.4],
    [34.3, 36.6],
    [34.7, 36.7], // Homs
    [35.1, 36.7], // Hama
    [35.6, 36.9],
    end
  ];

  const warnings = [
    { pos: [34.3, 36.6] as [number, number], type: 'fog', text: 'ضباب كثيف بعد 60 كم. مستوى الرؤية أقل من 500 متر', color: '#94a3b8', icon: '🌫️' },
    { pos: [35.1, 36.7] as [number, number], type: 'rain', text: 'أمطار غزيرة متوقعة في حمص. يرجى تخفيف السرعة', color: '#3b82f6', icon: '🌧️' },
    { pos: [35.8, 36.95] as [number, number], type: 'dust', text: 'عاصفة غبارية تؤثر على الرؤية قبل حلب بـ 40 كم', color: '#d97706', icon: '💨' }
  ];

  return (
    <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl overflow-hidden border border-white/5 shadow-2xl flex flex-col h-[85vh] animate-in fade-in duration-500 w-full text-white">
      <div className="flex justify-between items-center p-5 border-b border-white/10 bg-[#1e2338]">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
            <MapPin size={24} />
          </div>
          <div>
            <h2 className="text-white font-bold text-lg">خريطة مسار الرحلة والتحذيرات</h2>
            <p className="text-xs text-gray-400">دمشق - حلب (عبر حمص)</p>
          </div>
        </div>
      </div>
      
      <div className="flex-1 relative flex flex-col md:flex-row">
        {/* Map Area */}
        <div className="flex-1 h-[40vh] md:h-auto z-10 relative">
          <MapContainer center={center} zoom={7} style={{ height: '100%', width: '100%', backgroundColor: '#0f121b' }}>
            <TileLayer
              attribution='&copy; <a href="https://carto.com/">CartoDB</a>'
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            />
            <Polyline positions={route} color="#3b82f6" weight={5} opacity={0.8} />
            
            <Marker position={start}>
              <Popup>نقطة الانطلاق: دمشق</Popup>
            </Marker>
            <Marker position={end}>
              <Popup>الوجهة: حلب</Popup>
            </Marker>
            
            {userLocation && (
              <Marker position={userLocation} icon={createWarningIcon('#10b981', '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="3 11 22 2 13 21 11 13 3 11"></polygon></svg>')}>
                <Popup>موقعك الحالي</Popup>
              </Marker>
            )}

            {warnings.map((w, idx) => (
              <Marker key={idx} position={w.pos} icon={createWarningIcon(w.color, w.icon)}>
                <Popup>
                  <div className="text-right rtl font-sans" style={{direction:'rtl'}}>
                    <strong>تحذير على الطريق</strong><br/>
                    {w.text}
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>
        
        {/* Warnings List Sidebar */}
        <div className="w-full md:w-80 bg-[#1a1d2d] border-r border-white/5 flex flex-col overflow-hidden h-[45vh] md:h-auto">
          <div className="p-4 border-b border-white/5 bg-[#161a27]">
            <h3 className="text-white font-bold flex items-center gap-2">
              <AlertTriangle size={18} className="text-orange-500" />
              تنبيهات المسار (3)
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
            {warnings.map((w, idx) => (
              <div key={idx} className="bg-[#1e2338] border border-white/5 rounded-xl p-4 flex gap-3 hover:border-white/20 transition-colors cursor-pointer">
                <div className="w-10 h-10 shrink-0 rounded-full flex items-center justify-center text-xl shadow-inner border border-white/10" style={{backgroundColor: w.color + '40'}}>
                  {w.icon}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white mb-1">بعد {Math.round((idx+1)*50)} كم</h4>
                  <p className="text-xs text-gray-400 leading-relaxed">{w.text}</p>
                </div>
              </div>
            ))}
            
            <div className="mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
              <h4 className="text-green-400 font-bold text-sm mb-1">الرحلة آمنة بشكل عام</h4>
              <p className="text-xs text-green-500/80">يرجى أخذ الحيطة في النقاط المذكورة واتباع تعليمات المرور.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
