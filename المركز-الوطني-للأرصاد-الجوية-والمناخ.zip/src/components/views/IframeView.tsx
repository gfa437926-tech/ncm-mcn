import React, { useState, useEffect } from 'react';

export default function IframeView({ src }: { src: string }) {
  const [loading, setLoading] = useState(true);

  // Force reload when src changes
  useEffect(() => {
    setLoading(true);
  }, [src]);

  return (
    <div className="relative w-full h-[85vh] rounded-3xl overflow-hidden shadow-2xl bg-white border border-gray-200">
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-50 z-10">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      )}
      <iframe 
        src={src} 
        className="w-full h-full border-none"
        onLoad={() => setLoading(false)}
        title="Content Frame"
      />
    </div>
  );
}
