import { useState, useRef } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Droplets, Wind, CloudLightning, ArrowUp, ArrowDown } from 'lucide-react';
import { WeatherData } from '../../types';
import WeatherIcon from '../WeatherIcon';
import VerifiedWindyData from './VerifiedWindyData';
import SyriaMapView from './SyriaMapView';
import { useLongPress } from '../../hooks/useLongPress';

interface DashboardViewProps {
  data?: WeatherData;
}

export default function DashboardView({ data }: DashboardViewProps) {
  const [activeTabId, setActiveTabId] = useState('temp');
  const lastTapRef = useRef<number>(0);

  if (!data) return <div className="p-4 text-center">جاري التحميل...</div>;

  const hourlyTabs = [
    { id: 'temp', label: 'الحرارة', dataKey: 'temp', color: '#fbbf24', unit: '°' },
    { id: 'precip', label: 'الهطول', dataKey: 'precipitationProbability', color: '#60a5fa', unit: '%' },
    { id: 'wind', label: 'الرياح', dataKey: 'windSpeed', color: '#a78bfa', unit: ' كم/س' },
    { id: 'humidity', label: 'الرطوبة', dataKey: 'humidity', color: '#22d3ee', unit: '%' },
    { id: 'uv', label: 'الأشعة البنفسجية', dataKey: 'uvIndex', color: '#f472b6', unit: '' },
    { id: 'dew', label: 'نقطة الندى', dataKey: 'dewPoint', color: '#10b981', unit: '°' },
  ];

  const activeTab = hourlyTabs.find(t => t.id === activeTabId) || hourlyTabs[0];

  const chartData = data.hourly.map(hour => ({
    time: hour.time.split(':')[0],
    [activeTab.dataKey]: hour[activeTab.dataKey as keyof typeof hour],
  }));

  const getDynamicDescription = () => {
    if (!chartData || chartData.length === 0) return '';
    const values = chartData.map(d => Number(d[activeTab.dataKey as keyof typeof d])).filter(v => !isNaN(v));
    if (values.length === 0) return '';
    
    const max = Math.max(...values);
    const min = Math.min(...values);
    const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
    
    switch (activeTabId) {
      case 'temp':
        return `تشير التوقعات إلى أن درجات الحرارة ستتراوح بين ${min}° كحد أدنى و ${max}° كحد أقصى، بمتوسط ${avg}°. ${max > 30 ? 'يُتوقع طقس حار نسبياً، يُنصح بشرب السوائل.' : ''}`;
      case 'precip':
        return `تتراوح احتمالية هطول الأمطار بين ${min}% و ${max}%. ${max > 50 ? 'فرصة جيدة لهطول الأمطار، لا تنسَ المظلة.' : 'الطقس جاف غالباً.'}`;
      case 'wind':
        return `سرعة الرياح ستكون بين ${min} كم/س و ${max} كم/س. ${max > 40 ? 'رياح قوية متوقعة، يرجى توخي الحذر.' : 'الرياح هادئة إلى معتدلة.'}`;
      case 'humidity':
        return `تتراوح نسبة الرطوبة بين ${min}% و ${max}%. ${max > 70 ? 'رطوبة عالية قد تزيد من الإحساس بالحرارة.' : ''}`;
      case 'cloud':
        return `الغطاء السحابي سيكون بين ${min}% و ${max}%. ${max < 20 ? 'سماء صافية بمعظم الأوقات.' : avg > 70 ? 'سماء غائمة بشكل عام.' : 'سماء غائمة جزئياً.'}`;
      case 'pressure':
        return `يتراوح الضغط الجوي بين ${min} و ${max} مليبار.`;
      case 'uv':
        return `يصل مؤشر الأشعة فوق البنفسجية إلى أقصى حد ${max}. ${max >= 6 ? 'تأكد من استخدام واقي الشمس إذا خرجت.' : ''}`;
      case 'visibility':
        return `مستوى الرؤية الأفقية سيكون بين ${min} كم و ${max} كم. ${min < 2 ? 'تنبيه: رؤية ضعيفة في بعض الأوقات، قد يكون هناك ضباب.' : ''}`;
      default:
        return `القيم تتراوح بين ${min} و ${max} بمتوسط ${avg}.`;
    }
  };

  const readWeatherSummary = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      let trendSummary = getDynamicDescription();
      const message = `الطقس حالياً في ${data.current.location}. درجة الحرارة ${data.current.temp} درجة مئوية. سرعة الرياح ${data.current.windSpeed} كيلومتر في الساعة. والجو ${data.current.condition}. يتوقع أن تكون العظمى ${data.daily[0]?.maxTemp} والصغرى ${data.daily[0]?.minTemp}. ${trendSummary}`;
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'ar-SA';
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleContainerClick = () => {
    const now = Date.now();
    const DOUBLE_CLICK_DELAY = 300;
    if (now - lastTapRef.current < DOUBLE_CLICK_DELAY) {
      readWeatherSummary();
    }
    lastTapRef.current = now;
  };

  const getUvImpact = (uv: number) => {
    if (uv <= 2) return 'منخفض';
    if (uv <= 5) return 'متوسط';
    if (uv <= 7) return 'عالي';
    if (uv <= 10) return 'عالي جداً';
    return 'شديد';
  };

  const getWindCategory = (speed: number) => {
    if (speed < 1) return 'ساكن';
    if (speed <= 5) return 'خفيف';
    if (speed <= 11) return 'نسيم';
    if (speed <= 19) return 'لطيف';
    if (speed <= 28) return 'معتدل';
    if (speed <= 38) return 'نشط';
    if (speed <= 49) return 'قوي';
    if (speed <= 61) return 'عاصف';
    if (speed <= 74) return 'شديد';
    return 'إعصار';
  };

  const longPressProps = useLongPress(readWeatherSummary, undefined, { delay: 600 });

  return (
    <div 
      className="flex flex-col gap-5 p-4 pb-24 max-w-lg mx-auto w-full animate-in fade-in duration-500"
      onClick={handleContainerClick}
    >
      
      {/* Current Weather Main Card */}
      <div 
        {...longPressProps}
        className="bg-gradient-to-br from-[#161a27] to-[#0f121b] border border-white/5 rounded-3xl p-6 shadow-2xl relative overflow-hidden transition-transform active:scale-[0.98]"
      >
        <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="flex items-center justify-between mb-4 relative z-10">
          <div className="flex flex-col">
            <span className="text-4xl font-light text-white tracking-tighter">{data.current.temp}°</span>
            <span className="text-sm text-gray-400 mt-1">الإحساس الحقيقي {data.current.feelsLike}°</span>
          </div>
          <div className="scale-125 origin-left drop-shadow-xl">
            <WeatherIcon status={data.current.icon} size={64} />
          </div>
        </div>

        <div className="text-lg font-bold text-white mb-6 relative z-10">{data.current.condition}</div>
        
        <div className="grid grid-cols-3 gap-y-4 gap-x-2 pt-4 border-t border-white/10 relative z-10 text-center">
          <div className="flex flex-col gap-1 items-center">
            <Wind size={16} className="text-purple-400" />
            <span className="text-[10px] text-gray-400">{getWindCategory(data.current.windSpeed)}</span>
            <span className="text-xs font-bold text-white">{data.current.windSpeed} كم/س</span>
          </div>
          <div className="flex flex-col gap-1 items-center">
            <Droplets size={16} className="text-cyan-400" />
            <span className="text-[10px] text-gray-400">الرطوبة</span>
            <span className="text-xs font-bold text-white">{data.current.humidity}%</span>
          </div>
          <div className="flex flex-col gap-1 items-center">
            <span className="text-pink-400 font-bold text-sm leading-none mt-1">UV</span>
            <span className="text-[10px] text-gray-400">{getUvImpact(data.current.uvIndex)}</span>
            <span className="text-xs font-bold text-white">{data.current.uvIndex}</span>
          </div>
          <div className="flex flex-col gap-1 items-center text-gray-400 text-[10px] mt-2">
            <span>الضغط</span>
            <span className="text-xs font-bold text-white mt-1">{data.current.pressure} mb</span>
          </div>
          <div className="flex flex-col gap-1 items-center text-gray-400 text-[10px] mt-2">
            <span>الرؤية</span>
            <span className="text-xs font-bold text-white mt-1">{data.current.visibility} كم</span>
          </div>
          <div className="flex flex-col gap-1 items-center text-gray-400 text-[10px] mt-2">
            <span>نقطة الندى</span>
            <span className="text-xs font-bold text-white mt-1">{data.current.dewPoint}°</span>
          </div>
        </div>
      </div>

      {/* Hourly Data Chart */}
      <div className="bg-[#161a27] rounded-3xl p-5 border border-white/5 shadow-xl">
        <div className="flex gap-2 overflow-x-auto hide-scrollbar mb-6 pb-2">
          {hourlyTabs.map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTabId(tab.id)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                activeTabId === tab.id 
                  ? 'bg-blue-600 text-white shadow-[0_0_10px_rgba(37,99,235,0.3)]' 
                  : 'bg-[#1a1d2d] text-gray-400 hover:bg-white/10'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="h-40 w-full" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 0, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="colorMobileChart" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={activeTab.color} stopOpacity={0.4}/>
                  <stop offset="95%" stopColor={activeTab.color} stopOpacity={0.0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} interval="preserveStartEnd" />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} domain={['auto', 'auto']} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', fontSize: '12px' }}
                itemStyle={{ color: activeTab.color, fontWeight: 'bold' }}
                formatter={(value: any) => [`${value}${activeTab.unit}`, activeTab.label]}
              />
              <Area type="monotone" dataKey={activeTab.dataKey} stroke={activeTab.color} strokeWidth={2} fill="url(#colorMobileChart)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Map View */}
      <div className="bg-[#161a27] rounded-3xl overflow-hidden border border-white/5 shadow-xl h-64 relative mb-6">
        <SyriaMapView />
      </div>

      {/* Verified Windy Data */}
      <VerifiedWindyData />

      {/* 14 Days Forecast */}
      <div className="bg-[#161a27] rounded-3xl p-5 border border-white/5 shadow-xl">
        <h3 className="font-bold text-white mb-4">توقعات 14 يوماً</h3>
        <div className="flex flex-col gap-3">
          {data.daily.slice(0, 14).map((day, idx) => (
            <div key={idx} className="flex items-center justify-between p-2 hover:bg-white/5 rounded-xl transition-colors">
              <span className="w-16 text-sm text-gray-300">{idx === 0 ? 'اليوم' : day.dayName}</span>
              <div className="flex items-center justify-center w-12">
                <WeatherIcon status={day.icon} size={24} />
              </div>
              <div className="flex flex-col items-center justify-center w-12">
                {day.precipitationChance > 0 && (
                  <span className="text-[10px] text-blue-400 flex items-center gap-0.5"><Droplets size={10}/> {day.precipitationChance}%</span>
                )}
                {day.uvIndex && (
                  <span className="text-[10px] text-pink-400 font-bold bg-white/5 px-1 rounded">UV: {day.uvIndex}</span>
                )}
              </div>
              <div className="flex items-center gap-3 w-24 justify-end font-medium text-sm">
                <span className="text-white">{day.maxTemp}°</span>
                <div className="w-8 h-1 bg-gray-700 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-blue-500 to-orange-500" style={{ width: '100%' }}></div>
                </div>
                <span className="text-gray-500">{day.minTemp}°</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
