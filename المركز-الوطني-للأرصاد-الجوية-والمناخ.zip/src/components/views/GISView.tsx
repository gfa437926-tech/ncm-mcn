import React from 'react';
import { Map, Layers, ExternalLink } from 'lucide-react';

export default function GISView() {
  return (
    <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white">
      <div className="flex items-center gap-3 mb-8 border-b border-white/10 pb-4">
        <Map size={32} className="text-blue-500" />
        <h2 className="text-2xl font-bold">نظم المعلومات الجغرافية</h2>
      </div>

      <div className="space-y-8">
        <div className="bg-[#1a1d2d] rounded-2xl p-6 border border-white/5">
          <h3 className="text-xl font-bold mb-4 text-blue-400">تطبيقات نظم المعلومات الجغرافية في إدارة الكوارث</h3>
          <p className="text-gray-300 leading-relaxed">
            الهيئة العامة للاستشعار عن بعد هي مؤسسة حكومية علمية وبحثية متخصصة في تطبيق وتطوير تقنيات الاستشعار عن بعد ونظم المعلومات الجغرافية والفضائية لدعم التنمية المستدامة وصنع القرار في الجمهورية العربية السورية. أُحدثت الهيئة عام 1986، وتُعد المرجعية الوطنية في مجال استخدام الصور الفضائية والبيانات الجغرافية المكانية وتحليلها لخدمة مختلف القطاعات التنموية والخدمية.
          </p>
          <p className="text-gray-300 leading-relaxed mt-4">
            تعمل الهيئة على إنتاج وتحليل المعلومات المكانية والبيئية، ورصد التغيرات الطبيعية والبشرية، وتطوير التطبيقات المتعلقة بإدارة الموارد الطبيعية، والزراعة، والمياه، والتخطيط العمراني، والبيئة، وإدارة الكوارث، ومراقبة حرائق الغابات، والتغيرات المناخية.
          </p>
        </div>

        <div className="bg-[#1a1d2d] rounded-2xl p-6 border border-white/5">
          <h3 className="text-xl font-bold mb-4 text-emerald-400">وحدة نظم المعلومات الجغرافية (GIS)</h3>
          <p className="text-gray-300 leading-relaxed">
            تُعد وحدة نظم المعلومات الجغرافية في وزارة الطوارئ وإدارة الكوارث إحدى الوحدات الفنية المتخصصة التي تدعم إدارة المخاطر والكوارث من خلال إنتاج وتحليل الخرائط والبيانات المكانية. وتعمل الوحدة على تطوير خرائط المخاطر، ودعم أنظمة الإنذار المبكر، وتحليل المناطق المعرضة للكوارث، وتقييم الأضرار والخسائر.
          </p>
        </div>

        <div>
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-2"><Layers size={24} className="text-purple-500" /> التطبيقات</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              "الغطاء النباتي في سوريا 2026",
              "تقييم المخاطر المتعلقة بالفيضانات والمناطق المعرضة للخطر على طول نهر الفرات في الرقة ودير الزور",
              "الخريطة التفاعلية لمخاطر حرائق المحاصيل الزراعية في سوريا",
              "تقييم مخاطر الفيضانات في حوض نهر الفرات",
              "لوحة متابعة مخيمات سوريا - كانون الأول 2025"
            ].map((app, idx) => (
              <div key={idx} className="bg-gradient-to-br from-[#1e2338] to-[#161a27] rounded-xl p-4 border border-white/5 hover:border-purple-500/50 transition-all group flex flex-col justify-between">
                <h4 className="font-bold text-gray-200 mb-4">{app}</h4>
                <button className="flex items-center gap-2 text-sm font-bold text-purple-400 group-hover:text-purple-300 transition-colors mt-auto">
                  افتح التطبيق <ExternalLink size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}