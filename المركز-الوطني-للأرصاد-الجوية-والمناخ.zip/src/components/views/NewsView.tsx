import { Search, Settings, Clock, AlertTriangle } from 'lucide-react';

export default function NewsView() {
  return (
    <div className="flex flex-col gap-4 p-4 pb-24 max-w-lg mx-auto w-full animate-in fade-in duration-500">
      
      {/* Search and Filters */}
      <div className="flex items-center gap-2 mb-2">
        <div className="flex-1 bg-[#1a1d27] border border-[#2a2e3d] rounded-xl p-2.5 flex items-center gap-2">
          <Search size={16} className="text-gray-500" />
          <input type="text" placeholder="Search" className="bg-transparent border-none text-sm text-gray-200 w-full focus:outline-none placeholder-gray-500" />
        </div>
        <button className="p-2.5 text-gray-400">
          <Settings size={20} />
        </button>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        <button className="bg-[#3b82f6] text-white rounded-full px-4 py-1.5 text-xs font-medium whitespace-nowrap shrink-0">
          All
        </button>
        <button className="bg-[#1a1d27] border border-[#2a2e3d] text-gray-400 rounded-full px-4 py-1.5 text-xs whitespace-nowrap shrink-0 hover:bg-[#2a2e3d] transition-colors">
          Global
        </button>
        <button className="bg-[#1a1d27] border border-[#2a2e3d] text-gray-400 rounded-full px-4 py-1.5 text-xs whitespace-nowrap shrink-0 hover:bg-[#2a2e3d] transition-colors">
          Local
        </button>
        <button className="bg-[#1a1d27] border border-[#2a2e3d] text-gray-400 rounded-full px-4 py-1.5 text-xs whitespace-nowrap shrink-0 hover:bg-[#2a2e3d] transition-colors">
          Research
        </button>
        <button className="bg-[#1a1d27] border border-[#2a2e3d] text-gray-400 rounded-full px-4 py-1.5 text-xs whitespace-nowrap shrink-0 hover:bg-[#2a2e3d] transition-colors">
          Policy
        </button>
      </div>

      {/* Featured News */}
      <div className="rounded-2xl overflow-hidden relative h-48 group cursor-pointer">
        <img src="https://images.unsplash.com/photo-1548625361-ecba9321798e?w=800&q=80" alt="Glacier" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f111a] via-[#0f111a]/60 to-transparent"></div>
        <div className="absolute bottom-4 left-4 right-4 flex flex-col gap-2">
          <h3 className="text-white font-medium text-lg leading-tight">Arctic Sea Ice Hits Record Low: Urgent Implications</h3>
          <div className="flex justify-between items-center text-[10px] text-gray-300">
            <span className="flex items-center gap-1.5"><div className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center text-[8px] font-bold">N</div> NAEA Earth Observatory</span>
            <span className="flex items-center gap-1"><Clock size={10} /> 11:05 AM</span>
          </div>
        </div>
      </div>

      {/* Grid News */}
      <div className="grid grid-cols-2 gap-3">
        
        <div className="bg-[#1a1d27] rounded-xl overflow-hidden border border-[#2a2e3d] flex flex-col cursor-pointer group">
          <div className="h-24 w-full overflow-hidden">
             <img src="https://images.unsplash.com/photo-1560967018-090bbce8cc23?w=400&q=80" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
          </div>
          <div className="p-3 flex-1 flex flex-col justify-between gap-2">
            <h4 className="text-xs text-gray-200 font-medium leading-snug">COP28: Key Climate Pledges Analyzed</h4>
            <div className="flex justify-between items-center text-[9px] text-gray-500 mt-auto">
              <span className="flex items-center gap-1"><div className="w-3 h-3 rounded-sm bg-orange-600"></div> Reuters</span>
              <span className="flex items-center gap-0.5"><Clock size={8} /> 4h</span>
            </div>
          </div>
        </div>

        <div className="bg-[#1a1d27] rounded-xl overflow-hidden border border-[#2a2e3d] flex flex-col cursor-pointer group">
          <div className="h-24 w-full overflow-hidden">
             <img src="https://images.unsplash.com/photo-1454789548928-9efd52dc4031?w=400&q=80" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
          </div>
          <div className="p-3 flex-1 flex flex-col justify-between gap-2">
            <h4 className="text-xs text-gray-200 font-medium leading-snug">Extreme Weather Events Surge in 2023</h4>
            <div className="flex justify-between items-center text-[9px] text-gray-500 mt-auto">
              <span className="flex items-center gap-1"><div className="w-3 h-3 rounded-full bg-blue-600 text-[6px] text-white flex items-center justify-center">W</div> WMO</span>
              <span className="flex items-center gap-0.5"><Clock size={8} /> 5h</span>
            </div>
          </div>
        </div>

        <div className="bg-[#1a1d27] rounded-xl overflow-hidden border border-[#2a2e3d] flex flex-col cursor-pointer group">
          <div className="h-24 w-full overflow-hidden">
             <img src="https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?w=400&q=80" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
          </div>
          <div className="p-3 flex-1 flex flex-col justify-between gap-2">
            <h4 className="text-xs text-gray-200 font-medium leading-snug">New Study on Atlantic Current Collapse</h4>
            <div className="flex justify-between items-center text-[9px] text-gray-500 mt-auto">
              <span className="flex items-center gap-1"><div className="w-3 h-3 rounded-sm bg-green-600 text-[6px] text-white flex items-center justify-center">N</div> Nature</span>
              <span className="flex items-center gap-0.5"><Clock size={8} /> 10h</span>
            </div>
          </div>
        </div>

        <div className="bg-[#2a1d1a] rounded-xl overflow-hidden border border-[#4a2e2a] flex flex-col cursor-pointer group">
           <div className="p-3 flex-1 flex flex-col gap-2">
            <h4 className="text-xs text-gray-200 font-medium leading-snug">Local Dust Storm Warning for Damascus</h4>
            <p className="text-[10px] text-gray-400 leading-snug line-clamp-2">Local dust storm warning for Damascus valid until tomorrow morning...</p>
            <div className="flex justify-between items-center text-[9px] text-orange-400 mt-auto">
              <AlertTriangle size={12} />
              <span className="flex items-center gap-0.5 text-gray-500"><Clock size={8} /> 6h</span>
            </div>
          </div>
        </div>

      </div>

      <h3 className="text-sm text-gray-200 mt-2 font-medium">Bookmarked</h3>

    </div>
  );
}
