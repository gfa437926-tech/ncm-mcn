import React from 'react';
import { ShieldAlert, AlertTriangle } from 'lucide-react';

export default function AlertsView() {
  return (
    <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white">
      <div className="flex items-center gap-3 mb-8 border-b border-white/10 pb-4">
        <ShieldAlert size={32} className="text-red-500" />
        <h2 className="text-2xl font-bold">تنبيهات CAP Alerts</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* Map Placeholder */}
          <div className="bg-[#1a1d2d] rounded-2xl p-4 border border-white/5 h-[400px] flex items-center justify-center relative overflow-hidden">
            <img src="/pages/map1.html" alt="Map" className="absolute inset-0 w-full h-full object-cover opacity-30" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            <div className="z-10 text-center">
              <p className="text-gray-400 font-bold mb-2">خريطة التحذيرات النشطة</p>
              <div className="flex items-center justify-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-500"></span> Extreme
                <span className="w-3 h-3 rounded-full bg-orange-500 ml-2"></span> Severe
                <span className="w-3 h-3 rounded-full bg-yellow-500 ml-2"></span> Moderate
                <span className="w-3 h-3 rounded-full bg-cyan-500 ml-2"></span> Minor
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-xl font-bold border-b border-white/10 pb-2">Active Alerts</h3>
          
          <div className="bg-[#1a1d2d] rounded-2xl p-4 border border-cyan-500/30 flex flex-col gap-3">
            <div className="flex justify-between items-start">
              <span className="bg-cyan-500/20 text-cyan-400 text-xs font-bold px-2 py-1 rounded-full">خطورة طفيفة</span>
              <AlertTriangle size={20} className="text-cyan-400" />
            </div>
            <h4 className="font-bold text-lg">جاري التنفيذ: اللشمانيا (دير الزور، الرقة، حلب، حماة، إدلب)</h4>
            <p className="text-sm text-gray-400">تحذير صحي: ازدياد حالات الإصابة باللشمانيا في عدد من المحافظات...</p>
            <div className="text-xs text-gray-500 mt-2">
              صادر: 07 يوليو 2026 01:45 م
            </div>
          </div>
          
          <h3 className="text-xl font-bold border-b border-white/10 pb-2 mt-8">التنبيهات الماضية</h3>
          
          <div className="bg-[#1a1d2d] rounded-2xl p-4 border border-yellow-500/30 flex flex-col gap-3 opacity-70">
            <div className="flex justify-between items-start">
              <span className="bg-yellow-500/20 text-yellow-400 text-xs font-bold px-2 py-1 rounded-full">Moderate severity</span>
              <AlertTriangle size={20} className="text-yellow-400" />
            </div>
            <h4 className="font-bold text-lg">منتهي الصلاحية: أمواج مرتفعة (الساحل السوري)</h4>
            <div className="text-xs text-gray-500 mt-2">
              منتهي: 5 يوليو 2026
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}