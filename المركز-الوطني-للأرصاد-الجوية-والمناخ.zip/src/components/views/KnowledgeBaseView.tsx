import { useState } from 'react';
import { Wind, CloudFog, CloudLightning, Tornado, Plane, ShieldCheck, Ship, Network, Beaker, X, ChevronLeft } from 'lucide-react';

const articles = [
  {
    id: 'marine',
    title: 'مهام قسم الأرصاد البحرية',
    icon: <Ship size={24} />,
    color: 'from-blue-600 to-cyan-500',
    content: (
      <div className="space-y-6">
        <p className="text-lg leading-relaxed text-gray-300">حماية الأرواح والممتلكات من خلال الرصد والتحذير المبكر للحالة البحرية.</p>
        <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
          <h4 className="font-bold text-xl text-blue-400 mb-4">الدراسات والتحليلات</h4>
          <ul className="list-disc pl-4 space-y-3 text-gray-300">
            <li>دراسـة تأثيرات التغيرات الجـويـة على حـالة البحـر.</li>
            <li>تجميع وتحليل الرصدات البحرية وإعـداد الخرائـط الجـويـة للمنـاطق البحـريـة.</li>
          </ul>
        </div>
        <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
          <h4 className="font-bold text-xl text-blue-400 mb-4">التحذيرات الطارئة</h4>
          <ul className="list-disc pl-4 space-y-3 text-gray-300">
            <li>إصـدار التحـذيرات للملاحـة البحريـة في الحالات الحرجة.</li>
            <li>إبلاغ الجهات المسؤولة عن تأمين الحركة البحرية والموانئ.</li>
          </ul>
        </div>
      </div>
    )
  },
  {
    id: 'wind',
    title: 'الرياح وتأثيراتها',
    icon: <Wind size={24} />,
    color: 'from-emerald-500 to-teal-400',
    content: (
      <div className="space-y-6">
        <p className="text-lg leading-relaxed text-gray-300">الرياح هي حركة الهواء من منطقة إلى أخرى نتيجة اختلاف الضغط الجوي.</p>
        <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
          <h4 className="font-bold text-xl text-emerald-400 mb-4">أنواع الرياح</h4>
          <ul className="list-disc pl-4 space-y-3 text-gray-300">
            <li>الرياح المحلية: تتكون نتيجة التغيرات في درجات الحرارة بين اليابس والماء.</li>
            <li>الرياح العالمية: مثل الرياح التجارية والغربية والقطبية.</li>
          </ul>
        </div>
      </div>
    )
  },
  {
    id: 'fog',
    title: 'تشكل الضباب',
    icon: <CloudFog size={24} />,
    color: 'from-gray-400 to-slate-300',
    content: (
      <div className="space-y-6">
        <p className="text-lg leading-relaxed text-gray-300">يعد الضباب من الظواهر الجوية المهمة التي تؤثر على مختلف القطاعات خاصة النقل والطيران.</p>
        <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
          <h4 className="font-bold text-xl text-gray-300 mb-4">أنواع الضباب في سوريا</h4>
          <ul className="list-disc pl-4 space-y-3 text-gray-300">
            <li>ضباب الإشعاع: يحدث ليلاً مع صفاء السماء وهدوء الرياح.</li>
            <li>ضباب التبخر: يظهر فوق المسطحات المائية.</li>
            <li>ضباب المنخفضات: في المناطق المنخفضة مثل الغاب والسهول.</li>
          </ul>
        </div>
      </div>
    )
  },
  {
    id: 'cloud_seeding',
    title: 'الاستمطار الصناعي',
    icon: <Beaker size={24} />,
    color: 'from-teal-500 to-emerald-600',
    content: (
      <div className="space-y-6">
        <p className="text-lg leading-relaxed text-gray-300">مشاريع استمطار السحب باستخدام تقنيات متقدمة لزيادة الهطول المطري.</p>
        <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
          <h4 className="font-bold text-xl text-teal-400 mb-4">التقنيات المستخدمة</h4>
          <ul className="list-disc pl-4 space-y-3 text-gray-300">
            <li>الطائرات المخصصة لنثر المواد المحفزة (مثل يوديد الفضة).</li>
            <li>الرصد بالرادار لتحديد السحب المناسبة.</li>
          </ul>
        </div>
      </div>
    )
  }
];

export default function KnowledgeBaseView() {
  const [activeArticle, setActiveArticle] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-6 h-full animate-in fade-in duration-500 text-white" dir="rtl">
      
      {!activeArticle ? (
        <>
          <div className="bg-gradient-to-br from-[#161a27] to-[#0f121b] border border-white/5 rounded-3xl p-8 text-center shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <h2 className="text-2xl font-bold text-white mb-3">المركز المعرفي</h2>
            <p className="text-gray-400 max-w-md mx-auto">دليلك الشامل لعلوم الطقس، الأرصاد، والهيكل التنظيمي للمركز</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-12">
            {articles.map((article) => (
              <button
                key={article.id}
                onClick={() => setActiveArticle(article.id)}
                className="flex items-center gap-4 p-5 bg-[#161a27] hover:bg-white/5 border border-white/5 hover:border-white/10 rounded-2xl transition-all shadow-lg group text-right"
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${article.color} flex items-center justify-center text-white shadow-lg group-hover:scale-105 transition-transform shrink-0`}>
                  {article.icon}
                </div>
                <div className="flex-1">
                  <span className="font-bold text-gray-200 text-base">{article.title}</span>
                </div>
                <ChevronLeft size={20} className="text-gray-600 group-hover:text-white transition-colors" />
              </button>
            ))}
          </div>
        </>
      ) : (
        <div className="bg-[#161a27] border border-white/5 rounded-3xl p-8 shadow-2xl relative animate-in slide-in-from-bottom-8 flex-1">
          <button 
            onClick={() => setActiveArticle(null)}
            className="absolute top-6 left-6 text-sm bg-white/5 hover:bg-white/10 text-gray-300 px-4 py-2 rounded-xl transition-colors flex items-center gap-2"
          >
            عودة
            <X size={16} />
          </button>
          
          {articles.filter(a => a.id === activeArticle).map(article => (
            <div key={article.id} className="max-w-2xl mx-auto mt-8">
              <div className="flex items-center gap-6 mb-8 pb-8 border-b border-white/5">
                <div className={`w-16 h-16 rounded-3xl bg-gradient-to-br ${article.color} flex items-center justify-center text-white shrink-0 shadow-lg`}>
                  {article.icon}
                </div>
                <h3 className="text-3xl font-bold text-white leading-tight">{article.title}</h3>
              </div>
              <div className="prose prose-invert prose-blue max-w-none">
                {article.content}
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
}
