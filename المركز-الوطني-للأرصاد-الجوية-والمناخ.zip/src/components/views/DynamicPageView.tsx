import React, { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { ArrowRight, Info, CheckCircle, ChevronRight, FileText } from 'lucide-react';
import pagesData from '../../data/pagesData.json';

export default function DynamicPageView() {
  const location = useLocation();
  const pageName = location.pathname.split('/').pop() as string;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    setLoading(true);
    // Simulate slight delay for smooth transition
    const timer = setTimeout(() => {
      setData((pagesData as any)[pageName] || null);
      setLoading(false);
    }, 300);
    return () => clearTimeout(timer);
  }, [pageName]);

  if (loading) {
    return (
      <div className="w-full flex-1 min-h-[70vh] flex items-center justify-center bg-[#1e2338]/50 backdrop-blur-md rounded-3xl border border-white/5 shadow-2xl relative z-0">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="w-full flex-1 min-h-[70vh] flex flex-col items-center justify-center bg-[#1e2338]/50 backdrop-blur-md rounded-3xl border border-white/5 shadow-2xl relative z-0">
        <FileText size={48} className="text-gray-500 mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">الصفحة غير متوفرة</h2>
        <p className="text-gray-400 mb-6">عذراً، لم يتم العثور على الصفحة المطلوبة.</p>
        <Link to="/weather" className="px-6 py-2 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-500 transition-colors flex items-center gap-2">
          العودة للرئيسية <ArrowRight size={18} />
        </Link>
      </div>
    );
  }

  return (
    <div className="w-full flex-1 rounded-3xl overflow-hidden min-h-[70vh] flex flex-col relative z-0 bg-[#161a27] border border-white/5 shadow-2xl">
      {/* Dynamic Header */}
      <div className="bg-gradient-to-br from-blue-900/40 to-[#1e2338] p-8 md:p-12 border-b border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4 tracking-tight leading-tight">{data.title}</h1>
          {data.description && (
            <p className="text-lg text-blue-200/80 max-w-2xl mx-auto leading-relaxed">{data.description}</p>
          )}
        </div>
      </div>

      {/* Dynamic Content */}
      <div className="flex-1 p-6 md:p-10 overflow-y-auto custom-scrollbar">
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6">
          {data.sections && data.sections.map((section: any, idx: number) => (
            <div key={idx} className="bg-[#1e2338] rounded-2xl p-6 md:p-8 border border-white/5 shadow-xl hover:border-blue-500/20 transition-all group flex flex-col">
              {section.title && (
                <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
                  <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400 group-hover:scale-110 transition-transform">
                    <Info size={24} />
                  </div>
                  <h2 className="text-xl font-bold text-white leading-tight">{section.title}</h2>
                </div>
              )}
              
              <div className="flex-1 flex flex-col gap-4">
                {section.paragraphs && section.paragraphs.map((p: string, pIdx: number) => (
                  <p key={pIdx} className="text-gray-300 leading-relaxed">{p}</p>
                ))}
                
                {section.list && section.list.length > 0 && (
                  <ul className="space-y-3 mt-2">
                    {section.list.map((li: string, liIdx: number) => (
                      <li key={liIdx} className="flex items-start gap-3 text-gray-300">
                        <CheckCircle size={18} className="text-blue-500 shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{li}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ))}
          {(!data.sections || data.sections.length === 0) && (
             <div className="col-span-full py-20 text-center text-gray-500">
               المحتوى قيد التحديث...
             </div>
          )}
        </div>
      </div>
    </div>
  );
}
