import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { CheckCircle2, Server, Wind, Thermometer } from 'lucide-react';

interface VerifiedData {
  _id: string;
  date: string;
  region: string;
  forecastData: {
    windSpeed: number;
    temperature: number;
    condition: string;
  };
  approvedBy: string;
  exportedAt: string;
}

export default function VerifiedWindyData() {
  const [data, setData] = useState<VerifiedData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('/api/windy-data')
      .then(res => {
        if (res.data.status === 'ok' || res.data.status === 'mock') {
          setData(res.data.data);
        }
      })
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="text-gray-400 text-sm animate-pulse">جاري تحميل البيانات المعتمدة...</div>;
  }

  if (data.length === 0) {
    return <div className="text-gray-500 text-sm">لا توجد بيانات معتمدة حالياً.</div>;
  }

  return (
    <div className="bg-[#161a27] border border-emerald-500/20 rounded-3xl p-6 shadow-xl relative overflow-hidden mt-8 mb-8">
      {/* Background ambient glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-[80px] pointer-events-none"></div>

      <div className="flex items-center gap-3 mb-6 relative z-10">
        <div className="p-2 bg-emerald-500/20 rounded-lg">
          <Server size={20} className="text-emerald-400" />
        </div>
        <div>
          <h3 className="font-bold text-white text-lg">بيانات ويندي المعتمدة (MongoDB)</h3>
          <p className="text-xs text-emerald-400 flex items-center gap-1">
            <CheckCircle2 size={12} /> تم مراجعتها من قبل المتنبئين الجويين
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
        {data.map(item => (
          <div key={item._id} className="bg-[#0b0f19] border border-white/5 rounded-2xl p-4 flex flex-col gap-3">
            <div className="flex justify-between items-center border-b border-white/5 pb-2">
              <span className="font-bold text-gray-200">{item.region}</span>
              <span className="text-xs text-gray-500">{new Date(item.date).toLocaleDateString('ar-SY')}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Thermometer size={16} className="text-orange-400" />
                <span className="text-sm text-gray-300 font-bold">{item.forecastData.temperature}°</span>
              </div>
              <div className="flex items-center gap-2">
                <Wind size={16} className="text-cyan-400" />
                <span className="text-sm text-gray-300 font-bold">{item.forecastData.windSpeed} كم/س</span>
              </div>
              <div className="text-sm text-gray-400">
                {item.forecastData.condition}
              </div>
            </div>

            <div className="text-[10px] text-gray-500 mt-2 bg-white/5 p-2 rounded-lg flex justify-between">
              <span>بواسطة: {item.approvedBy}</span>
              <span>مُصدرة في: {new Date(item.exportedAt).toLocaleTimeString('ar-SY')}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
