import { CloudLightning, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-[#1e2338] text-gray-300 border-t border-white/10 mt-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          
          {/* Logo and Brand */}
          <div className="md:col-span-4 space-y-6">
            <Link to="/" className="flex items-center gap-3">
              <div className="p-1.5 bg-blue-600 rounded-lg">
                <CloudLightning size={26} className="text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-white leading-tight">وزارة الطوارئ وإدارة الكوارث</span>
              </div>
            </Link>
            <p className="text-sm text-gray-500">
              © وزارة الطوارئ وإدارة الكوارث 2026
            </p>
            <div className="inline-flex items-center gap-2 border border-white/10 rounded-lg px-3 py-1.5 bg-white/5">
              <span className="text-xs font-bold text-white">Digital Public Goods Badge</span>
            </div>
          </div>

          {/* Products */}
          <div className="md:col-span-4">
            <h4 className="text-white font-bold mb-4 text-lg border-b border-white/10 pb-2">منتجاتنا</h4>
            <ul className="space-y-3 text-sm font-medium">
              <li><Link to="/forecasts/daily" className="hover:text-blue-400 transition-colors">النشرة اليومية</Link></li>
              <li><Link to="/forecasts/weekly" className="hover:text-blue-400 transition-colors">النشرة الأسبوعية</Link></li>
              <li><Link to="/forecasts/monthly" className="hover:text-blue-400 transition-colors">النشرة الشهرية</Link></li>
              <li><Link to="/forecasts/seasonal" className="hover:text-blue-400 transition-colors">النشرة الموسمية</Link></li>
              <li><a href="#" className="hover:text-blue-400 transition-colors flex items-center gap-1">منصة الغابات ومراقبة الحرائق التابعة للهيئة العامة للاستشعار عن بعد <ExternalLink size={12} /></a></li>
              <li><Link to="/marine" className="hover:text-blue-400 transition-colors">الاشعارات الملاحية</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div className="md:col-span-4">
            <h4 className="text-white font-bold mb-4 text-lg border-b border-white/10 pb-2">خدماتنا</h4>
            <ul className="space-y-3 text-sm font-medium">
              <li><Link to="/forecasts" className="hover:text-blue-400 transition-colors">تنبؤات الطقس</Link></li>
              <li><Link to="/gis" className="hover:text-blue-400 transition-colors">نظم المعلومات الجغرافية</Link></li>
            </ul>
          </div>

        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="bg-[#161a27] border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-medium text-gray-500">
          <p>© وزارة الطوارئ وإدارة الكوارث 2026</p>
          <div className="flex gap-4">
            <span>بدعم من Climweb v1.1.8</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
