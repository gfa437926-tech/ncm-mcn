import { ArrowLeft, Clock } from 'lucide-react';
import { NewsItem } from '../types';

interface NewsFeedProps {
  news: NewsItem[];
}

export default function NewsFeed({ news }: NewsFeedProps) {
  // هنا نكتب الكود الذي يبحث في قاعدة البيانات اسمه كذا الخاص بأخبار المركز الوطني للأرصاد الجوية لكي اقوم لاحقا ببرمجته
  
  return (
    <section id="news" className="bg-white py-16 border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-10">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-2">أخبار المركز</h2>
            <p className="text-slate-500">أحدث النشرات والتقارير الصادرة عن المركز الوطني للأرصاد الجوية والمناخ</p>
          </div>
          <button className="hidden sm:flex items-center gap-2 text-blue-600 font-medium hover:text-blue-800 transition-colors">
            عرض كل الأخبار
            <ArrowLeft size={18} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {news.map((item) => (
            <article key={item.id} className="group cursor-pointer">
              <div className="relative h-64 mb-4 overflow-hidden rounded-2xl">
                <img 
                  src={item.imageUrl} 
                  alt={item.title}
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-500 mb-2">
                <Clock size={14} />
                <span>{item.date}</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors line-clamp-2">
                {item.title}
              </h3>
              <p className="text-slate-600 line-clamp-3">
                {item.excerpt}
              </p>
            </article>
          ))}
        </div>
        
        <button className="w-full mt-8 sm:hidden py-4 rounded-xl bg-slate-100 text-slate-800 font-bold hover:bg-slate-200 transition-colors">
          عرض كل الأخبار
        </button>
      </div>
    </section>
  );
}
