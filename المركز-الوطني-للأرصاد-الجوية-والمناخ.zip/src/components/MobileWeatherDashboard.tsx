import { useState } from 'react';
import { User, Menu, X, LayoutDashboard, Microscope, Map as MapIcon, Newspaper, BookOpen, Library, MapPin, Search, ChevronDown, AlertTriangle, FileText, Activity } from 'lucide-react';
import { WeatherData, City } from '../types';
import DashboardView from './views/DashboardView';
import ResearchView from './views/ResearchView';
import SyriaMapView from './views/SyriaMapView';
import MediaSection from './MediaSection';
import LibraryView from './views/LibraryView';
import KnowledgeBaseView from './views/KnowledgeBaseView';
import DataRequestView from './views/DataRequestView';

interface Props {
  data: WeatherData;
  cities?: City[];
  selectedCity?: City;
  onCityChange?: (city: City) => void;
}

type ViewType = 'dashboard' | 'research' | 'map' | 'news' | 'library' | 'knowledge' | 'datarequest';

export default function MobileWeatherDashboard({ data, cities, selectedCity, onCityChange }: Props) {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [menuOpen, setMenuOpen] = useState(false);
  const [showCitySelector, setShowCitySelector] = useState(false);
  const [citySearch, setCitySearch] = useState('');

  const getTitle = () => {
    switch (currentView) {
      case 'dashboard': return 'المرصد المناخي';
      case 'stations': return 'بيانات المحطات';
      case 'research': return 'المرصد المناخي - الأبحاث';
      case 'map': return 'خريطة سوريا التفاعلية';
      case 'news': return 'الأخبار والتحديثات';
      case 'library': return 'المكتبة الرقمية';
      case 'knowledge': return 'المركز المعرفي';
      case 'datarequest': return 'طلب بيانات مناخية';
    }
  };

  const navItems = [
    { id: 'dashboard', label: 'الرئيسية', icon: <LayoutDashboard size={20} /> },
    { id: 'stations', label: 'المحطات', icon: <Activity size={20} /> },
    { id: 'map', label: 'الخريطة التفاعلية', icon: <MapIcon size={20} /> },
    { id: 'knowledge', label: 'المركز المعرفي (المقالات)', icon: <Library size={20} /> },
    { id: 'research', label: 'الأبحاث والتحليلات', icon: <Microscope size={20} /> },
    { id: 'library', label: 'المكتبة الرقمية', icon: <BookOpen size={20} /> },
    { id: 'news', label: 'الأخبار', icon: <Newspaper size={20} /> },
    { id: 'datarequest', label: 'طلب بيانات مناخية', icon: <FileText size={20} /> },
  ] as const;

  const filteredCities = cities?.filter(c => c.name.includes(citySearch)) || [];

  const MOCK_ALERTS = [
    "تحذير: عاصفة رملية متوقعة على المناطق الشرقية والبادية خلال الـ 24 ساعة القادمة.",
    "تنبيه: انخفاض ملموس على درجات الحرارة ليل الخميس في المرتفعات الجبلية.",
    "إرشاد: تدني مستوى الرؤية الأفقية بسبب الضباب الكثيف في المنطقة الساحلية."
  ];

  return (
    <div className="bg-transparent min-h-screen text-slate-50 font-sans w-full max-w-lg mx-auto relative overflow-x-hidden" dir="rtl">
      
      {/* Header */}
      <div className="flex justify-between items-start p-4 pt-6 sticky top-0 bg-[#0b0f19]/80 backdrop-blur-xl z-[500] border-b border-white/5 shadow-lg">
        <div className="flex gap-3">
          <button 
            onClick={() => setMenuOpen(true)}
            className="w-10 h-10 bg-[#161a27] rounded-full flex items-center justify-center border border-white/10 text-gray-300 shadow-md hover:bg-white/5 transition-colors"
          >
            <Menu size={18} />
          </button>
        </div>
        <div className="text-left flex flex-col items-end" dir="ltr">
          <button 
            onClick={() => setShowCitySelector(!showCitySelector)}
            className="flex items-center gap-1.5 text-lg font-bold tracking-tight text-white hover:text-blue-400 transition-colors"
          >
            <MapPin size={16} className="text-blue-500" />
            {selectedCity?.name || 'دمشق'}
            <ChevronDown size={16} className={`transition-transform ${showCitySelector ? 'rotate-180' : ''}`} />
          </button>
          <p className="text-[11px] text-gray-500 mt-0.5">{new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
      </div>

      {/* News Ticker Mobile */}
      <div className="bg-red-500/10 border-b border-red-500/20 flex items-center overflow-hidden h-10 relative z-[400] shadow-[0_4px_15px_rgba(239,68,68,0.1)]">
        <div className="bg-red-500 text-white px-3 h-full text-xs font-bold flex items-center gap-1.5 z-10 shadow-[4px_0_10px_rgba(0,0,0,0.2)]">
          <AlertTriangle size={14} className="animate-pulse" />
          عاجل
        </div>
        <div className="flex-1 overflow-hidden relative h-full flex items-center">
          <div className="animate-ticker text-red-300 text-[11px] font-medium leading-none">
            {MOCK_ALERTS.join('     •     ')}
          </div>
        </div>
      </div>

      {/* Mobile City Selector Dropdown */}
      {showCitySelector && (
        <div className="absolute top-20 left-4 right-4 bg-[#161a27]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl z-[600] overflow-hidden animate-in fade-in slide-in-from-top-4">
          <div className="p-3 border-b border-white/10 bg-black/20">
            <div className="flex items-center gap-2 bg-[#0b0f19] rounded-xl px-3 py-2 border border-white/5">
              <Search size={16} className="text-gray-400" />
              <input 
                type="text" 
                placeholder="ابحث عن مدينة..." 
                value={citySearch}
                onChange={e => setCitySearch(e.target.value)}
                className="bg-transparent border-none outline-none text-sm w-full text-white placeholder-gray-500"
              />
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto custom-scrollbar p-2">
            {filteredCities.map(city => (
              <button 
                key={city.id}
                onClick={() => {
                  onCityChange?.(city);
                  setShowCitySelector(false);
                  setCitySearch('');
                }}
                className={`w-full text-right px-4 py-3 rounded-xl text-sm transition-colors mb-1 ${selectedCity?.id === city.id ? 'bg-blue-600 text-white font-bold' : 'text-gray-300 hover:bg-white/5'}`}
              >
                {city.name}
              </button>
            ))}
            {filteredCities.length === 0 && (
              <div className="p-4 text-center text-sm text-gray-500">لا توجد نتائج</div>
            )}
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="w-full">
        {currentView === 'dashboard' && <DashboardView data={data} />}
        {currentView === 'stations' && <div className="w-full h-[85vh] p-4"><iframe src="/pages/stations.html" className="w-full h-full rounded-2xl border-none"></iframe></div>}
        {currentView === 'research' && <ResearchView />}
        {currentView === 'map' && <SyriaMapView />}
        {currentView === 'news' && <MediaSection />}
        {currentView === 'library' && <LibraryView />}
        {currentView === 'knowledge' && <KnowledgeBaseView />}
        {currentView === 'datarequest' && <DataRequestView />}
      </div>

      {/* Fullscreen Mobile Menu */}
      {menuOpen && (
        <div className="fixed inset-0 bg-[#0b0f19]/95 backdrop-blur-2xl z-[1000] flex flex-col p-6 animate-in slide-in-from-right-full duration-300" dir="rtl">
          <div className="flex justify-between items-center mb-10 pb-4 border-b border-white/10">
             <h2 className="text-xl font-bold text-white bg-clip-text text-transparent bg-gradient-to-l from-white to-gray-400">القائمة الرئيسية</h2>
             <button 
              onClick={() => setMenuOpen(false)}
              className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center border border-white/10 text-gray-300 hover:bg-white/10 transition-colors"
            >
              <X size={20} />
            </button>
          </div>
          
          <div className="flex flex-col gap-3">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentView(item.id);
                  setMenuOpen(false);
                }}
                className={`flex items-center gap-4 p-4 rounded-2xl transition-all ${
                  currentView === item.id 
                    ? 'bg-blue-600/20 border border-blue-500/30 text-blue-400 shadow-inner' 
                    : 'bg-[#161a27] border border-white/5 text-gray-300 hover:bg-white/5'
                }`}
              >
                {item.icon}
                <span className="font-bold">{item.label}</span>
              </button>
            ))}
            
            <div className="mt-8 grid grid-cols-2 gap-3 opacity-80">
              <div className="rounded-2xl overflow-hidden aspect-video border border-white/10 shadow-lg relative group">
                <div className="absolute inset-0 bg-blue-900/30 mix-blend-overlay z-10"></div>
                <img src="https://images.unsplash.com/photo-1561484930-974554019ade?w=400&q=80" alt="Weather Tech" className="w-full h-full object-cover mix-blend-luminosity z-0" />
              </div>
              <div className="rounded-2xl overflow-hidden aspect-video border border-white/10 shadow-lg relative group">
                <div className="absolute inset-0 bg-blue-900/30 mix-blend-overlay z-10"></div>
                <img src="https://images.unsplash.com/photo-1454789476662-53eb23ba5907?w=400&q=80" alt="Storm" className="w-full h-full object-cover mix-blend-luminosity z-0" />
              </div>
            </div>
            
          </div>
        </div>
      )}

    </div>
  );
}
