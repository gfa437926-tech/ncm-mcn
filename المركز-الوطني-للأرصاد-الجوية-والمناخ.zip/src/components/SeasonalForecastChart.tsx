import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { CalendarDays, TrendingUp } from 'lucide-react';

interface SeasonalForecastChartProps {
  currentTemp: number;
}

export default function SeasonalForecastChart({ currentTemp }: SeasonalForecastChartProps) {
  // Generate data for the next 6 months
  const chartData = useMemo(() => {
    const data = [];
    const date = new Date();
    
    const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    
    for (let i = 1; i <= 6; i++) {
      const nextMonth = new Date(date.getFullYear(), date.getMonth() + i, 1);
      const monthIndex = nextMonth.getMonth();
      
      // Northern Hemisphere simple temperature curve estimation (Syria context)
      const isSummer = monthIndex >= 5 && monthIndex <= 8;
      const isWinter = monthIndex === 11 || monthIndex <= 2;
      
      let expectedMax = 25;
      let expectedMin = 15;
      
      if (isSummer) {
        expectedMax = 32 + (monthIndex === 6 || monthIndex === 7 ? 5 : 0) + Math.random() * 2;
        expectedMin = 20 + (monthIndex === 6 || monthIndex === 7 ? 4 : 0) + Math.random() * 2;
      } else if (isWinter) {
        expectedMax = 12 + Math.random() * 4;
        expectedMin = 4 + Math.random() * 3;
      } else {
        // Spring / Autumn
        expectedMax = 22 + Math.random() * 4;
        expectedMin = 12 + Math.random() * 3;
      }
      
      data.push({
        name: months[monthIndex],
        max: Math.round(expectedMax),
        min: Math.round(expectedMin),
        avg: Math.round((expectedMax + expectedMin) / 2)
      });
    }
    return data;
  }, [currentTemp]);

  return (
    <div className="bg-[#161a27] rounded-3xl p-6 border border-white/5 shadow-xl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/10 rounded-xl">
            <CalendarDays className="text-purple-400" size={24} />
          </div>
          <div>
            <h3 className="font-bold text-white text-lg">التوقعات الموسمية</h3>
            <p className="text-sm text-gray-400">اتجاهات درجات الحرارة للأشهر الستة القادمة</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-gray-400 bg-white/5 px-3 py-1.5 rounded-full">
          <TrendingUp size={14} className="text-purple-400" />
          مؤشرات مناخية
        </div>
      </div>
      
      <div className="h-64 w-full" dir="ltr">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorMaxSeason" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#f97316" stopOpacity={0.0}/>
              </linearGradient>
              <linearGradient id="colorMinSeason" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} dy={10} />
            <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
            <Tooltip 
              contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.1)', color: '#fff' }}
              itemStyle={{ fontWeight: 'bold' }}
              labelStyle={{ color: '#94a3b8', marginBottom: '4px' }}
            />
            <Area type="monotone" name="العظمى" dataKey="max" stroke="#f97316" strokeWidth={3} fill="url(#colorMaxSeason)" />
            <Area type="monotone" name="الصغرى" dataKey="min" stroke="#3b82f6" strokeWidth={3} fill="url(#colorMinSeason)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      <div className="flex items-center justify-center gap-6 mt-4 border-t border-white/5 pt-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.6)]"></div>
          <span className="text-sm font-medium text-gray-300">متوسط العظمى</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]"></div>
          <span className="text-sm font-medium text-gray-300">متوسط الصغرى</span>
        </div>
      </div>
    </div>
  );
}
