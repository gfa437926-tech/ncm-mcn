import { Map, Plane, Radar, Shield, ThermometerSun, Radio } from 'lucide-react';

export default function AboutServices() {
  const services = [
    {
      icon: <Radar size={32} className="text-blue-500" />,
      title: 'رادار الطقس',
      description: 'صور رادارية حية ومباشرة لمراقبة حركة السحب والأمطار في جميع أنحاء البلاد.'
    },
    {
      icon: <ThermometerSun size={32} className="text-orange-500" />,
      title: 'المناخ والبحوث',
      description: 'دراسات مناخية وأبحاث علمية حول التغيرات المناخية وتأثيرها على البيئة والمجتمع.'
    },
    {
      icon: <Plane size={32} className="text-sky-500" />,
      title: 'أرصاد الطيران',
      description: 'معلومات دقيقة لحركة الملاحة الجوية وتأمين سلامة الطيران عبر تقارير METAR و TAF.'
    },
    {
      icon: <Map size={32} className="text-emerald-500" />,
      title: 'الخرائط التفاعلية',
      description: 'خرائط تفاعلية متطورة تعرض الضغط الجوي، اتجاه الرياح، ودرجات الحرارة.'
    },
    {
      icon: <Shield size={32} className="text-indigo-500" />,
      title: 'خدمات الطوارئ',
      description: 'التعاون المستمر مع الدفاع المدني والجهات المختصة لتقديم الدعم أثناء الكوارث.'
    },
    {
      icon: <Radio size={32} className="text-red-500" />,
      title: 'نظام الإنذار المبكر',
      description: 'بث تحذيرات الطقس العنيف للجمهور والجهات الحكومية لتقليل المخاطر والأضرار.'
    }
  ];

  return (
    <section id="services" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">عن المركز وخدماته</h2>
          <p className="text-lg text-slate-600">
            يعمل المركز الوطني للأرصاد الجوية والمناخ على تقديم أدق المعلومات المناخية والتحذيرات المبكرة لضمان سلامة الأرواح والممتلكات، وفق أحدث المعايير العالمية.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => (
            <div key={idx} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-16 h-16 rounded-2xl bg-slate-50 flex items-center justify-center mb-6">
                {service.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
              <p className="text-slate-600 leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
