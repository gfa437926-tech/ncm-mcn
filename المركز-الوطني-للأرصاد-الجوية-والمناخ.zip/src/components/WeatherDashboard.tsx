import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Area, Bar, ComposedChart, ResponsiveContainer, Tooltip, XAxis, YAxis, LabelList } from 'recharts';
import { Home, ChevronDown, Droplets, Wind, CloudLightning, ArrowUp, ArrowDown, MapPin, Search, AlertTriangle, Leaf, Sun, Moon, Sunrise, Sunset, History, Calendar, Map, Volume2 } from 'lucide-react';
import { WeatherData, City } from '../types';
import WeatherIcon from './WeatherIcon';
import VerifiedWindyData from './views/VerifiedWindyData';
import SyriaMapView from './views/SyriaMapView';
import WeatherBot from './WeatherBot';
import SeasonalForecastChart from './SeasonalForecastChart';
import { useLongPress } from '../hooks/useLongPress';

interface WeatherDashboardProps {
  data: WeatherData;
  cities?: City[];
  selectedCity?: City;
  onCityChange?: (city: City) => void;
  loading?: boolean;
}

export default function WeatherDashboard({ data, cities, selectedCity, onCityChange, loading }: WeatherDashboardProps) {
  const [activeTabId, setActiveTabId] = useState('temp');
  const [showCityDropdown, setShowCityDropdown] = useState(false);
  const [citySearch, setCitySearch] = useState('');

  const getUvImpact = (uv: number) => {
    if (uv <= 2) return 'منخفض';
    if (uv <= 5) return 'متوسط';
    if (uv <= 7) return 'عالي';
    if (uv <= 10) return 'عالي جداً';
    return 'شديد';
  };

  const getWindCategory = (speed: number) => {
    if (speed < 1) return 'ساكن';
    if (speed <= 5) return 'هواء خفيف';
    if (speed <= 11) return 'نسيم خفيف';
    if (speed <= 19) return 'نسيم لطيف';
    if (speed <= 28) return 'نسيم معتدل';
    if (speed <= 38) return 'نسيم نشط';
    if (speed <= 49) return 'رياح قوية';
    if (speed <= 61) return 'عاصف';
    if (speed <= 74) return 'عاصفة شديدة';
    return 'إعصار';
  };

  const hourlyTabs = [
    { id: 'temp', label: 'نظرة عامة', dataKey: 'temp', color: '#fbbf24', unit: '°' },
    { id: 'precip', label: 'الهطول', dataKey: 'precipitationProbability', color: '#60a5fa', unit: '%' },
    { id: 'wind', label: 'الرياح', dataKey: 'windSpeed', color: '#a78bfa', unit: ' كم/س' },
    { id: 'aqi', label: 'جودة الهواء', dataKey: 'airQuality', color: '#34d399', unit: '' },
    { id: 'humidity', label: 'الرطوبة', dataKey: 'humidity', color: '#22d3ee', unit: '%' },
    { id: 'cloud', label: 'الغطاء السحابي', dataKey: 'cloudCover', color: '#94a3b8', unit: '%' },
    { id: 'pressure', label: 'الضغط', dataKey: 'pressure', color: '#fb923c', unit: ' mb' },
    { id: 'uv', label: 'الأشعة البنفسجية', dataKey: 'uvIndex', color: '#f472b6', unit: '' },
    { id: 'visibility', label: 'الرؤية', dataKey: 'visibility', color: '#cbd5e1', unit: ' كم' },
    { id: 'feelsLike', label: 'الإحساس الحقيقي', dataKey: 'feelsLike', color: '#f87171', unit: '°' },
    { id: 'dew', label: 'نقطة الندى', dataKey: 'dewPoint', color: '#10b981', unit: '°' },
  ];

  const activeTab = hourlyTabs.find(t => t.id === activeTabId) || hourlyTabs[0];

  const chartData = data.hourly;

  const filteredCities = cities?.filter(c => c.name.includes(citySearch)) || [];

  const MOCK_ALERTS = [
    "تحذير: عاصفة رملية متوقعة على المناطق الشرقية والبادية خلال الـ 24 ساعة القادمة.",
    "تنبيه: انخفاض ملموس على درجات الحرارة ليل الخميس في المرتفعات الجبلية.",
    "إرشاد: تدني مستوى الرؤية الأفقية بسبب الضباب الكثيف في المنطقة الساحلية."
  ];

  const readWeatherSummary = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const message = `الطقس حالياً في ${data.current.location}. درجة الحرارة ${data.current.temp} درجة مئوية. سرعة الرياح ${data.current.windSpeed} كيلومتر في الساعة. والجو ${data.current.condition}. يتوقع أن تكون العظمى ${data.daily[0]?.maxTemp} والصغرى ${data.daily[0]?.minTemp}.`;
      
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'ar-SA';
      window.speechSynthesis.speak(utterance);
    }
  };

  const longPressProps = useLongPress(readWeatherSummary, undefined, { delay: 600 });

  const getDynamicDescription = () => {
    if (!chartData || chartData.length === 0) return '';
    const values = chartData.map(d => Number(d[activeTab.dataKey as keyof typeof d])).filter(v => !isNaN(v));
    if (values.length === 0) return '';
    
    const max = Math.max(...values);
    const min = Math.min(...values);
    const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
    
    switch (activeTabId) {
      case 'temp':
        return `تشير التوقعات إلى أن درجات الحرارة ستتراوح بين ${min}° كحد أدنى و ${max}° كحد أقصى، بمتوسط ${avg}°. ${max > 30 ? 'يُتوقع طقس حار نسبياً، يُنصح بشرب السوائل.' : ''}`;
      case 'precip':
        return `تتراوح احتمالية هطول الأمطار بين ${min}% و ${max}%. ${max > 50 ? 'فرصة جيدة لهطول الأمطار، لا تنسَ المظلة.' : 'الطقس جاف غالباً.'}`;
      case 'wind':
        return `سرعة الرياح ستكون بين ${min} كم/س و ${max} كم/س. ${max > 40 ? 'رياح قوية متوقعة، يرجى توخي الحذر.' : 'الرياح هادئة إلى معتدلة.'}`;
      case 'humidity':
        return `تتراوح نسبة الرطوبة بين ${min}% و ${max}%. ${max > 70 ? 'رطوبة عالية قد تزيد من الإحساس بالحرارة.' : ''}`;
      case 'cloud':
        return `الغطاء السحابي سيكون بين ${min}% و ${max}%. ${max < 20 ? 'سماء صافية بمعظم الأوقات.' : avg > 70 ? 'سماء غائمة بشكل عام.' : 'سماء غائمة جزئياً.'}`;
      case 'pressure':
        return `يتراوح الضغط الجوي بين ${min} و ${max} مليبار.`;
      case 'uv':
        return `يصل مؤشر الأشعة فوق البنفسجية إلى أقصى حد ${max}. ${max >= 6 ? 'تأكد من استخدام واقي الشمس إذا خرجت.' : ''}`;
      case 'visibility':
        return `مستوى الرؤية الأفقية سيكون بين ${min} كم و ${max} كم. ${min < 2 ? 'تنبيه: رؤية ضعيفة في بعض الأوقات، قد يكون هناك ضباب.' : ''}`;
      default:
        return `القيم تتراوح بين ${min} و ${max} بمتوسط ${avg}.`;
    }
  };

  return (
    <div 
      className={`space-y-6 transition-opacity duration-300 ${loading ? 'opacity-50' : 'opacity-100'}`}
    >
      
      <WeatherBot weatherData={data} />
      
      {/* News Ticker */}
      <div className="bg-red-500/10 border border-red-500/20 rounded-xl flex items-center overflow-hidden mb-2 shadow-[0_0_15px_rgba(239,68,68,0.1)]">
        <div className="bg-red-500 text-white px-4 py-3 font-bold flex items-center gap-2 z-10 whitespace-nowrap shadow-lg">
          <AlertTriangle size={18} className="animate-pulse" />
          عاجل
        </div>
        <div className="flex-1 overflow-hidden relative h-full flex items-center">
          <div className="animate-ticker text-red-300 text-sm font-medium">
            {MOCK_ALERTS.join('     •     ')}
          </div>
        </div>
      </div>

      {/* Header / City Selector */}
      <div className="flex items-center gap-3 text-white mb-6 relative z-50">
        <div className="relative">
          <button 
            onClick={() => setShowCityDropdown(!showCityDropdown)}
            className="text-2xl font-bold flex items-center gap-2 hover:text-blue-400 transition-colors bg-transparent border-none outline-none"
          >
            <MapPin size={24} className="text-blue-500" />
            {data.current.location}
            <ChevronDown size={20} className={`transition-transform duration-300 ${showCityDropdown ? 'rotate-180' : ''}`} />
          </button>
          
          {showCityDropdown && (
            <div className="absolute top-full mt-4 right-0 w-72 bg-[#1a1d2d]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-in slide-in-from-top-2">
              <div className="p-3 border-b border-white/10 bg-black/20">
                <div className="flex items-center gap-2 bg-[#0b0f19] rounded-xl px-3 py-2 border border-white/5">
                  <Search size={16} className="text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="ابحث عن مدينة..." 
                    value={citySearch}
                    onChange={e => setCitySearch(e.target.value)}
                    className="bg-transparent border-none outline-none text-sm w-full text-white placeholder-gray-500"
                  />
                </div>
              </div>
              <div className="max-h-60 overflow-y-auto custom-scrollbar">
                {filteredCities.map(city => (
                  <button 
                    key={city.id}
                    onClick={() => {
                      onCityChange?.(city);
                      setShowCityDropdown(false);
                      setCitySearch('');
                    }}
                    className={`w-full text-right px-4 py-3 text-sm hover:bg-white/10 transition-colors border-b border-white/5 last:border-0 ${selectedCity?.id === city.id ? 'text-blue-400 font-bold bg-blue-500/10' : 'text-gray-300'}`}
                  >
                    {city.name}
                  </button>
                ))}
                {filteredCities.length === 0 && (
                  <div className="p-4 text-center text-sm text-gray-500">لا توجد نتائج</div>
                )}
              </div>
            </div>
          )}
        </div>
        
        <button className="p-2 rounded-full hover:bg-white/10 transition-colors mr-2">
          <Home size={20} />
        </button>
      </div>

      {/* Top Section: Current Weather & Map Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_minmax(0,1.2fr)] gap-6">
        
        {/* Current Weather Card - Premium Design */}
        <div 
          {...longPressProps}
          className="bg-gradient-to-br from-[#161a27] to-[#0f121b] border border-white/5 rounded-3xl p-8 relative overflow-hidden flex flex-col justify-between min-h-[340px] shadow-[0_8px_30px_rgba(0,0,0,0.4)] transition-all active:scale-[0.98]"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <div className="flex justify-between items-start z-10">
            <div>
              <h2 className="text-sm font-bold text-gray-400 tracking-wider">الطقس الحالي</h2>
              <p className="text-xs text-gray-500 mt-1">{data.hourly[0]?.time || 'الآن'}</p>
            </div>
            <Link 
              to="/route"
              className="text-xs bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-full flex items-center gap-2 transition-colors shadow-lg"
            >
              <Map size={14} />
              خريطة المسار والتحذيرات
            </Link>
          </div>
          
          <div className="flex items-center gap-8 mt-6 mb-8 z-10">
            <WeatherIcon status={data.current.icon} size={110} className="drop-shadow-2xl" />
            <div className="flex items-start">
              <span className="text-[6rem] font-light leading-none tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400 clickable-text cursor-pointer">{data.current.temp}°</span>
            </div>
            <div className="flex flex-col ml-4 border-l border-white/10 pl-6 h-full justify-center">
              <span className="text-3xl font-medium mb-2 text-white clickable-text cursor-pointer">{data.current.condition}</span>
              <span className="text-sm text-gray-400 clickable-text cursor-pointer">الإحساس الحقيقي {data.current.feelsLike}°</span>
            </div>
          </div>
          
          <p className="text-sm text-gray-300 mb-8 z-10 leading-relaxed max-w-md clickable-text cursor-pointer">الجو سيكون {data.current.condition}. الصغرى المتوقعة لليوم هي {data.daily[0]?.minTemp}°.</p>
          
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-4 pt-6 border-t border-white/10 z-10">
            <div className="flex flex-col gap-1">
              <span className="text-xs text-gray-500">الرياح ({getWindCategory(data.current.windSpeed)})</span>
              <span className="text-sm font-bold text-gray-200">{data.current.windSpeed} كم/س</span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-xs text-gray-500">الرطوبة</span>
              <span className="text-sm font-bold text-gray-200">{data.current.humidity}%</span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-xs text-gray-500">مؤشر UV ({getUvImpact(data.current.uvIndex)})</span>
              <span className="text-sm font-bold text-gray-200">{data.current.uvIndex}</span>
            </div>
            <div className="flex flex-col gap-1 hidden sm:flex">
              <span className="text-xs text-gray-500">الرؤية</span>
              <span className="text-sm font-bold text-gray-200">{data.current.visibility} كم</span>
            </div>
            <div className="flex flex-col gap-1 hidden sm:flex">
              <span className="text-xs text-gray-500">الضغط</span>
              <span className="text-sm font-bold text-gray-200">{data.current.pressure} mb</span>
            </div>
            <div className="flex flex-col gap-1 hidden sm:flex">
              <span className="text-xs text-gray-500">نقطة الندى</span>
              <span className="text-sm font-bold text-gray-200">{data.current.dewPoint}°</span>
            </div>
          </div>
        </div>

        {/* Map Card */}
        <div className="bg-[#161a27] rounded-3xl overflow-hidden relative min-h-[340px] border border-white/5 shadow-xl">
           <SyriaMapView />
        </div>
      </div>

      {/* Hourly / Overview Section */}
      <div className="mt-10">
        <div className="flex items-center gap-3 overflow-x-auto hide-scrollbar mb-6 pb-2">
          <h3 className="text-xl font-bold ml-6 shrink-0 text-white">كل ساعة</h3>
          {hourlyTabs.map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTabId(tab.id)}
              className={`px-5 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all shadow-sm ${
                activeTabId === tab.id 
                  ? 'bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]' 
                  : 'bg-[#1a1d2d] text-gray-400 hover:bg-white/10 hover:text-white border border-white/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Daily Tabs (horizontal strip) */}
        <div className="flex gap-4 overflow-x-auto hide-scrollbar mb-6 pb-4">
          {data.daily.slice(0, 7).map((day, idx) => (
            <div key={idx} className={`min-w-[140px] rounded-3xl p-5 flex flex-col justify-between cursor-pointer transition-all ${
              idx === 0 
                ? 'bg-gradient-to-br from-[#1e2338] to-[#161a27] border border-blue-500/30 shadow-lg shadow-blue-500/10' 
                : 'bg-[#161a27] border border-white/5 hover:border-white/20 hover:bg-[#1a1d2d]'
            }`}>
              <div className="flex justify-between items-center mb-4">
                <span className={`text-sm font-bold ${idx === 0 ? 'text-white' : 'text-gray-400'}`}>{idx === 0 ? 'اليوم' : day.dayName}</span>
                <span className="text-xs text-gray-500">{new Date(day.date).getDate()}</span>
              </div>
              <div className="flex justify-center mb-4 scale-110">
                <WeatherIcon status={day.icon} size={42} />
              </div>
              <div className="flex justify-between items-center mt-auto font-medium">
                <span className="text-lg text-white">{day.maxTemp}°</span>
                <span className="text-sm text-gray-500">{day.minTemp}°</span>
              </div>
              {day.precipitationChance > 0 && (
                <div className="text-[10px] text-blue-400 mt-2 flex items-center justify-center gap-1 font-bold">
                  <Droplets size={10} /> {day.precipitationChance}%
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Chart Area */}
        <div className="bg-gradient-to-br from-[#161a27] to-[#0f121b] border border-white/5 rounded-3xl p-8 shadow-xl">
          <div className="flex justify-between mb-8 items-center">
             <h4 className="font-bold text-lg text-white">{activeTab.label}</h4>
             {activeTabId === 'temp' && (
               <label className="flex items-center gap-3 text-sm text-gray-400 cursor-pointer hover:text-white transition-colors">
                 <div className="w-10 h-5 bg-black/50 border border-white/10 rounded-full relative transition-colors shadow-inner">
                   <div className="w-4 h-4 bg-gray-500 rounded-full absolute left-0.5 top-0.5 shadow-sm"></div>
                 </div>
                 الإحساس الحقيقي
               </label>
             )}
          </div>
          
          <div className="h-[280px] w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={{ top: 30, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorDynamicChart" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={activeTab.color} stopOpacity={0.5}/>
                    <stop offset="95%" stopColor={activeTab.color} stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" axisLine={{ stroke: 'rgba(255,255,255,0.1)' }} tickLine={false} tick={{ fontSize: 12, fill: '#64748b', fontWeight: 500 }} interval="preserveStartEnd" minTickGap={40} />
                <YAxis yAxisId="primary" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} domain={['auto', 'auto']} />
                {activeTabId === 'temp' && (
                  <YAxis yAxisId="secondary" orientation="right" axisLine={false} tickLine={false} domain={[0, 100]} hide />
                )}
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.1)', color: '#fff', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.5)', backdropFilter: 'blur(8px)' }}
                  itemStyle={{ fontWeight: 'bold' }}
                  labelStyle={{ color: '#94a3b8', marginBottom: '8px' }}
                />
                
                {activeTabId === 'temp' && (
                  <Bar yAxisId="secondary" dataKey="precipitationProbability" fill="#3b82f6" fillOpacity={0.3} radius={[4, 4, 0, 0]} name="فرصة الهطول" />
                )}
                
                <Area yAxisId="primary" type="monotone" dataKey={activeTab.dataKey} stroke={activeTab.color} strokeWidth={4} fill="url(#colorDynamicChart)" activeDot={{ r: 6, strokeWidth: 0, fill: activeTab.color }} name={activeTab.label}>
                  {(activeTabId === 'temp' || activeTabId === 'wind' || activeTabId === 'precip') && (
                    <LabelList 
                      dataKey={activeTab.dataKey} 
                      position="top" 
                      fill="#f8fafc" 
                      fontSize={13} 
                      fontWeight="bold" 
                      formatter={(val: any) => `${val}${activeTab.unit}`} 
                      offset={12} 
                    />
                  )}
                </Area>
                {activeTabId === 'temp' && (
                  <Area yAxisId="primary" type="monotone" dataKey="feelsLike" stroke="#f87171" strokeDasharray="5 5" strokeWidth={2} fillOpacity={0} name="الإحساس الحقيقي" />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 p-4 bg-white/5 border border-white/10 rounded-xl text-sm text-gray-300">
            <p className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
              {getDynamicDescription()}
            </p>
          </div>
        </div>
      </div>
      
      {/* Extra Details Grid: MSN Style Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-8">
        
        {/* Temperature */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">درجة الحرارة</h4>
          <div className="flex-1 relative flex items-end">
            {/* Simple sparkline placeholder */}
            <svg className="absolute w-full h-12 bottom-8" viewBox="0 0 100 30" preserveAspectRatio="none">
              <path d="M0,15 Q25,5 50,15 T100,25" fill="none" stroke="#60a5fa" strokeWidth="3" vectorEffect="non-scaling-stroke"/>
              <circle cx="80" cy="20" r="4" fill="#60a5fa" stroke="#161a27" strokeWidth="2"/>
            </svg>
            <div className="text-3xl font-bold text-white relative z-10 w-full text-right">{data.current.temp}°</div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-yellow-400">
              <span className="w-2 h-2 rounded-full bg-yellow-400 inline-block"></span> مستقر
            </div>
            <div className="text-gray-400 truncate mt-1">مستقر عند {data.current.temp}°. غداً أبرد.</div>
          </div>
        </div>

        {/* Feels Like */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">الإحساس الحقيقي</h4>
          <div className="flex-1 relative flex flex-col justify-center">
            <svg className="absolute w-full h-12 top-0" viewBox="0 0 100 30" preserveAspectRatio="none">
              <path d="M0,10 L80,20 L100,20" fill="none" stroke="#60a5fa" strokeWidth="3" vectorEffect="non-scaling-stroke" opacity="0.5"/>
              <circle cx="80" cy="20" r="4" fill="#fff" stroke="#60a5fa" strokeWidth="2"/>
            </svg>
            <div className="mt-12 text-xs text-gray-500">العامل المؤثر: الرياح</div>
            <div className="flex gap-4 mt-1">
              <div>
                <span className="text-xs text-gray-400">الإحساس:</span>
                <span className="text-xl font-bold text-white ml-1">{data.current.feelsLike}°</span>
              </div>
              <div>
                <span className="text-xs text-gray-400">الحرارة:</span>
                <span className="text-xl font-bold text-white ml-1">{data.current.temp}°</span>
              </div>
            </div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-blue-400">
              مريح <ArrowDown size={12}/>
            </div>
            <div className="text-gray-400 truncate mt-1">يبدو أبرد بسبب الرياح.</div>
          </div>
        </div>

        {/* Cloud Cover */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">الغطاء السحابي</h4>
          <div className="flex-1 flex items-center justify-center relative">
            <svg viewBox="0 0 100 100" className="w-24 h-24 transform -rotate-90">
              <circle cx="50" cy="50" r="40" fill="none" stroke="#1f2937" strokeWidth="10" />
              <circle cx="50" cy="50" r="40" fill="none" stroke="#94a3b8" strokeWidth="10" strokeDasharray="251.2" strokeDashoffset={251.2 - (data.current.cloudCover / 100) * 251.2} strokeLinecap="round" className="transition-all duration-1000 ease-out" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-white leading-none">{data.current.cloudCover}%</span>
              <span className="text-[10px] text-gray-400 mt-1">{data.current.cloudCover === 0 ? 'صافي' : data.current.cloudCover < 50 ? 'جزئي' : 'غائم'}</span>
            </div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-gray-300">
              <CloudLightning size={12}/> الغيوم تغطي {data.current.cloudCover}%
            </div>
            <div className="text-gray-400 truncate mt-1">{data.current.cloudCover === 0 ? 'سماء صافية ورؤية ممتازة' : 'سماء ملبدة ببعض الغيوم'}</div>
          </div>
        </div>

        {/* Precipitation */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">الهطول</h4>
          <div className="flex-1 flex flex-col items-center justify-center relative">
            <div className="w-20 h-20 rounded-full border border-blue-500/30 bg-blue-500/10 flex items-center justify-center flex-col">
              <span className="text-2xl font-bold text-white">0 <span className="text-sm">مم</span></span>
              <span className="text-[10px] text-gray-400">خلال 24س</span>
            </div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-yellow-400">
              لا يوجد هطول <span className="w-2 h-2 rounded-full bg-yellow-400 inline-block"></span>
            </div>
            <div className="text-gray-400 truncate mt-1">لا يتوقع هطول لـ 24س القادمة.</div>
          </div>
        </div>

        {/* Wind */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">الرياح</h4>
          <div className="flex-1 flex items-center justify-center relative mt-2">
             <svg viewBox="0 0 100 50" className="w-full h-full max-h-24 overflow-visible mt-4">
               {/* Background Arc */}
               <path d="M 10 45 A 40 40 0 0 1 90 45" fill="none" stroke="#1f2937" strokeWidth="8" strokeLinecap="round" />
               {/* Value Arc */}
               <path d="M 10 45 A 40 40 0 0 1 90 45" fill="none" stroke="#3b82f6" strokeWidth="8" strokeLinecap="round" strokeDasharray="125.6" strokeDashoffset={125.6 - (Math.min(data.current.windSpeed, 100) / 100) * 125.6} />
               {/* Tick marks */}
               {Array.from({ length: 11 }).map((_, i) => {
                 const angle = Math.PI - (i * Math.PI) / 10;
                 const x1 = 50 + 32 * Math.cos(angle);
                 const y1 = 45 - 32 * Math.sin(angle);
                 const x2 = 50 + 38 * Math.cos(angle);
                 const y2 = 45 - 38 * Math.sin(angle);
                 return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={i % 2 === 0 ? "#94a3b8" : "#475569"} strokeWidth={i % 2 === 0 ? 2 : 1} />;
               })}
               {/* Needle */}
               <g style={{ transform: `rotate(${180 * (Math.min(data.current.windSpeed, 100) / 100)}deg)`, transformOrigin: '50px 45px' }} className="transition-transform duration-1000 ease-out">
                  <polygon points="48,45 52,45 50,15" fill="#f87171" />
                  <circle cx="50" cy="45" r="4" fill="#f87171" />
               </g>
             </svg>
             <div className="absolute bottom-0 flex flex-col items-center">
                <span className="text-xl font-bold text-white leading-none">{data.current.windSpeed}</span>
                <span className="text-[10px] text-gray-400">كم/س</span>
             </div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-blue-400">
              {getWindCategory(data.current.windSpeed)} <span className="w-2 h-2 rounded-full bg-blue-400 inline-block"></span>
            </div>
            <div className="text-gray-400 truncate mt-1">اتجاه الرياح: {data.current.windDirection}°</div>
          </div>
        </div>

        {/* Humidity */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">الرطوبة</h4>
          <div className="flex-1 flex items-center justify-between gap-4">
             <div className="flex gap-1 h-16 items-end">
                {[40, 50, 60, 70, 69, 50, 40].map((h, i) => (
                  <div key={i} className="w-2 bg-blue-500/20 rounded-full h-full relative overflow-hidden">
                    <div className="absolute bottom-0 w-full bg-blue-500 rounded-full" style={{ height: `${h}%` }}></div>
                  </div>
                ))}
             </div>
             <div className="flex flex-col">
                <span className="text-2xl font-bold text-white">{data.current.humidity}%</span>
                <span className="text-[10px] text-gray-400">الرطوبة النسبية</span>
                <span className="text-lg font-bold text-white mt-1">15°</span>
                <span className="text-[10px] text-gray-400">نقطة الندى</span>
             </div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-blue-400">
              طبيعي <ArrowUp size={12}/>
            </div>
            <div className="text-gray-400 truncate mt-1">ترتفع تدريجياً لتبلغ 78% غداً.</div>
          </div>
        </div>

        {/* UV */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">مؤشر UV</h4>
          <div className="flex-1 flex items-center justify-center relative">
            <svg viewBox="0 0 100 50" className="w-28 overflow-visible">
               <path d="M10,50 A40,40 0 0,1 90,50" fill="none" stroke="#333" strokeWidth="6" strokeLinecap="round"/>
               <path d="M10,50 A40,40 0 0,1 70,15" fill="none" stroke="#a855f7" strokeWidth="6" strokeLinecap="round"/>
               <circle cx="70" cy="15" r="4" fill="#fff" stroke="#a855f7" strokeWidth="2"/>
            </svg>
            <div className="absolute text-3xl font-bold text-white mt-4">{data.current.uvIndex}</div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-yellow-400">
              عالي <span className="w-2 h-2 rounded-full bg-yellow-400 inline-block"></span>
            </div>
            <div className="text-gray-400 truncate mt-1">مستويات الأشعة البنفسجية ستكون عالية.</div>
          </div>
        </div>

        {/* AQI */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">جودة الهواء</h4>
          <div className="flex-1 flex items-center justify-center relative">
            <svg viewBox="0 0 100 100" className="w-24 overflow-visible transform -rotate-90">
               <circle cx="50" cy="50" r="45" fill="none" stroke="#333" strokeWidth="6" strokeLinecap="round"/>
               <circle cx="50" cy="50" r="45" fill="none" stroke="#eab308" strokeWidth="6" strokeLinecap="round" strokeDasharray="282.7" strokeDashoffset="180"/>
               <circle cx="10" cy="70" r="4" fill="#fff" stroke="#eab308" strokeWidth="2"/>
            </svg>
            <div className="absolute text-3xl font-bold text-white">{data.current.airQuality}</div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-blue-400">
              معتدل <ArrowDown size={12}/>
            </div>
            <div className="text-gray-400 truncate mt-1">الملوث الأساسي: الأوزون 47 ppb.</div>
          </div>
        </div>

        {/* Pollen */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">حبوب اللقاح</h4>
          <div className="flex-1 flex flex-col items-center justify-center relative mt-2">
            <svg viewBox="0 0 100 50" className="w-28 overflow-visible">
               <path d="M10,50 A40,40 0 0,1 90,50" fill="none" stroke="#333" strokeWidth="6" strokeLinecap="round"/>
               <path d="M10,50 A40,40 0 0,1 80,24" fill="none" stroke="#f97316" strokeWidth="6" strokeLinecap="round"/>
               <circle cx="80" cy="24" r="4" fill="#fff" stroke="#f97316" strokeWidth="2"/>
            </svg>
            <div className="absolute text-2xl font-bold text-white mt-4">69</div>
            <div className="text-[10px] text-gray-400 mt-2 text-center">المسبب الرئيسي: الأعشاب</div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-yellow-400">
              عالي <span className="w-2 h-2 rounded-full bg-yellow-400 inline-block"></span>
            </div>
            <div className="text-gray-400 truncate mt-1">توقع مستويات مشابهة للغد.</div>
          </div>
        </div>

        {/* Visibility */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">الرؤية</h4>
          <div className="flex-1 flex flex-col items-center justify-center gap-1">
             <div className="w-12 h-1.5 bg-emerald-400/30 rounded-full"></div>
             <div className="w-16 h-1.5 bg-emerald-400/50 rounded-full"></div>
             <div className="w-20 h-1.5 bg-emerald-400/70 rounded-full"></div>
             <div className="w-24 h-1.5 bg-emerald-400/90 rounded-full"></div>
             <div className="w-28 h-1.5 bg-emerald-400 rounded-full"></div>
             <div className="text-2xl font-bold text-white mt-2">10 <span className="text-sm">كم</span></div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-blue-400">
              ممتازة <ArrowDown size={12}/>
            </div>
            <div className="text-gray-400 truncate mt-1">الرؤية ستكون مشابهة لليوم.</div>
          </div>
        </div>

        {/* Pressure */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">الضغط</h4>
          <div className="flex-1 relative flex items-center justify-center">
            <svg className="absolute w-full h-12" viewBox="0 0 100 30" preserveAspectRatio="none">
              <path d="M0,20 Q50,15 100,25" fill="none" stroke="#a855f7" strokeWidth="3" vectorEffect="non-scaling-stroke"/>
              <circle cx="80" cy="19" r="4" fill="#fff" stroke="#a855f7" strokeWidth="2"/>
            </svg>
            <div className="text-2xl font-bold text-white relative z-10 w-full text-center mt-8">1023 <span className="text-xs text-gray-400 font-normal">mb<br/>الآن</span></div>
          </div>
          <div className="mt-auto border-t border-white/10 pt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-blue-400">
              يرتفع <ArrowUp size={12}/>
            </div>
            <div className="text-gray-400 truncate mt-1">توقع بارتفاع الضغط خلال 3 ساعات.</div>
          </div>
        </div>

        {/* Sun */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">الشمس</h4>
          <div className="flex-1 flex flex-col items-center justify-center relative mt-2">
            <svg viewBox="0 0 100 50" className="w-full overflow-visible">
               <path d="M10,40 Q50,-10 90,40" fill="none" stroke="#333" strokeWidth="2" strokeLinecap="round" strokeDasharray="4 4"/>
               <path d="M10,40 Q30,10 40,2" fill="none" stroke="#f43f5e" strokeWidth="3" strokeLinecap="round"/>
               <circle cx="10" cy="40" r="3" fill="#fff"/>
               <circle cx="90" cy="40" r="3" fill="#fff"/>
               <circle cx="40" cy="2" r="4" fill="#fff" stroke="#f43f5e" strokeWidth="2"/>
               <line x1="0" y1="40" x2="100" y2="40" stroke="#444" strokeWidth="1"/>
            </svg>
            <div className="text-[10px] text-gray-300 mt-2 font-bold">16 س 11 دقيقة</div>
            <div className="flex justify-between w-full mt-1 px-2">
              <div className="text-center"><div className="text-sm font-bold text-white">05:00</div><div className="text-[10px] text-gray-500">شروق</div></div>
              <div className="text-center"><div className="text-sm font-bold text-white">21:11</div><div className="text-[10px] text-gray-500">غروب</div></div>
            </div>
          </div>
        </div>

        {/* Weather Overview */}
        <div className="bg-[#161a27] border border-white/5 rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col h-48 md:col-span-2 cursor-pointer hover:bg-white/5 transition-colors">
          <h4 className="font-semibold text-gray-300 mb-2">نظرة عامة على الطقس</h4>
          <div className="flex-1 flex items-center justify-between gap-4 mt-2">
             <div className="relative w-32 h-32 flex items-center justify-center shrink-0">
               <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                 <circle cx="50" cy="50" r="40" fill="none" stroke="#0ea5e9" strokeWidth="12" strokeDasharray="25 251.2" strokeLinecap="round"/>
                 <circle cx="50" cy="50" r="40" fill="none" stroke="#f97316" strokeWidth="12" strokeDasharray="200 251.2" strokeDashoffset="-35" strokeLinecap="round"/>
               </svg>
               <div className="absolute flex flex-col items-center justify-center text-center">
                 <span className="text-xs text-gray-400">{new Date().getFullYear()}</span>
                 <span className="text-lg font-bold text-white leading-none">{new Date().toLocaleDateString('en-US', { month: 'short' })}</span>
               </div>
             </div>
             <div className="flex-1 grid grid-cols-2 gap-x-4 gap-y-3">
               <div className="flex items-center gap-2">
                 <span className="w-3 h-3 rounded-full bg-orange-500 flex-shrink-0"></span>
                 <div className="flex flex-col">
                   <span className="text-[10px] text-gray-400">أيام مشمسة/غائمة</span>
                   <span className="text-sm font-bold text-white leading-none">29</span>
                 </div>
               </div>
               <div className="flex items-center gap-2">
                 <span className="w-3 h-3 rounded-full bg-sky-500 flex-shrink-0"></span>
                 <div className="flex flex-col">
                   <span className="text-[10px] text-gray-400">أيام ماطرة/مثلجة</span>
                   <span className="text-sm font-bold text-white leading-none">2</span>
                 </div>
               </div>
               <div className="flex items-center gap-2">
                 <ArrowUp size={14} className="text-red-400 flex-shrink-0" />
                 <div className="flex flex-col">
                   <span className="text-[10px] text-gray-400">متوسط العظمى</span>
                   <span className="text-sm font-bold text-white leading-none">26°</span>
                 </div>
               </div>
               <div className="flex items-center gap-2">
                 <ArrowDown size={14} className="text-blue-400 flex-shrink-0" />
                 <div className="flex flex-col">
                   <span className="text-[10px] text-gray-400">متوسط الصغرى</span>
                   <span className="text-sm font-bold text-white leading-none">15°</span>
                 </div>
               </div>
             </div>
          </div>
        </div>

      </div>

      {/* Verified Windy Data from MongoDB */}
      <VerifiedWindyData />
      
      {/* Seasonal Forecast Chart */}
      <div className="mt-10 mb-8">
        <SeasonalForecastChart currentTemp={data.current.temp} />
      </div>
      
      {/* 14-Day Forecast Table */}
      <div className="mt-10 mb-8">
        <h3 className="text-xl font-bold ml-6 mb-6 text-white">توقعات 14 يوماً</h3>
        <div className="bg-[#161a27] border border-white/5 rounded-3xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right text-gray-300">
              <thead className="text-xs uppercase bg-[#1a1d2d] text-gray-400">
                <tr>
                  <th scope="col" className="px-6 py-4">اليوم</th>
                  <th scope="col" className="px-6 py-4 text-center">الحالة</th>
                  <th scope="col" className="px-6 py-4 text-center">العظمى</th>
                  <th scope="col" className="px-6 py-4 text-center">الصغرى</th>
                  <th scope="col" className="px-6 py-4 text-center">الهطول</th>
                  <th scope="col" className="px-6 py-4 text-center">مؤشر UV</th>
                </tr>
              </thead>
              <tbody>
                {data.daily.slice(0, 14).map((day, idx) => (
                  <tr key={idx} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 font-bold text-white flex items-center gap-3">
                      <span className="w-8">{idx === 0 ? 'اليوم' : day.dayName}</span>
                      <span className="text-xs text-gray-500 font-normal">{new Date(day.date).getDate()}/{new Date(day.date).getMonth() + 1}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-center">
                        <WeatherIcon status={day.icon} size={28} />
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center font-bold text-white">{day.maxTemp}°</td>
                    <td className="px-6 py-4 text-center text-gray-400">{day.minTemp}°</td>
                    <td className="px-6 py-4 text-center">
                      {day.precipitationChance > 0 ? (
                        <div className="flex items-center justify-center gap-1 text-blue-400">
                          <Droplets size={14} /> {day.precipitationChance}%
                        </div>
                      ) : (
                        <span className="text-gray-600">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center">
                         <span className="px-2 py-1 rounded-md text-xs font-bold bg-white/5 text-pink-400">{day.uvIndex || '-'}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
    </div>
  );
}
