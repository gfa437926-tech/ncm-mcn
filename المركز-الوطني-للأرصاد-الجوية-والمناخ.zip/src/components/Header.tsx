import { CloudLightning, Menu, Search, Globe, AlertTriangle, ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';
import NotificationBell from './NotificationBell';

export default function Header({ onMenuClick }: { onMenuClick?: () => void }) {
  return (
    <header className="bg-[#1e2338] text-white sticky top-0 z-50 shadow-md border-b border-white/10">
      {/* Top Utility Bar */}
      <div className="bg-[#161a27] border-b border-white/5 py-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 font-bold text-gray-300">
              <span className="w-5 h-3 rounded-sm border border-gray-600 block shadow-sm relative overflow-hidden flex flex-col">
                <div className="h-1/3 bg-[#007a3d]"></div>
                <div className="h-1/3 bg-white flex items-center justify-center">
                  <div className="flex gap-[1px] text-[#ce1126] leading-none" style={{fontSize: '5px'}}>
                    <span>★</span><span>★</span><span>★</span>
                  </div>
                </div>
                <div className="h-1/3 bg-black"></div>
              </span>
              SYR
            </div>
            <Link to="/alerts" className="flex items-center gap-1.5 text-red-400 hover:text-red-300 transition-colors font-bold px-2 py-1 bg-red-500/10 rounded-md">
              <ShieldAlert size={14} />
              تنبيهات CAP Alerts
            </Link>
            <NotificationBell />
          </div>
          <div className="flex items-center gap-4 text-gray-400">
            <button className="flex items-center gap-1 hover:text-white transition-colors">
              <Globe size={14} /> لغة
            </button>
            <button className="flex items-center gap-1 hover:text-white transition-colors">
              <Search size={14} /> يبحث
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-4">
            <button onClick={onMenuClick} className="p-2 hover:bg-white/10 rounded-md lg:hidden">
              <Menu size={24} />
            </button>
            <Link to="/" className="flex items-center gap-3">
              <div className="p-1.5 bg-blue-600 rounded-lg">
                <CloudLightning size={26} className="text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-blue-300 font-bold uppercase tracking-wider">وزارة الطوارئ وإدارة الكوارث</span>
                <span className="text-sm font-bold leading-tight">المركز الوطني للأرصاد الجوية</span>
              </div>
            </Link>
          </div>
          
          
        </div>
      </div>

      {/* Alert Ticker */}
      <div className="bg-red-500/10 border-b border-red-500/20 py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-3">
          <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse flex items-center gap-1">
            <AlertTriangle size={12} /> Alert
          </span>
          <p className="text-red-400 text-sm font-bold truncate">
            تحذير صحي: ازدياد حالات الإصابة باللشمانيا في عدد من المحافظات
          </p>
        </div>
      </div>
    </header>
  );
}
