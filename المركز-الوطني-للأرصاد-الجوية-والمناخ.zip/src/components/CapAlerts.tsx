import { AlertTriangle, Info, ShieldAlert } from 'lucide-react';
import { CapAlert } from '../types';

interface CapAlertsProps {
  alerts: CapAlert[];
}

export default function CapAlerts({ alerts }: CapAlertsProps) {
  if (!alerts || alerts.length === 0) return null;

  const getSeverityColors = (severity: string) => {
    switch (severity) {
      case 'Extreme': return 'bg-red-600 text-white border-red-800';
      case 'Severe': return 'bg-orange-500 text-white border-orange-700';
      case 'Moderate': return 'bg-yellow-400 text-slate-900 border-yellow-600';
      default: return 'bg-blue-100 text-blue-900 border-blue-300';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'Extreme': return <ShieldAlert className="flex-shrink-0" />;
      case 'Severe': return <AlertTriangle className="flex-shrink-0" />;
      case 'Moderate': return <AlertTriangle className="flex-shrink-0" />;
      default: return <Info className="flex-shrink-0" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 space-y-3">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-3 h-3 rounded-full bg-red-600 animate-pulse"></div>
        <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wider">نظام الإنذار المبكر (CAP)</h2>
      </div>
      
      {alerts.map(alert => (
        <div 
          key={alert.id} 
          className={`rounded-lg border-r-4 p-4 shadow-sm flex items-start gap-4 ${getSeverityColors(alert.severity)}`}
        >
          {getSeverityIcon(alert.severity)}
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1">
              <h3 className="font-bold text-lg leading-tight">{alert.headline}</h3>
              <span className="text-xs font-semibold px-2 py-1 rounded bg-black/10 whitespace-nowrap">
                {alert.event}
              </span>
            </div>
            <p className="text-sm opacity-90">{alert.description}</p>
            <div className="mt-3 text-xs font-medium opacity-75 flex gap-4">
              <span>ساري من: {alert.effective}</span>
              <span>ينتهي: {alert.expires}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
