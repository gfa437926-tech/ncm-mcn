import React, { useEffect, useState } from 'react';

interface ForecastData {
  _id: string;
  stationId: { name: string };
  date: string;
  temperature_max: number;
  temperature_min: number;
  description: string;
}

export default function ForecastsTable() {
  const [forecasts, setForecasts] = useState<ForecastData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/forecasts')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'ok' || data.status === 'mock') {
          setForecasts(data.data);
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white w-full animate-in fade-in duration-500">
      <h2 className="text-2xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-l from-white to-gray-400">توقعات محطات الرصد</h2>
      
      {loading ? (
        <div className="animate-pulse flex flex-col space-y-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-12 bg-white/5 rounded-xl w-full"></div>
          ))}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-gray-400">
                <th className="p-4 font-medium">المحطة</th>
                <th className="p-4 font-medium">التاريخ</th>
                <th className="p-4 font-medium">الحرارة العظمى</th>
                <th className="p-4 font-medium">الحرارة الصغرى</th>
                <th className="p-4 font-medium">الحالة الجوية</th>
              </tr>
            </thead>
            <tbody>
              {forecasts.map((f, i) => (
                <tr key={f._id || i} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="p-4 clickable-text cursor-pointer">{f.stationId?.name || 'محطة غير معروفة'}</td>
                  <td className="p-4 text-gray-300 clickable-text cursor-pointer">{new Date(f.date).toLocaleDateString('ar-EG')}</td>
                  <td className="p-4 text-pink-400 font-bold clickable-text cursor-pointer">{f.temperature_max}°</td>
                  <td className="p-4 text-blue-400 font-bold clickable-text cursor-pointer">{f.temperature_min}°</td>
                  <td className="p-4 clickable-text cursor-pointer">{f.description}</td>
                </tr>
              ))}
              {forecasts.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-gray-500">لا توجد بيانات متاحة حالياً</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
