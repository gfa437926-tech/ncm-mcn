import { useState, useRef, useEffect, ChangeEvent } from 'react';
import { MessageSquare, X, Send, Bot, User, BrainCircuit, Image as ImageIcon, Mic, MicOff, Loader2 } from 'lucide-react';
import axios from 'axios';
import { WeatherData } from '../types';

interface Message {
  id: string;
  role: 'user' | 'bot';
  text: string;
  imageUrl?: string;
}

export default function WeatherBot({ weatherData }: { weatherData: WeatherData }) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'bot', text: 'مرحباً بك! أنا المساعد الآلي لمركز الأرصاد الجوية. كيف يمكنني مساعدتك بمعلومات الطقس اليوم؟' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [interactionId, setInteractionId] = useState<string | undefined>();
  const [useThinking, setUseThinking] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  // Live Voice State
  const [isLive, setIsLive] = useState(false);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    return () => {
      stopLiveVoice();
    };
  }, []);

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !selectedImage) return;
    const userMsg = input.trim();
    const currentImage = selectedImage;
    
    setInput('');
    setSelectedImage(null);
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', text: userMsg, imageUrl: currentImage || undefined }]);
    setIsLoading(true);
    
    try {
      const response = await axios.post('/api/chat', {
        message: userMsg,
        weatherContext: weatherData,
        imageBase64: currentImage,
        previous_interaction_id: interactionId,
        useThinking
      });
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'bot', text: response.data.reply }]);
      if (response.data.interaction_id) {
        setInteractionId(response.data.interaction_id);
      }
    } catch (error: any) {
      console.error(error);
      const errorMessage = error.response?.data?.error || 'عذراً، حدث خطأ أثناء الاتصال بالخادم. يرجى المحاولة لاحقاً.';
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'bot', text: errorMessage }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Live Voice Methods
  const pcmToBase64 = (float32Array: Float32Array) => {
    const buffer = new ArrayBuffer(float32Array.length * 2);
    const view = new DataView(buffer);
    for (let i = 0; i < float32Array.length; i++) {
      let s = Math.max(-1, Math.min(1, float32Array[i]));
      view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  };

  const playAudioChunk = (ctx: AudioContext, base64Audio: string) => {
    const binary = window.atob(base64Audio);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 0x8000;
    }
    const buffer = ctx.createBuffer(1, float32Array.length, 24000);
    buffer.getChannelData(0).set(float32Array);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start();
  };

  const toggleLiveVoice = async () => {
    if (isLive) {
      stopLiveVoice();
    } else {
      await startLiveVoice();
    }
  };

  const startLiveVoice = async () => {
    try {
      setIsLive(true);
      const host = window.location.host;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const websocket = new WebSocket(`${protocol}//${host}/api/live`);
      setWs(websocket);

      const inputAudioCtx = new AudioContext({ sampleRate: 16000 });
      const outputAudioCtx = new AudioContext({ sampleRate: 24000 });
      audioContextRef.current = outputAudioCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const source = inputAudioCtx.createMediaStreamSource(stream);
      const processor = inputAudioCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;
      
      source.connect(processor);
      processor.connect(inputAudioCtx.destination);

      processor.onaudioprocess = (e) => {
        if (websocket.readyState === WebSocket.OPEN) {
          const base64 = pcmToBase64(e.inputBuffer.getChannelData(0));
          websocket.send(JSON.stringify({ audio: base64 }));
        }
      };

      websocket.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.audio) {
          playAudioChunk(outputAudioCtx, msg.audio);
        }
      };

    } catch (err) {
      console.error(err);
      stopLiveVoice();
    }
  };

  const stopLiveVoice = () => {
    setIsLive(false);
    if (ws) {
      ws.close();
      setWs(null);
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 left-6 p-4 bg-blue-600 text-white rounded-full shadow-[0_0_20px_rgba(37,99,235,0.4)] hover:scale-110 transition-transform z-50 ${isOpen ? 'hidden' : 'block'}`}
      >
        <MessageSquare size={28} />
      </button>

      {isOpen && (
        <div className="fixed bottom-6 left-6 w-[350px] sm:w-[450px] h-[600px] bg-[#161a27] border border-white/10 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden animate-in slide-in-from-bottom-5">
          <div className="bg-[#1e2338] border-b border-white/10 p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg relative">
                <Bot size={20} />
                {isLive && <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
              </div>
              <div>
                <h3 className="text-white font-bold text-sm">مساعد الأرصاد الذكي</h3>
                <p className="text-xs text-green-400">متصل الآن {isLive && '(محادثة صوتية نشطة)'}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={toggleLiveVoice}
                className={`p-1.5 rounded-full transition-colors ${isLive ? 'bg-red-500/20 text-red-400' : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'}`}
                title={isLive ? "إيقاف المحادثة الصوتية" : "محادثة صوتية مباشرة"}
              >
                {isLive ? <Mic size={18} /> : <MicOff size={18} />}
              </button>
              <button 
                onClick={() => setUseThinking(!useThinking)}
                className={`p-1.5 rounded-full transition-colors ${useThinking ? 'bg-purple-500/20 text-purple-400' : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10'}`}
                title="تفعيل نمط التفكير العميق"
              >
                <BrainCircuit size={18} />
              </button>
              <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
            {messages.map(msg => (
              <div key={msg.id} className={`flex gap-2 max-w-[90%] ${msg.role === 'user' ? 'mr-auto flex-row-reverse' : 'ml-auto'}`}>
                <div className={`p-1.5 h-fit rounded-full shrink-0 ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-white/10 text-blue-400'}`}>
                  {msg.role === 'user' ? <User size={14} /> : <Bot size={14} />}
                </div>
                <div className={`flex flex-col gap-2 p-3 rounded-2xl text-sm ${msg.role === 'user' ? 'bg-blue-600 text-white rounded-tl-none' : 'bg-white/5 text-gray-200 rounded-tr-none'}`}>
                  {msg.imageUrl && (
                    <img src={msg.imageUrl} alt="User Upload" className="max-w-[200px] rounded-lg border border-white/10" />
                  )}
                  {msg.text && <p className="whitespace-pre-wrap">{msg.text}</p>}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-2 max-w-[85%] ml-auto">
                <div className="p-1.5 h-fit rounded-full shrink-0 bg-white/10 text-blue-400">
                  <Bot size={14} />
                </div>
                <div className="p-3 rounded-2xl bg-white/5 rounded-tr-none flex items-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {selectedImage && (
            <div className="px-4 py-2 border-t border-white/5 bg-black/20 flex items-center gap-2">
              <div className="relative">
                <img src={selectedImage} alt="Selected" className="w-12 h-12 object-cover rounded-lg border border-white/10" />
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 shadow-md"
                >
                  <X size={12} />
                </button>
              </div>
            </div>
          )}

          <div className="p-3 border-t border-white/10 bg-black/20">
            <form 
              onSubmit={e => { e.preventDefault(); handleSend(); }}
              className="flex items-center gap-2 bg-[#0b0f19] rounded-xl px-3 py-2 border border-white/5"
            >
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
              />
              <button 
                type="button" 
                onClick={() => fileInputRef.current?.click()}
                className="text-gray-400 hover:text-blue-400 transition-colors"
                title="إرفاق صورة"
              >
                <ImageIcon size={18} />
              </button>
              
              <input 
                type="text" 
                placeholder="اسأل عن الطقس أو قم بتحليل صورة..." 
                value={input}
                onChange={e => setInput(e.target.value)}
                className="bg-transparent border-none outline-none text-sm w-full text-white placeholder-gray-500"
              />
              <button 
                type="submit" 
                disabled={(!input.trim() && !selectedImage) || isLoading}
                className="text-blue-500 hover:text-blue-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} className="transform rotate-180" />}
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}