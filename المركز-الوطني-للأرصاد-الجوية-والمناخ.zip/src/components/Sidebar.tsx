import { Link, useLocation } from 'react-router-dom';
import { 
  Sun, Map, Library, FileText, Anchor, CloudRain, ShieldAlert,
  Wind, CloudFog, Zap, Layers, Activity, Server, Users, BarChart, Info, Plane
} from 'lucide-react';
import { useState } from 'react';

export default function Sidebar() {
  const location = useLocation();
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({
    departments: false,
    services: false,
    phenomena: false
  });

  const toggleMenu = (key: string) => {
    setOpenMenus(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const isActive = (path: string) => location.pathname === path;

  const mainLinks = [
    { path: '/weather', icon: <Sun size={20} />, label: 'الرئيسية' },
    { path: '/stations-list', icon: <Activity size={20} />, label: 'المحطات' },
    { path: '/route', icon: <Map size={20} />, label: 'مسار الرحلة' },
    { path: '/map', icon: <Map size={20} />, label: 'خريطة المحطات' },
    { path: '/knowledge', icon: <Library size={20} />, label: 'المركز المعرفي' },
    { path: '/page/specialized_library', icon: <FileText size={20} />, label: 'المكتبة المتخصصة' },
    { path: '/page/climate_library', icon: <FileText size={20} />, label: 'المكتبة المناخية' },
    { path: '/request-data', icon: <FileText size={20} />, label: 'طلب بيانات مناخية' },
  ];

  const departmentLinks = [
    { path: '/page/general', icon: <CloudRain size={16} />, label: 'الأرصاد العامة' },
    { path: '/page/marine', icon: <Anchor size={16} />, label: 'الأرصاد البحرية' },
    { path: '/page/climate_hydro', icon: <BarChart size={16} />, label: 'المناخ والهيدرولوجي' },
    { path: '/page/development', icon: <Layers size={16} />, label: 'قسم التطوير' },
    { path: '/page/technical', icon: <Server size={16} />, label: 'الخدمات الفنية' },
    { path: '/page/support', icon: <Users size={16} />, label: 'الخدمات المساندة' },
    { path: '/page/numerical', icon: <Activity size={16} />, label: 'الخدمات العددية' },
  ];

  const servicesLinks = [
    { path: '/page/weather_mod', icon: <CloudRain size={16} />, label: 'تحسين الطقس (الاستمطار)' },
    { path: '/page/aviation', icon: <Plane size={16} />, label: 'الطيران' },
  ];

  const phenomenaLinks = [
    { path: '/page/fog', icon: <CloudFog size={16} />, label: 'الضباب' },
    { path: '/page/dust', icon: <Wind size={16} />, label: 'الغبار' },
    { path: '/page/sandstorms', icon: <ShieldAlert size={16} />, label: 'العواصف الرملية' },
    { path: '/page/thunderstorms', icon: <Zap size={16} />, label: 'العواصف الرعدية' },
    { path: '/page/wind', icon: <Wind size={16} />, label: 'الرياح' },
  ];

  const aboutLinks = [
    { path: '/page/tasks', icon: <Info size={16} />, label: 'مهام المركز' },
    { path: '/page/org_chart', icon: <Layers size={16} />, label: 'الهيكل التنظيمي' },
  ];

  const SidebarLink = ({ path, icon, label, indent = false }: any) => (
    <Link
      to={path}
      className={`flex items-center gap-3 p-2.5 rounded-xl transition-colors w-full text-right ${indent ? 'pr-8' : ''} ${isActive(path) ? 'text-white bg-[#323652]' : 'text-gray-400 hover:text-white hover:bg-[#323652]'}`}
    >
      <div className="shrink-0">{icon}</div>
      <span className="hidden md:block text-sm font-medium">{label}</span>
    </Link>
  );

  return (
    <aside className="w-16 md:w-64 bg-[#1e2338]/90 backdrop-blur-xl flex flex-col py-6 border-l border-white/5 min-h-[calc(100vh-64px)] rounded-tl-3xl rounded-bl-3xl ml-4 my-2 transition-all duration-300 overflow-y-auto custom-scrollbar">
      <div className="flex flex-col gap-1 px-2 flex-1">
        
        {mainLinks.map((item) => (
          <SidebarLink key={item.path} {...item} />
        ))}

        <div className="mt-4 mb-2 px-4 hidden md:block border-t border-white/5 pt-4">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">عن المركز</h3>
        </div>
        {aboutLinks.map((item) => (
          <SidebarLink key={item.path} {...item} />
        ))}

        <div className="mt-4 mb-2 px-4 hidden md:block border-t border-white/5 pt-4">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">الأقسام</h3>
        </div>
        {departmentLinks.map((item) => (
          <SidebarLink key={item.path} {...item} />
        ))}

        <div className="mt-4 mb-2 px-4 hidden md:block border-t border-white/5 pt-4">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">الخدمات المتخصصة</h3>
        </div>
        {servicesLinks.map((item) => (
          <SidebarLink key={item.path} {...item} />
        ))}

        <div className="mt-4 mb-2 px-4 hidden md:block border-t border-white/5 pt-4">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">الظواهر والسلامة</h3>
        </div>
        {phenomenaLinks.map((item) => (
          <SidebarLink key={item.path} {...item} />
        ))}

      </div>
    </aside>
  );
}
