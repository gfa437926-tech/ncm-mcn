import { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, Link } from 'react-router-dom';
import { Sun, MapPin, Map, Activity } from 'lucide-react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import WeatherDashboard from './components/WeatherDashboard';
import MobileWeatherDashboard from './components/MobileWeatherDashboard';
import MediaSection from './components/MediaSection';
import Footer from './components/Footer';

import ClimateLibraryView from './components/views/ClimateLibraryView';
import SpecializedLibraryView from './components/views/SpecializedLibraryView';
import DynamicPageView from './components/views/DynamicPageView';
import AdvancedMapsView from './components/views/AdvancedMapsView';
import KnowledgeBaseView from './components/views/KnowledgeBaseView';
import LibraryView from './components/views/LibraryView';
import IframeView from './components/views/IframeView';
import DataRequestView from './components/views/DataRequestView';
import AlertsView from './components/views/AlertsView';
import GISView from './components/views/GISView';
import StationsTab from './components/StationsTab';
import ForecastsTable from './components/ForecastsTable';
import ECMWFMap from './components/ECMWFMap';
import RouteMapView from './components/views/RouteMapView';
import AdminDashboard from './admin/AdminDashboard';
import { NewsItem, WeatherData, City } from './types';
import { fetchWeatherData, getWeatherCodeDescription, getWeatherStatus } from './services/weatherApi';

export const SYRIAN_CITIES: City[] = [
  { id: 'damascus', name: 'دمشق', lat: 33.5138, lng: 36.2765 },
  { id: 'damascus-airport', name: 'دمشق الدولي', lat: 33.429167, lng: 36.522222 },
  { id: 'aleppo', name: 'حلب', lat: 36.2021, lng: 37.1343 },
  { id: 'homs', name: 'حمص', lat: 34.7318, lng: 36.7139 },
  { id: 'latakia', name: 'اللاذقية', lat: 35.5407, lng: 35.7800 },
  { id: 'deir-ez-zor', name: 'دير الزور', lat: 35.3354, lng: 40.1431 },
  { id: 'hasakah', name: 'الحسكة', lat: 36.5096, lng: 40.7518 },
  { id: 'daraa', name: 'درعا', lat: 32.6183, lng: 36.1013 },
  { id: 'suwayda', name: 'السويداء', lat: 32.7097, lng: 36.5702 },
  { id: 'tartus', name: 'طرطوس', lat: 34.8837, lng: 35.8876 },
  { id: 'hama', name: 'حماة', lat: 35.1318, lng: 36.7579 },
  { id: 'idlib', name: 'إدلب', lat: 35.9296, lng: 36.6311 },
  { id: 'raqqa', name: 'الرقة', lat: 35.9333, lng: 39.0236 },
  { id: 'safita', name: 'safeta', lat: 34.813889, lng: 36.1175 },
  { id: 'tal-abyad', name: 'تل أبيض', lat: 36.6841, lng: 38.9483 },
  { id: 'quneitra', name: 'القنيطرة', lat: 33.1259, lng: 35.8236 },
  { id: 'sarghaya', name: 'سرغايا', lat: 33.7716, lng: 36.0965 },
  { id: 'nabek', name: 'النبك', lat: 34.0258, lng: 36.7285 },
  { id: 'salamiyah', name: 'سلمية', lat: 35.0118, lng: 36.7120 },
  { id: 'qamishli', name: 'القامشلي', lat: 37.0581, lng: 41.2279 },
  { id: 'qardaha', name: 'القرداحة', lat: 35.6300, lng: 35.7900 },
  { id: 'jableh', name: 'جبلة', lat: 35.3296, lng: 35.9184 },
  { id: 'baniyas', name: 'بانياس', lat: 35.182, lng: 35.945 },
  { id: 'jarabulus', name: 'جرابلس', lat: 36.845, lng: 38.045 },
  { id: 'bukamal', name: 'البوكمال', lat: 34.4522, lng: 40.8019 },
  { id: 'palmyra', name: 'تدمر', lat: 34.5536, lng: 38.2682 }
];

const MOCK_NEWS: NewsItem[] = [
  {
    id: '1',
    title: 'توقعات بموجة حر تضرب البلاد الأسبوع القادم',
    excerpt: 'حذر المركز الوطني للأرصاد الجوية والمناخ من موجة حر مرتقبة تؤثر على معظم المناطق السورية...',
    date: '8 تموز 2026',
    imageUrl: 'https://images.unsplash.com/photo-1504370805625-d32c54b16100?q=80&w=2000&auto=format&fit=crop'
  }
];

function AppLayout() {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedCity, setSelectedCity] = useState<City>(SYRIAN_CITIES[0]);
  const location = useLocation();

  const [cities, setCities] = useState<City[]>(SYRIAN_CITIES);

  useEffect(() => {
    const fetchCities = async () => {
      try {
        const res = await fetch('/api/stations');
        const data = await res.json();
        if (data.status === 'ok' && data.data && data.data.length > 0) {
          const fetchedCities = data.data.map((station: any) => ({
            id: station._id,
            name: station.name,
            lat: station.location?.coordinates[1] || 33.5,
            lng: station.location?.coordinates[0] || 36.3
          }));
          setCities(fetchedCities);
          setSelectedCity(fetchedCities[0]);
        }
      } catch (err) {
        console.error("Failed to fetch cities from MongoDB", err);
      }
    };
    fetchCities();
  }, []);

  useEffect(() => {
    const loadWeather = async () => {
      try {
        setLoading(true);
        const data = await fetchWeatherData(selectedCity.lat, selectedCity.lng);
        
        const current = data.current;
        const hourly = data.hourly;
        const daily = data.daily;
        
        const transformedData: WeatherData = {
          current: {
            temp: Math.round(current.temperature_2m),
            condition: getWeatherCodeDescription(current.weather_code),
            feelsLike: Math.round(current.apparent_temperature),
            windSpeed: Math.round(current.wind_speed_10m),
            windDirection: current.wind_direction_10m,
            humidity: Math.round(current.relative_humidity_2m),
            pressure: Math.round(current.pressure_msl),
            visibility: current.visibility / 1000,
            uvIndex: 9,
            dewPoint: Math.round(hourly.dew_point_2m[0]),
            cloudCover: current.cloud_cover,
            isDay: current.is_day === 1,
            icon: getWeatherStatus(current.weather_code, current.is_day === 1),
            location: `${selectedCity.name}، سوريا`
          },
          sunAndMoon: {
            sunrise: new Date(daily.sunrise[0]).toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit', hour12: false}),
            sunset: new Date(daily.sunset[0]).toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit', hour12: false}),
          },
          hourly: hourly.time.slice(0, 24).map((timeStr: string, index: number) => ({
            time: new Date(timeStr).toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit', hour12: false}),
            temp: Math.round(hourly.temperature_2m[index]),
            condition: getWeatherCodeDescription(hourly.weather_code[index]),
            icon: getWeatherStatus(hourly.weather_code[index], true),
            isDay: true,
            precipitationProbability: hourly.precipitation_probability[index],
            windSpeed: Math.round(hourly.wind_speed_10m?.[index] || 0),
            humidity: Math.round(hourly.relative_humidity_2m?.[index] || 0),
            cloudCover: Math.round(hourly.cloud_cover?.[index] || 0),
            pressure: Math.round(hourly.pressure_msl?.[index] || 0),
            uvIndex: Math.round(hourly.uv_index?.[index] || 0),
            visibility: Math.round((hourly.visibility?.[index] || 0) / 1000),
            feelsLike: Math.round(hourly.apparent_temperature?.[index] || 0),
            airQuality: 50 + Math.round(Math.random() * 50),
            dewPoint: Math.round(hourly.dew_point_2m?.[index] || 0)
          })),
          daily: daily.time.map((dateStr: string, index: number) => ({
            date: dateStr,
            dayName: new Date(dateStr).toLocaleDateString('ar-EG', { weekday: 'short' }),
            maxTemp: Math.round(daily.temperature_2m_max[index]),
            minTemp: Math.round(daily.temperature_2m_min[index]),
            condition: getWeatherCodeDescription(daily.weather_code[index]),
            icon: getWeatherStatus(daily.weather_code[index], true),
            precipitationChance: daily.precipitation_probability_max[index],
            uvIndex: daily.uv_index_max?.[index] ? Math.round(daily.uv_index_max[index]) : undefined
          }))
        };
        
        setWeatherData(transformedData);
      } catch (err) {
        setError('فشل في جلب بيانات الطقس');
      } finally {
        setLoading(false);
      }
    };
    
    loadWeather();
  }, [selectedCity]);

  if (loading && !weatherData) return <div className="min-h-screen bg-transparent flex items-center justify-center text-white">جاري تحميل البيانات...</div>;
  if (error) return <div className="min-h-screen bg-transparent flex items-center justify-center text-white">{error}</div>;
  if (!weatherData) return null;

  const isHome = location.pathname === '/' || location.pathname === '/weather';

  const routes = (
    <Routes>
      <Route path="/" element={<Navigate to="/weather" replace />} />
      <Route path="/weather" element={
        <div className="max-w-7xl mx-auto w-full animate-in fade-in duration-500 pb-20 md:pb-0">
          <WeatherDashboard 
            data={weatherData} 
            cities={cities}
            selectedCity={selectedCity}
            onCityChange={setSelectedCity}
            loading={loading}
          />
          <div className="mt-8">
            <MediaSection />
          </div>
        </div>
      } />
      
      <Route path="/map" element={
        <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl overflow-hidden h-[90vh] border border-white/5 shadow-2xl flex flex-col pb-20 md:pb-0">
          <AdvancedMapsView />
        </div>
      } />
      <Route path="/alerts" element={<AlertsView />} />
      <Route path="/gis" element={<GISView />} />
      <Route path="/services" element={<div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white pb-20 md:pb-0"><h2 className="text-2xl font-bold mb-4">خدماتنا</h2><p>الخدمات متوفرة قريباً</p></div>} />
      <Route path="/forecasts" element={<ForecastsTable />} />
      <Route path="/forecasts/:type" element={<ForecastsTable />} />
      <Route path="/satellite" element={<ECMWFMap />} />
      <Route path="/route" element={<RouteMapView />} />
      <Route path="/stations" element={<div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white w-full h-[85vh] pb-20 md:pb-0"><StationsTab /></div>} />
      <Route path="/stations-list" element={<div className="pb-20 md:pb-0 h-full"><StationsTab /></div>} />
      <Route path="/about" element={<div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white pb-20 md:pb-0"><h2 className="text-2xl font-bold mb-4">معلوماتنا</h2><p>معلومات المركز الوطني</p></div>} />
      <Route path="/marine" element={<div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl text-white pb-20 md:pb-0"><h2 className="text-2xl font-bold mb-4">الاشعارات الملاحية</h2><p>الاشعارات الملاحية</p></div>} />
      <Route path="/knowledge" element={
        <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-6 border border-white/5 shadow-2xl pb-20 md:pb-0">
          <KnowledgeBaseView />
        </div>
      } />
      <Route path="/library" element={
        <div className="bg-[#131620]/80 backdrop-blur-md rounded-3xl p-2 md:p-6 border border-white/5 shadow-2xl pb-20 md:pb-0">
          <LibraryView />
        </div>
      } />
            <Route path="/page/climate_library" element={
        <div className="pb-20 md:pb-0 h-full"><ClimateLibraryView /></div>
      } />
      <Route path="/page/specialized_library" element={
        <div className="pb-20 md:pb-0 h-full"><SpecializedLibraryView /></div>
      } />
      {/* Iframe Routes for all the static pages */}
      <Route path="/page/:pageName" element={
        <div className="pb-20 md:pb-0 h-full"><DynamicPageView /></div>
      } />
      <Route path="/request-data" element={
        <div className="pb-20 md:pb-0 h-full"><DataRequestView /></div>
      } />
    </Routes>
  );

  return (
    <div className="min-h-screen bg-transparent font-sans text-slate-50" dir="rtl">
      {/* Unified Layout */}
      <div className="flex flex-col min-h-screen relative">
        <Header onMenuClick={() => setIsMobileMenuOpen(true)} />
        
        <main className="flex flex-1 max-w-[1920px] mx-auto w-full relative">
          <div className="block">
            <Sidebar />
          </div>
          <div className="flex-1 overflow-x-hidden flex flex-col p-4 md:p-6 pb-24 md:pb-6">
            {routes}
          </div>
        </main>
        
        <Footer />
        
        {/* Mobile Bottom Navigation */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#1e2338]/90 backdrop-blur-lg border-t border-white/10 flex justify-around items-center p-3 z-50">
          <Link to="/weather" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/weather') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Sun size={20} />
            <span className="text-[10px]">الرئيسية</span>
          </Link>
          <Link to="/map" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/map') ? 'text-blue-400' : 'text-gray-400'}`}>
            <MapPin size={20} />
            <span className="text-[10px]">الخريطة</span>
          </Link>
          <Link to="/route" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/route') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Map size={20} />
            <span className="text-[10px]">المسار</span>
          </Link>
          <Link to="/stations-list" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/stations') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Activity size={20} />
            <span className="text-[10px]">المحطات</span>
          </Link>
          <button onClick={() => setIsMobileMenuOpen(true)} className="flex flex-col items-center gap-1 text-gray-400 hover:text-blue-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
            <span className="text-[10px]">القائمة</span>
          </button>
        </div>

        {/* Mobile Menu Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-[100] flex">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)}></div>
            <div className="relative w-64 max-w-[80%] bg-[#1e2338] h-full flex flex-col animate-in slide-in-from-right duration-300">
              <div className="p-4 border-b border-white/10 flex justify-between items-center">
                <span className="font-bold text-lg">القائمة الرئيسية</span>
                <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 bg-white/5 rounded-full text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </button>
              </div>
              <div className="flex-1 overflow-y-auto pb-20" onClick={() => setIsMobileMenuOpen(false)}>
                <Sidebar />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function IframeRouteWrapper() {
  const location = useLocation();
  const pageName = location.pathname.split('/').pop();
  return <IframeView src={`/pages/${pageName}.html`} />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/admin/*" element={<AdminDashboard />} />
        <Route path="*" element={<AppLayout />} />
      </Routes>
    </BrowserRouter>
  );
}
