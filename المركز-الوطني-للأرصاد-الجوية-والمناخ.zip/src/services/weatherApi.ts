import axios from 'axios';

// WMO Weather interpretation codes (https://open-meteo.com/en/docs)
export const getWeatherCodeDescription = (code: number): string => {
  const codes: Record<number, string> = {
    0: 'صافي',
    1: 'غالبا صافي',
    2: 'غائم جزئيا',
    3: 'غائم',
    45: 'ضباب',
    48: 'ضباب صقيعي',
    51: 'رذاذ خفيف',
    53: 'رذاذ معتدل',
    55: 'رذاذ كثيف',
    56: 'رذاذ متجمد خفيف',
    57: 'رذاذ متجمد كثيف',
    61: 'مطر خفيف',
    63: 'مطر معتدل',
    65: 'مطر غزير',
    66: 'مطر متجمد خفيف',
    67: 'مطر متجمد غزير',
    71: 'ثلج خفيف',
    73: 'ثلج معتدل',
    75: 'ثلج كثيف',
    77: 'حبيبات ثلجية',
    80: 'زخات مطر خفيفة',
    81: 'زخات مطر معتدلة',
    82: 'زخات مطر غزيرة',
    85: 'زخات ثلج خفيفة',
    86: 'زخات ثلج كثيفة',
    95: 'عاصفة رعدية',
    96: 'عاصفة رعدية مع برد خفيف',
    99: 'عاصفة رعدية مع برد كثيف',
  };
  return codes[code] || 'غير معروف';
};

// Map WMO codes to a simpler status for icon selection
export const getWeatherStatus = (code: number, isDay: boolean = true): string => {
  if (code === 0) return isDay ? 'clear-day' : 'clear-night';
  if (code === 1 || code === 2) return isDay ? 'partly-cloudy-day' : 'partly-cloudy-night';
  if (code === 3) return 'cloudy';
  if (code >= 45 && code <= 48) return 'fog';
  if (code >= 51 && code <= 67) return 'rain';
  if (code >= 71 && code <= 77) return 'snow';
  if (code >= 80 && code <= 82) return 'rain'; // showers
  if (code >= 85 && code <= 86) return 'snow'; // snow showers
  if (code >= 95 && code <= 99) return 'thunderstorm';
  return 'clear-day';
};

export const fetchWeatherData = async (lat: number = 33.5131, lon: number = 36.3096) => {
  // دمشق كافتراضي
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,visibility&hourly=temperature_2m,relative_humidity_2m,dew_point_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,pressure_msl,cloud_cover,visibility,wind_speed_10m,wind_direction_10m,uv_index&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,uv_index_max,precipitation_probability_max&timezone=auto&forecast_days=14`;
  
  try {
    const response = await axios.get(url);
    return response.data;
  } catch (error) {
    console.error("Error fetching weather data:", error);
    throw error;
  }
};
