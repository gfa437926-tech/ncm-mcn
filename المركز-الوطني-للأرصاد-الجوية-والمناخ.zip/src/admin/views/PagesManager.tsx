import React, { useState, useEffect } from 'react';
import { Edit2, Save, X, FileText, Plus, Trash2 } from 'lucide-react';

export default function PagesManager() {
  const [pages, setPages] = useState<any>({});
  const [editingPageId, setEditingPageId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<any>(null);

  useEffect(() => {
    fetchPages();
  }, []);

  const fetchPages = () => {
    fetch('/api/cms/pages')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'ok') setPages(data.data);
      });
  };

  const handleEdit = (id: string, page: any) => {
    setEditingPageId(id);
    setEditForm(JSON.parse(JSON.stringify(page))); // deep copy
  };

  const handleSave = async () => {
    try {
      await fetch(`/api/cms/pages/${editingPageId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm)
      });
      setEditingPageId(null);
      fetchPages();
    } catch (err) {
      alert("فشل في حفظ الصفحة");
    }
  };

  if (editingPageId && editForm) {
    return (
      <div className="bg-[#161a27] rounded-2xl border border-white/5 p-6 shadow-2xl">
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-white/10">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Edit2 className="text-blue-500" /> تحرير الصفحة: <span className="text-blue-400 font-mono text-xl">{editingPageId}</span>
          </h2>
          <div className="flex gap-2">
            <button onClick={() => setEditingPageId(null)} className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors flex items-center gap-2">
              <X size={18} /> إلغاء
            </button>
            <button onClick={handleSave} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl font-bold transition-colors flex items-center gap-2 shadow-lg shadow-blue-500/20">
              <Save size={18} /> حفظ التغييرات
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-gray-400 mb-2 font-bold">عنوان الصفحة (Title)</label>
            <input 
              type="text" 
              value={editForm.title || ''} 
              onChange={e => setEditForm({...editForm, title: e.target.value})}
              className="w-full bg-[#1e2338] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
          <div>
            <label className="block text-gray-400 mb-2 font-bold">الوصف (Description)</label>
            <textarea 
              value={editForm.description || ''} 
              onChange={e => setEditForm({...editForm, description: e.target.value})}
              className="w-full bg-[#1e2338] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors h-24 resize-none"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-4">
              <label className="block text-gray-400 font-bold text-lg">أقسام الصفحة (Sections)</label>
              <button 
                onClick={() => setEditForm({...editForm, sections: [...(editForm.sections || []), { title: 'قسم جديد', paragraphs: [], list: [] }]})}
                className="px-3 py-1.5 bg-blue-500/10 text-blue-400 hover:bg-blue-500 hover:text-white rounded-lg flex items-center gap-1 transition-colors text-sm font-bold"
              >
                <Plus size={16} /> إضافة قسم
              </button>
            </div>
            
            <div className="space-y-4">
              {editForm.sections && editForm.sections.map((section: any, idx: number) => (
                <div key={idx} className="bg-[#1e2338] p-4 rounded-xl border border-white/5 relative group">
                  <button 
                    onClick={() => {
                      const newSections = [...editForm.sections];
                      newSections.splice(idx, 1);
                      setEditForm({...editForm, sections: newSections});
                    }}
                    className="absolute top-4 left-4 p-2 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={16} />
                  </button>
                  
                  <input 
                    type="text" 
                    value={section.title || ''} 
                    onChange={e => {
                      const newSections = [...editForm.sections];
                      newSections[idx].title = e.target.value;
                      setEditForm({...editForm, sections: newSections});
                    }}
                    placeholder="عنوان القسم..."
                    className="w-full md:w-1/2 bg-[#161a27] border border-white/10 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500 mb-4 font-bold"
                  />
                  
                  <div className="mb-4">
                    <label className="block text-gray-500 text-sm mb-1">الفقرات (كل سطر فقرة مستقلة)</label>
                    <textarea 
                      value={section.paragraphs ? section.paragraphs.join('\n') : ''}
                      onChange={e => {
                        const newSections = [...editForm.sections];
                        newSections[idx].paragraphs = e.target.value.split('\n').filter(p => p.trim());
                        setEditForm({...editForm, sections: newSections});
                      }}
                      className="w-full bg-[#161a27] border border-white/10 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500 min-h-[80px]"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-500 text-sm mb-1">القوائم والنقاط (كل سطر نقطة مستقلة)</label>
                    <textarea 
                      value={section.list ? section.list.join('\n') : ''}
                      onChange={e => {
                        const newSections = [...editForm.sections];
                        newSections[idx].list = e.target.value.split('\n').filter(p => p.trim());
                        setEditForm({...editForm, sections: newSections});
                      }}
                      className="w-full bg-[#161a27] border border-white/10 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500 min-h-[80px]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#161a27] rounded-2xl border border-white/5 overflow-hidden">
      <div className="p-6 border-b border-white/10 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2 mb-1">
            <FileText className="text-blue-500" /> إدارة محتوى الصفحات
          </h2>
          <p className="text-gray-400 text-sm">قم بتعديل النصوص والمحتوى التعريفي لكافة أقسام الموقع</p>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-right">
          <thead className="bg-[#1e2338]">
            <tr>
              <th className="p-4 text-gray-400 font-bold">معرف الصفحة (الرابط)</th>
              <th className="p-4 text-gray-400 font-bold">عنوان الصفحة</th>
              <th className="p-4 text-gray-400 font-bold w-32">إجراء</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(pages).map(([key, page]: [string, any]) => (
              <tr key={key} className="border-t border-white/5 hover:bg-white/5 transition-colors group">
                <td className="p-4 font-mono text-sm text-blue-400" dir="ltr">{key}</td>
                <td className="p-4 font-bold text-white">{page.title || '-'}</td>
                <td className="p-4">
                  <button 
                    onClick={() => handleEdit(key, page)}
                    className="px-4 py-2 bg-white/5 hover:bg-blue-600 rounded-lg text-sm font-bold transition-colors flex items-center gap-2 group-hover:bg-white/10 group-hover:text-white"
                  >
                    <Edit2 size={14} /> تحرير
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
