import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Image as ImageIcon, Video, Save, X } from 'lucide-react';

export default function MediaManager() {
  const [photos, setPhotos] = useState<any[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'photos' | 'videos'>('photos');
  const [isAdding, setIsAdding] = useState(false);
  const [addForm, setAddForm] = useState<any>({});

  useEffect(() => {
    fetchMedia();
  }, [activeTab]);

  const fetchMedia = () => {
    fetch(`/api/cms/${activeTab}`)
      .then(res => res.json())
      .then(data => {
        if (data.status === 'ok') {
          activeTab === 'photos' ? setPhotos(data.data) : setVideos(data.data);
        }
      });
  };

  const handleSave = async () => {
    try {
      await fetch(`/api/cms/${activeTab}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(addForm)
      });
      setIsAdding(false);
      setAddForm({});
      fetchMedia();
    } catch (err) { alert("حدث خطأ أثناء الحفظ"); }
  };

  const handleDelete = async (id: string) => {
    if(!confirm('هل أنت متأكد من الحذف؟')) return;
    try {
      await fetch(`/api/cms/${activeTab}/${id}`, { method: 'DELETE' });
      fetchMedia();
    } catch (err) { alert("حدث خطأ أثناء الحذف"); }
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-4">
        <button onClick={() => setActiveTab('photos')} className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-colors ${activeTab === 'photos' ? 'bg-blue-600 text-white shadow-lg' : 'bg-[#161a27] text-gray-400 hover:text-white'}`}>
          <ImageIcon size={20} /> معرض الصور
        </button>
        <button onClick={() => setActiveTab('videos')} className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-colors ${activeTab === 'videos' ? 'bg-blue-600 text-white shadow-lg' : 'bg-[#161a27] text-gray-400 hover:text-white'}`}>
          <Video size={20} /> مكتبة الفيديو
        </button>
      </div>

      <div className="bg-[#161a27] rounded-2xl border border-white/5 overflow-hidden p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">{activeTab === 'photos' ? 'الصور' : 'الفيديوهات'}</h2>
          {!isAdding && (
            <button onClick={() => setIsAdding(true)} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl font-bold transition-colors flex items-center gap-2">
              <Plus size={18} /> إضافة {activeTab === 'photos' ? 'صورة' : 'فيديو'}
            </button>
          )}
        </div>

        {isAdding && (
          <div className="bg-[#1e2338] p-6 rounded-xl border border-white/10 mb-8 space-y-4">
            <h3 className="font-bold text-lg mb-4 text-blue-400">إضافة عنصر جديد</h3>
            <div>
              <label className="block text-gray-400 mb-2 text-sm">العنوان</label>
              <input type="text" value={addForm.title || ''} onChange={e => setAddForm({...addForm, title: e.target.value})} className="w-full bg-[#161a27] border border-white/10 rounded-lg px-4 py-2 text-white" />
            </div>
            <div>
              <label className="block text-gray-400 mb-2 text-sm">رابط {activeTab === 'photos' ? 'الصورة' : 'الفيديو'} (URL)</label>
              <input type="text" value={addForm.url || ''} onChange={e => setAddForm({...addForm, url: e.target.value})} className="w-full bg-[#161a27] border border-white/10 rounded-lg px-4 py-2 text-white" dir="ltr" />
            </div>
            {activeTab === 'videos' && (
              <div>
                <label className="block text-gray-400 mb-2 text-sm">رابط الصورة المصغرة (اختياري)</label>
                <input type="text" value={addForm.thumbnailUrl || ''} onChange={e => setAddForm({...addForm, thumbnailUrl: e.target.value})} className="w-full bg-[#161a27] border border-white/10 rounded-lg px-4 py-2 text-white" dir="ltr" />
              </div>
            )}
            <div>
              <label className="block text-gray-400 mb-2 text-sm">وصف قصير (اختياري)</label>
              <input type="text" value={addForm.description || ''} onChange={e => setAddForm({...addForm, description: e.target.value})} className="w-full bg-[#161a27] border border-white/10 rounded-lg px-4 py-2 text-white" />
            </div>
            <div className="flex gap-2 pt-4">
              <button onClick={handleSave} className="px-6 py-2 bg-blue-600 rounded-lg font-bold hover:bg-blue-700">حفظ</button>
              <button onClick={() => setIsAdding(false)} className="px-6 py-2 bg-white/10 rounded-lg font-bold hover:bg-white/20">إلغاء</button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {(activeTab === 'photos' ? photos : videos).map((item) => (
            <div key={item._id} className="relative group bg-[#1e2338] rounded-xl overflow-hidden border border-white/5 aspect-square">
              {activeTab === 'photos' ? (
                <img src={item.url} alt={item.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-black flex items-center justify-center">
                  <Video className="text-white/50" size={48} />
                </div>
              )}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                <h4 className="text-white font-bold text-sm mb-2 truncate">{item.title}</h4>
                <button onClick={() => handleDelete(item._id)} className="p-2 bg-red-500 hover:bg-red-600 text-white rounded-lg self-end">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
