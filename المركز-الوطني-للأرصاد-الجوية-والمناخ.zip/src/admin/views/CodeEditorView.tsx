import React, { useState, useEffect } from 'react';
import { Save, FileCode2, RefreshCw } from 'lucide-react';

export default function CodeEditorView() {
  const [files, setFiles] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [content, setContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = async () => {
    try {
      const res = await fetch('/api/files');
      const data = await res.json();
      if (data.files) {
        setFiles(data.files);
      }
    } catch (err) {
      console.error("Failed to fetch files", err);
    }
  };

  const handleSelectFile = async (filePath: string) => {
    setSelectedFile(filePath);
    setIsLoading(true);
    try {
      const res = await fetch(`/api/files/content?path=${encodeURIComponent(filePath)}`);
      const data = await res.json();
      if (data.content !== undefined) {
        setContent(data.content);
      }
    } catch (err) {
      console.error("Failed to load file content", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!selectedFile) return;
    setIsSaving(true);
    try {
      const res = await fetch('/api/files/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: selectedFile, content })
      });
      if (res.ok) {
        alert("تم الحفظ بنجاح. قد تحتاج لإعادة تحميل الصفحة لرؤية التغييرات.");
      } else {
        alert("فشل في حفظ الملف");
      }
    } catch (err) {
      console.error("Failed to save file", err);
      alert("فشل في حفظ الملف");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">محرر الأكواد</h2>
          <p className="text-gray-400 mt-1">تعديل الملفات البرمجية للواجهة مباشرة (تحذير: التعديلات تنطبق فوراً وقد تؤدي لتعطل التطبيق)</p>
        </div>
        <button
          onClick={handleSave}
          disabled={!selectedFile || isSaving}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors disabled:opacity-50"
        >
          {isSaving ? <RefreshCw size={18} className="animate-spin" /> : <Save size={18} />}
          حفظ التعديلات
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 h-[70vh]">
        {/* File Browser */}
        <div className="col-span-1 bg-[#1e2338] rounded-2xl border border-white/5 overflow-hidden flex flex-col">
          <div className="p-4 border-b border-white/5 bg-black/20">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <FileCode2 size={18} className="text-blue-400" />
              الملفات (src)
            </h3>
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            {files.map(file => (
              <button
                key={file}
                onClick={() => handleSelectFile(file)}
                className={`w-full text-right px-3 py-2 text-sm rounded-lg transition-colors truncate ${selectedFile === file ? 'bg-blue-600/20 text-blue-400' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
                title={file}
              >
                <span dir="ltr">{file}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Editor */}
        <div className="col-span-3 bg-[#0b0f19] rounded-2xl border border-white/5 overflow-hidden flex flex-col">
          {selectedFile ? (
            isLoading ? (
              <div className="flex-1 flex items-center justify-center">
                <RefreshCw size={24} className="text-blue-400 animate-spin" />
              </div>
            ) : (
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="flex-1 w-full p-4 bg-transparent text-gray-300 font-mono text-sm focus:outline-none resize-none custom-scrollbar"
                dir="ltr"
                spellCheck={false}
              />
            )
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-500">
              <FileCode2 size={48} className="mb-4 opacity-50" />
              <p>يرجى اختيار ملف من القائمة لتعديله</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
