import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Save, X, Newspaper } from 'lucide-react';

export default function NewsManager() {
  const [news, setNews] = useState<any[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<any>(null);

  useEffect(() => { fetchNews(); }, []);

  const fetchNews = () => {
    fetch('/api/cms/news')
      .then(res => res.json())
      .then(data => { if (data.status === 'ok') setNews(data.data); });
  };

  const handleSave = async () => {
    const isNew = !editForm._id;
    const url = isNew ? '/api/cms/news' : `/api/cms/news/${editForm._id}`;
    const method = isNew ? 'POST' : 'PUT';

    try {
      await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm)
      });
      setIsEditing(false);
      fetchNews();
    } catch (err) { alert("حدث خطأ أثناء الحفظ"); }
  };

  const handleDelete = async (id: string) => {
    if(!confirm('هل أنت متأكد من حذف هذا الخبر؟')) return;
    try {
      await fetch(`/api/cms/news/${id}`, { method: 'DELETE' });
      fetchNews();
    } catch (err) { alert("حدث خطأ أثناء الحذف"); }
  };

  if (isEditing) {
    return (
      <div className="bg-[#161a27] rounded-2xl border border-white/5 p-6 shadow-2xl">
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-white/10">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Newspaper className="text-blue-500" /> {editForm._id ? 'تحرير الخبر' : 'إضافة خبر جديد'}
          </h2>
          <div className="flex gap-2">
            <button onClick={() => setIsEditing(false)} className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors flex items-center gap-2">
              <X size={18} /> إلغاء
            </button>
            <button onClick={handleSave} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl font-bold transition-colors flex items-center gap-2">
              <Save size={18} /> حفظ الخبر
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-gray-400 mb-2 font-bold">عنوان الخبر</label>
            <input type="text" value={editForm.title || ''} onChange={e => setEditForm({...editForm, title: e.target.value})} className="w-full bg-[#1e2338] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500" />
          </div>
          <div>
            <label className="block text-gray-400 mb-2 font-bold">التفاصيل والمحتوى</label>
            <textarea value={editForm.content || ''} onChange={e => setEditForm({...editForm, content: e.target.value})} className="w-full bg-[#1e2338] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 h-32" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-gray-400 mb-2 font-bold">رابط الصورة (URL)</label>
              <input type="text" value={editForm.imageUrl || ''} onChange={e => setEditForm({...editForm, imageUrl: e.target.value})} className="w-full bg-[#1e2338] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500" dir="ltr" />
            </div>
            <div>
              <label className="block text-gray-400 mb-2 font-bold">المصدر (اختياري)</label>
              <input type="text" value={editForm.source || ''} onChange={e => setEditForm({...editForm, source: e.target.value})} className="w-full bg-[#1e2338] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#161a27] rounded-2xl border border-white/5 overflow-hidden">
      <div className="p-6 border-b border-white/10 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2 mb-1">
            <Newspaper className="text-blue-500" /> المركز الإعلامي - الأخبار
          </h2>
          <p className="text-gray-400 text-sm">نشر الأخبار وإدارة محتوى المركز الإعلامي</p>
        </div>
        <button onClick={() => { setEditForm({}); setIsEditing(true); }} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-xl font-bold transition-colors flex items-center gap-2 shadow-lg shadow-blue-500/20">
          <Plus size={18} /> خبر جديد
        </button>
      </div>
      <div className="grid grid-cols-1 gap-4 p-6">
        {news.map((item) => (
          <div key={item._id} className="bg-[#1e2338] p-4 rounded-xl border border-white/5 flex gap-4 items-start group">
            {item.imageUrl && (
              <img src={item.imageUrl} alt="" className="w-24 h-24 object-cover rounded-lg shrink-0" />
            )}
            <div className="flex-1">
              <h3 className="text-lg font-bold text-white mb-1">{item.title}</h3>
              <p className="text-sm text-gray-400 line-clamp-2">{item.content}</p>
              <span className="text-xs text-gray-500 mt-2 block">{new Date(item.date).toLocaleDateString('ar-SA')}</span>
            </div>
            <div className="flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button onClick={() => { setEditForm(item); setIsEditing(true); }} className="p-2 bg-blue-500/10 text-blue-400 hover:bg-blue-500 hover:text-white rounded-lg transition-colors"><Edit2 size={16} /></button>
              <button onClick={() => handleDelete(item._id)} className="p-2 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-colors"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
