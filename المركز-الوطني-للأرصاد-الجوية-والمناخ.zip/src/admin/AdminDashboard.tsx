import React, { useState, useEffect } from 'react';
import { FileText, Image, Settings, Database, Server, LayoutDashboard, ShieldCheck, LogOut, ShieldAlert, Newspaper, Code } from 'lucide-react';
import PagesManager from './views/PagesManager';
import NewsManager from './views/NewsManager';
import MediaManager from './views/MediaManager';
import CodeEditorView from './views/CodeEditorView';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  
  const triggerTestAlert = async (severity: string) => {
    try {
      await fetch('/api/alerts/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: severity === 'Extreme' ? 'تحذير شديد الخطورة: عاصفة رملية' : 'تنبيه: أمطار رعدية',
          description: 'هذا تنبيه تجريبي تم إرساله من لوحة التحكم لتجربة نظام الإشعارات الفورية.',
          severity
        })
      });
      alert('تم إرسال التنبيه بنجاح');
    } catch (e) {
      alert('فشل في إرسال التنبيه');
    }
  };

  const SidebarItem = ({ id, icon: Icon, label }: any) => (
    <button 
      onClick={() => setActiveTab(id)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
        activeTab === id ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-400 hover:bg-white/5 hover:text-white'
      }`}
    >
      <Icon size={20} />
      <span className="font-bold">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-[#0f1219] text-white flex" dir="rtl">
      {/* Admin Sidebar */}
      <aside className="w-64 bg-[#161a27] border-l border-white/5 p-6 flex flex-col gap-4">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-blue-600 rounded-lg"><ShieldCheck size={24} /></div>
          <span className="font-bold text-xl">لوحة التحكم</span>
        </div>
        
        <SidebarItem id="overview" icon={LayoutDashboard} label="نظرة عامة" />
        <SidebarItem id="pages" icon={FileText} label="إدارة الصفحات" />
        <SidebarItem id="news" icon={Newspaper} label="الأخبار" />
        <SidebarItem id="media" icon={Image} label="الصور والفيديو" />
        <SidebarItem id="alerts" icon={ShieldAlert} label="إدارة التنبيهات (CAP)" />
        <SidebarItem id="database" icon={Database} label="قواعد البيانات" />
        <SidebarItem id="settings" icon={Settings} label="الإعدادات" />
        <SidebarItem id="code" icon={Code} label="محرر الأكواد" />
        
        <div className="mt-auto">
          <button className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition-colors font-bold">
            <LogOut size={20} /> تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-y-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">النظام المركزي لإدارة الموقع</h1>
            <p className="text-gray-400">إدارة المحتوى، قواعد البيانات، والتطبيقات من مكان واحد</p>
          </div>
          <div className="flex gap-4">
            <div className="px-4 py-2 bg-green-500/10 text-green-400 border border-green-500/20 rounded-xl flex items-center gap-2 font-bold">
              <Server size={18} />
              <span>قاعدة البيانات: {process.env.VITE_DB_TYPE || 'JSON محلي / MongoDB'}</span>
            </div>
          </div>
        </div>

        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#161a27] p-6 rounded-2xl border border-white/5">
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center text-blue-400 mb-4">
                <ShieldCheck size={24} />
              </div>
              <h3 className="text-xl font-bold mb-1">النظام متصل</h3>
              <p className="text-gray-400">جميع الخدمات تعمل بكفاءة</p>
            </div>
          </div>
        )}

        {activeTab === 'alerts' && (
          <div className="bg-[#161a27] p-6 rounded-2xl border border-white/5">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <ShieldAlert className="text-red-500" /> إدارة التنبيهات المباشرة (CAP)
            </h2>
            <p className="text-gray-400 mb-8">قم باختبار نظام الإشعارات الفورية للزوار عبر إرسال تنبيه تجريبي.</p>
            
            <div className="flex gap-4">
              <button 
                onClick={() => triggerTestAlert('Extreme')}
                className="px-6 py-3 bg-red-600 hover:bg-red-700 rounded-xl font-bold transition-colors shadow-lg shadow-red-500/20"
              >
                إرسال تنبيه عاجل (Extreme)
              </button>
              
              <button 
                onClick={() => triggerTestAlert('Moderate')}
                className="px-6 py-3 bg-yellow-600 hover:bg-yellow-700 rounded-xl font-bold transition-colors shadow-lg shadow-yellow-500/20"
              >
                إرسال تنبيه متوسط (Moderate)
              </button>
            </div>
          </div>
        )}

        {activeTab === 'pages' && <PagesManager />}
        {activeTab === 'news' && <NewsManager />}
        {activeTab === 'media' && <MediaManager />}
        {activeTab === 'code' && <CodeEditorView />}
        
        {activeTab === 'database' && (
          <div className="bg-[#161a27] p-8 rounded-2xl border border-white/5">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Database className="text-blue-500" /> إعدادات قواعد البيانات
            </h2>
            <p className="text-gray-400 mb-8 max-w-2xl leading-relaxed">
              تم بناء طبقة تجريد البيانات (Database Abstraction Layer) لتسهيل الربط السلس مع أي قاعدة بيانات.
              يمكنك التبديل بين قواعد البيانات من خلال تغيير متغيرات البيئة.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#1e2338] p-6 rounded-xl border border-white/10">
                <h3 className="font-bold text-lg mb-2 text-white">MongoDB</h3>
                <p className="text-gray-400 text-sm mb-4">يعمل حالياً بشكل تلقائي في حال توفر MONGO_URI في البيئة.</p>
                <div className="text-xs font-mono bg-black/50 p-3 rounded-lg text-green-400">
                  DB_TYPE=mongodb<br/>
                  MONGO_URI=mongodb+srv://...
                </div>
              </div>
              <div className="bg-[#1e2338] p-6 rounded-xl border border-white/10">
                <h3 className="font-bold text-lg mb-2 text-white">Supabase / PostgreSQL</h3>
                <p className="text-gray-400 text-sm mb-4">متوافق وجاهز للربط مع Supabase و PostgreSQL عبر واجهات DAL.</p>
                <div className="text-xs font-mono bg-black/50 p-3 rounded-lg text-blue-400">
                  DB_TYPE=supabase<br/>
                  SUPABASE_URL=https://...
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
