import { useEffect, useState, useRef } from 'react';

// Play a synthesized distinct sound
const playAlertSound = () => {
  try {
    const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext) as typeof AudioContext;
    if (!AudioContextClass) return;
    
    const ctx = new AudioContextClass();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    // Siren-like sound
    osc1.type = 'square';
    osc1.frequency.setValueAtTime(600, ctx.currentTime);
    osc1.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.3);
    
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(900, ctx.currentTime);
    
    gainNode.gain.setValueAtTime(0, ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.1);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.8);
    
    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    osc1.start(ctx.currentTime);
    osc2.start(ctx.currentTime);
    
    osc1.stop(ctx.currentTime + 1);
    osc2.stop(ctx.currentTime + 1);
  } catch (e) {
    console.error("Failed to play audio:", e);
  }
};

export function useAlertNotifications() {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const seenAlerts = useRef<Set<string>>(new Set());

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = async () => {
    if (!('Notification' in window)) return false;
    
    try {
      const p = await Notification.requestPermission();
      setPermission(p);
      // Play a tiny sound to unlock AudioContext if needed
      playAlertSound();
      return p === 'granted';
    } catch (err) {
      console.error(err);
      return false;
    }
  };

  useEffect(() => {
    let evtSource: EventSource | null = null;
    let reconnectTimer: any;

    const connect = () => {
      evtSource = new EventSource('/api/alerts/stream');
      
      evtSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.type === 'new_alert') {
            const alert = data.alert;
            if (!seenAlerts.current.has(alert.id)) {
              seenAlerts.current.add(alert.id);
              
              // Only notify for Severe or Extreme
              const isUrgent = alert.severity === 'Severe' || alert.severity === 'Extreme';
              
              if (isUrgent && Notification.permission === 'granted') {
                playAlertSound();
                
                new Notification(alert.title, {
                  body: alert.description,
                  icon: '/icon.png', // Assuming an icon exists, or use default
                  tag: 'weather-alert',
                  requireInteraction: true // Keep open until user dismisses
                });
              }
            }
          }
        } catch (e) {
          console.error("Error parsing SSE data", e);
        }
      };

      evtSource.onerror = () => {
        evtSource?.close();
        // Reconnect after 5s
        reconnectTimer = setTimeout(connect, 5000);
      };
    };

    connect();

    return () => {
      evtSource?.close();
      clearTimeout(reconnectTimer);
    };
  }, []);

  return { permission, requestPermission, playAlertSound };
}
