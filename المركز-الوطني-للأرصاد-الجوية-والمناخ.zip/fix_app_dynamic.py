import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

import_statement = "import DynamicPageView from './components/views/DynamicPageView';\n"
content = content.replace("import IframeRouteWrapper from", import_statement + "import IframeRouteWrapper from")

content = content.replace("<IframeRouteWrapper />", "<DynamicPageView />")

with open('src/App.tsx', 'w') as f:
    f.write(content)
