with open('src/App.tsx', 'r') as f:
    content = f.read()

import re
# Remove the div containing MobileWeatherDashboard
pattern = re.compile(r'<div className="block md:hidden pb-20">.*?<MobileWeatherDashboard.*?>\s*</div>', re.DOTALL)
content = pattern.sub('', content)

with open('src/App.tsx', 'w') as f:
    f.write(content)
