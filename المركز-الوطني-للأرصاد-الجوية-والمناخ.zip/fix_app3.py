with open('src/App.tsx', 'r') as f:
    content = f.read()

replacement1 = """  const [error, setError] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);"""
content = content.replace("  const [error, setError] = useState<string | null>(null);", replacement1)

replacement2 = """        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#1e2338]/90 backdrop-blur-lg border-t border-white/10 flex justify-around items-center p-3 z-50">
          <Link to="/weather" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/weather') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Sun size={20} />
            <span className="text-[10px]">الرئيسية</span>
          </Link>
          <Link to="/map" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/map') ? 'text-blue-400' : 'text-gray-400'}`}>
            <MapPin size={20} />
            <span className="text-[10px]">الخريطة</span>
          </Link>
          <Link to="/route" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/route') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Map size={20} />
            <span className="text-[10px]">المسار</span>
          </Link>
          <Link to="/stations-list" className={`flex flex-col items-center gap-1 ${location.pathname.includes('/stations') ? 'text-blue-400' : 'text-gray-400'}`}>
            <Activity size={20} />
            <span className="text-[10px]">المحطات</span>
          </Link>
          <button onClick={() => setIsMobileMenuOpen(true)} className="flex flex-col items-center gap-1 text-gray-400 hover:text-blue-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
            <span className="text-[10px]">القائمة</span>
          </button>
        </div>

        {/* Mobile Menu Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-[100] flex">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)}></div>
            <div className="relative w-64 max-w-[80%] bg-[#1e2338] h-full flex flex-col animate-in slide-in-from-right duration-300">
              <div className="p-4 border-b border-white/10 flex justify-between items-center">
                <span className="font-bold text-lg">القائمة الرئيسية</span>
                <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 bg-white/5 rounded-full text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </button>
              </div>
              <div className="flex-1 overflow-y-auto pb-20" onClick={() => setIsMobileMenuOpen(false)}>
                <Sidebar />
              </div>
            </div>
          </div>
        )}"""

import re
pattern = re.compile(r'        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-\[#1e2338\]/90 backdrop-blur-lg border-t border-white/10 flex justify-around items-center p-3 z-50">.*?</div>', re.DOTALL)
content = pattern.sub(replacement2, content)

with open('src/App.tsx', 'w') as f:
    f.write(content)
