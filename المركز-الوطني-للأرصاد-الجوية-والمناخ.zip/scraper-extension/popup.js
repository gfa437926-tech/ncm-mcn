const startBtn = document.getElementById('startBtn');
const counterText = document.getElementById('counterText');
const statusLabel = document.getElementById('statusLabel');
const errorDiv = document.getElementById('errorMessage');

let totalStations = 0; // سيتم تحديثه من الخلفية

startBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: "start_scraping" });
  startBtn.disabled = true;
  statusLabel.innerText = "جاري سحب بيانات المحطات...";
  errorDiv.style.display = "none";
  errorDiv.innerText = "";
});

chrome.runtime.onMessage.addListener((message) => {
  switch (message.action) {
    case "update_progress":
      counterText.innerText = `${message.current} / ${message.total}`;
      totalStations = message.total;
      let attemptText = (message.attempt && message.attempt > 1) ? ` (محاولة ${message.attempt}/${message.maxAttempts})` : "";
      statusLabel.innerHTML = `جاري العمل على: <b>${message.station}</b>${attemptText}`;
      errorDiv.style.display = "none";
      break;
      
    case "retry":
      statusLabel.innerHTML = `⚠️ إعادة محاولة <b>${message.station}</b> (${message.attempt}/${message.maxAttempts})`;
      break;
      
    case "station_done":
      if (message.success) {
        statusLabel.innerHTML = `✅ تم بنجاح: <b>${message.station}</b>`;
        setTimeout(() => {
          if (statusLabel.innerHTML.includes(message.station))
            statusLabel.innerHTML = "مستمر...";
        }, 2000);
      }
      break;
      
    case "error":
      errorDiv.style.display = "block";
      errorDiv.innerText = `❌ ${message.station}: ${message.message}`;
      statusLabel.innerHTML = `فشل في ${message.station}`;
      break;
      
    case "complete":
      statusLabel.innerHTML = "🎉 اكتمل السحب. سيتم فتح التقرير الذكي الآن.";
      startBtn.disabled = false;
      counterText.innerText = `${totalStations} / ${totalStations}`;
      break;
  }
});
