(async function() {
  const container = document.getElementById('reportsContainer');
  
  // استرجاع البيانات من التخزين المحلي
  const { weatherData } = await chrome.storage.local.get('weatherData');
  if (!weatherData || weatherData.length === 0) {
    container.innerHTML = '<div style="text-align:center; padding:50px;">⚠️ لا توجد بيانات متاحة. يرجى تشغيل السحب أولاً.</div>';
    return;
  }

  for (const station of weatherData) {
    try {
      const card = document.createElement('div');
      card.className = 'station-card';
      
      // رأس المحطة
      const headerDiv = document.createElement('div');
      headerDiv.className = 'station-header';
      headerDiv.innerHTML = `
        <div>
          <span class="station-title">📍 ${station.name} (${station.arName || station.name})</span>
          <span class="station-coords">${station.coords}</span>
        </div>
        <a href="https://www.windy.com/${station.coords.replace(', ', '/')}?forecast" target="_blank" class="verify-btn">
          🔗 تحقق من البيانات في Windy
        </a>
      `;
      card.appendChild(headerDiv);
      
      // تحليل الجدول
      const parser = new DOMParser();
      const doc = parser.parseFromString(station.tableHtml, 'text/html');
      
      // استخراج الصفوف المطلوبة
      const days = Array.from(doc.querySelectorAll('.tr--days td')).map(td => ({ name: td.innerText.trim(), span: td.colSpan }));
      const hours = Array.from(doc.querySelectorAll('.tr--hour td')).map(td => td.innerText.trim());
      const icons = Array.from(doc.querySelectorAll('.tr--icon td img')).map(img => {
        let src = img.getAttribute('src');
        if (src && !src.startsWith('http')) src = 'https://www.windy.com' + src;
        return src;
      });
      const temps = Array.from(doc.querySelectorAll('.tr--temp td')).map(td => td.innerText.trim());
      const winds = Array.from(doc.querySelectorAll('.tr--wind td')).map(td => td.innerText.trim());
      const gusts = Array.from(doc.querySelectorAll('.tr--gust td')).map(td => td.innerText.trim());
      const dirs = Array.from(doc.querySelectorAll('.tr--windDir td div')).map(div => {
        const match = div.style.transform.match(/rotate\((\d+)deg\)/);
        return match ? match[1] : '0';
      });
      
      // بناء الجدول
      const table = document.createElement('table');
      table.className = 'forecast-table';
      
      // صف الأيام
      let rowDays = table.insertRow();
      let thLabel = document.createElement('td');
      thLabel.className = 'label-col';
      thLabel.innerText = 'اليوم';
      rowDays.appendChild(thLabel);
      days.forEach(day => {
        let td = document.createElement('td');
        td.colSpan = day.span;
        td.className = 'day-header';
        td.innerText = day.name;
        rowDays.appendChild(td);
      });
      
      // صف الساعات
      let rowHours = table.insertRow();
      let hourLabel = document.createElement('td');
      hourLabel.className = 'label-col';
      hourLabel.innerText = 'الساعة';
      rowHours.appendChild(hourLabel);
      hours.forEach(h => {
        let td = document.createElement('td');
        td.innerText = h;
        rowHours.appendChild(td);
      });
      
      // صف الأيقونات
      let rowIcons = table.insertRow();
      let iconLabel = document.createElement('td');
      iconLabel.className = 'label-col';
      iconLabel.innerText = 'السماء';
      rowIcons.appendChild(iconLabel);
      icons.forEach(src => {
        let td = document.createElement('td');
        let img = document.createElement('img');
        img.src = src;
        img.className = 'weather-icon';
        td.appendChild(img);
        rowIcons.appendChild(td);
      });
      
      // صف الحرارة
      let rowTemp = table.insertRow();
      let tempLabel = document.createElement('td');
      tempLabel.className = 'label-col';
      tempLabel.innerText = '🌡️ الحرارة';
      rowTemp.appendChild(tempLabel);
      temps.forEach(t => {
        let td = document.createElement('td');
        td.className = 'temp';
        td.innerText = t;
        rowTemp.appendChild(td);
      });
      
      // صف الرياح
      let rowWind = table.insertRow();
      let windLabel = document.createElement('td');
      windLabel.className = 'label-col';
      windLabel.innerText = '💨 الرياح';
      rowWind.appendChild(windLabel);
      winds.forEach(w => {
        let td = document.createElement('td');
        td.className = `wind-cell ${getWindClass(parseInt(w))}`;
        td.innerText = w;
        rowWind.appendChild(td);
      });
      
      // صف الهبات
      let rowGust = table.insertRow();
      let gustLabel = document.createElement('td');
      gustLabel.className = 'label-col';
      gustLabel.innerText = '💨 الهبات';
      rowGust.appendChild(gustLabel);
      gusts.forEach(g => {
        let td = document.createElement('td');
        td.className = `wind-cell ${getWindClass(parseInt(g))}`;
        td.innerText = g;
        rowGust.appendChild(td);
      });
      
      // صف الاتجاه (سهم دوار)
      let rowDir = table.insertRow();
      let dirLabel = document.createElement('td');
      dirLabel.className = 'label-col';
      dirLabel.innerText = '🧭 الاتجاه';
      rowDir.appendChild(dirLabel);
      dirs.forEach(deg => {
        let td = document.createElement('td');
        let arrow = document.createElement('div');
        arrow.className = 'arrow';
        arrow.style.transform = `rotate(${deg}deg)`;
        arrow.innerHTML = '↓';
        td.appendChild(arrow);
        rowDir.appendChild(td);
      });
      
      const wrapper = document.createElement('div');
      wrapper.className = 'table-wrapper';
      wrapper.appendChild(table);
      card.appendChild(wrapper);
      container.appendChild(card);
      
    } catch (err) {
      console.warn(`فشل معالجة ${station.name}`, err);
      container.innerHTML += `<div style="background:#330000; padding:10px; margin:10px">⚠️ خطأ في تحليل بيانات ${station.name}</div>`;
    }
  }
  
  function getWindClass(val) {
    if (isNaN(val)) return 'wind-low';
    if (val >= 15) return 'wind-vhigh';
    if (val >= 10) return 'wind-high';
    if (val >= 6) return 'wind-med';
    return 'wind-low';
  }
})();
