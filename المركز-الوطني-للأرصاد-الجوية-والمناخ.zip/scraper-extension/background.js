const locations = [
  { name: 'دمشق', ar: 'دمشق', url: 'https://www.windy.com/33.513/36.292' },
  { name: 'حلب', ar: 'حلب', url: 'https://www.windy.com/36.202/37.134' },
  { name: 'اللاذقية', ar: 'اللاذقية', url: 'https://www.windy.com/35.542/35.767' }
];
const MAX_RETRIES = 2;
const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

let collectedData = [];

async function waitForElement(tabId, selector, timeout = 25000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    try {
      const result = await chrome.scripting.executeScript({
        target: { tabId },
        func: (sel) => !!document.querySelector(sel),
        args: [selector]
      });
      if (result[0] && result[0].result) return true;
    } catch (e) {}
    await wait(1000);
  }
  return false;
}

async function smoothScroll(tabId, steps = 2) {
  for (let i = 0; i < steps; i++) {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => window.scrollBy(0, window.innerHeight * 0.6)
    });
    await wait(1500);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "start_scraping") {
    runScraper().catch(console.error);
    sendResponse({ status: "started" });
  }
  return true;
});

async function runScraper() {
  collectedData = [];
  const total = locations.length;
  
  for (let i = 0; i < total; i++) {
    const loc = locations[i];
    let retries = 0;
    let success = false;

    while (retries < MAX_RETRIES && !success) {
      chrome.runtime.sendMessage({
        action: "update_progress",
        current: i + 1,
        total: total,
        station: loc.name,
        arName: loc.ar,
        attempt: retries + 1,
        maxAttempts: MAX_RETRIES
      });

      let tab = null;
      try {
        tab = await chrome.tabs.create({ url: loc.url, active: true });
        await wait(12000);
        
        const selectorsToTry = [
          "table.forecast-table__table",
          "table[class*='forecast']",
          "div[class*='forecast'] table"
        ];
        let tableFound = false;
        for (const selector of selectorsToTry) {
          if (await waitForElement(tab.id, selector, 18000)) {
            tableFound = true;
            break;
          }
        }
        
        if (!tableFound) throw new Error("جدول التوقعات غير موجود");
        
        await smoothScroll(tab.id, 2);
        
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (selectors) => {
            for (const sel of selectors) {
              const table = document.querySelector(sel);
              if (table) return table.outerHTML;
            }
            return null;
          },
          args: [selectorsToTry]
        });
        
        const tableHtml = results[0]?.result;
        if (!tableHtml) throw new Error("فشل استخراج الجدول");
        
        const stationInfo = {
          name: loc.name,
          arName: loc.ar,
          coords: extractCoordsFromUrl(loc.url),
          tableHtml: tableHtml,
          timestamp: Date.now()
        };
        collectedData.push(stationInfo);
        
        await chrome.storage.local.set({ weatherData: collectedData });
        
        success = true;
        chrome.runtime.sendMessage({
          action: "station_done",
          station: loc.name,
          success: true
        });
        
        await chrome.tabs.remove(tab.id);
        await wait(2000);
        
      } catch (error) {
        console.error(`خطأ في ${loc.name}:`, error);
        if (tab) {
          try { await chrome.tabs.remove(tab.id); } catch(e) {}
        }
        retries++;
        if (retries < MAX_RETRIES) {
          chrome.runtime.sendMessage({
            action: "retry",
            station: loc.name,
            attempt: retries,
            maxAttempts: MAX_RETRIES
          });
          await wait(10000);
        }
      }
    }
    
    if (!success) {
      chrome.runtime.sendMessage({
        action: "error",
        station: loc.name,
        message: `فشل بعد ${MAX_RETRIES} محاولات`
      });
    }
  }
  
  chrome.storage.local.set({ weatherData: collectedData }, () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("report.html") });
  });
  
  chrome.runtime.sendMessage({ action: "complete" });
}

function extractCoordsFromUrl(url) {
  const match = url.match(/(\d+\.\d+)\/(\d+\.\d+)/);
  if (match) return `${match[1]}, ${match[2]}`;
  return "غير معروفة";
}
