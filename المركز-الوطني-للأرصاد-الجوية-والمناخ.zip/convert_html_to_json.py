import os
import json
import re

html_dir = 'public/pages'
output_file = 'src/data/pagesData.json'

pages_data = {}

for filename in os.listdir(html_dir):
    if filename.endswith('.html'):
        filepath = os.path.join(html_dir, filename)
        with open(filepath, 'r', encoding='utf-8') as f:
            html = f.read()
            
        page_id = filename.replace('.html', '')
        
        title_match = re.search(r'<title>(.*?)</title>', html, re.IGNORECASE)
        title = title_match.group(1) if title_match else page_id
        
        h1_match = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.IGNORECASE | re.DOTALL)
        header_title = re.sub(r'<[^>]+>', '', h1_match.group(1)).strip() if h1_match else title
        
        p_match = re.search(r'<div class="header">.*?<p>(.*?)</p>', html, re.IGNORECASE | re.DOTALL)
        header_desc = re.sub(r'<[^>]+>', '', p_match.group(1)).strip() if p_match else ''
        
        sections = []
        cards = re.findall(r'<div class="(?:card|task-card)">(.*?)</div>\s*(?:<div|$)', html, re.IGNORECASE | re.DOTALL)
        
        if cards:
            for card_html in cards:
                card_title_match = re.search(r'<h[23][^>]*>(.*?)</h[23]>', card_html, re.IGNORECASE | re.DOTALL)
                card_title = re.sub(r'<[^>]+>', '', card_title_match.group(1)).strip() if card_title_match else ''
                
                list_items = []
                lis = re.findall(r'<li>(.*?)</li>', card_html, re.IGNORECASE | re.DOTALL)
                for li in lis:
                    list_items.append(re.sub(r'<[^>]+>', '', li).strip())
                    
                paragraphs = []
                ps = re.findall(r'<p>(.*?)</p>', card_html, re.IGNORECASE | re.DOTALL)
                for p in ps:
                    paragraphs.append(re.sub(r'<[^>]+>', '', p).strip())
                    
                sections.append({
                    'title': card_title,
                    'list': list_items,
                    'paragraphs': paragraphs
                })
        else:
            # No cards found, just extract all lists and paragraphs from body
            body_match = re.search(r'<body[^>]*>(.*?)</body>', html, re.IGNORECASE | re.DOTALL)
            body_html = body_match.group(1) if body_match else html
            
            list_items = []
            lis = re.findall(r'<li>(.*?)</li>', body_html, re.IGNORECASE | re.DOTALL)
            for li in lis:
                list_items.append(re.sub(r'<[^>]+>', '', li).strip())
                
            paragraphs = []
            # exclude paragraphs that might have been matched in the header
            ps = re.findall(r'<p[^>]*>(.*?)</p>', body_html, re.IGNORECASE | re.DOTALL)
            for p in ps:
                clean_p = re.sub(r'<[^>]+>', '', p).strip()
                if clean_p and clean_p != header_desc:
                    paragraphs.append(clean_p)
            
            if list_items or paragraphs:
                sections.append({
                    'title': '',
                    'list': list_items,
                    'paragraphs': paragraphs
                })
            
        pages_data[page_id] = {
            'title': header_title,
            'description': header_desc,
            'sections': sections
        }

os.makedirs(os.path.dirname(output_file), exist_ok=True)
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(pages_data, f, ensure_ascii=False, indent=2)

print("Conversion complete.")
