import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

pattern = re.compile(r'      <Route path="/weather" element=\{.*?</div>\n      \} />', re.DOTALL)

replacement = """      <Route path="/weather" element={
        <div className="max-w-7xl mx-auto w-full animate-in fade-in duration-500 pb-20 md:pb-0">
          <WeatherDashboard 
            data={weatherData} 
            cities={cities}
            selectedCity={selectedCity}
            onCityChange={setSelectedCity}
            loading={loading}
          />
          <div className="mt-8">
            <MediaSection />
          </div>
        </div>
      } />"""

new_content = pattern.sub(replacement, content)

with open('src/App.tsx', 'w') as f:
    f.write(new_content)
